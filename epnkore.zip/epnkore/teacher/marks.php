<?php
/**
 * EP NKORE - School Management System
 * Marks Entry & Continuous Assessment Grading System
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, ['Teacher', 'Head Teacher', 'Administrator']);

// Fetch teacher record if logged in as teacher
$stmt_t = $pdo->prepare("SELECT id FROM teachers WHERE user_id = ?");
$stmt_t->execute([$current_user['id']]);
$teacher_id = $stmt_t->fetchColumn() ?: null;

// Fetch active academic year
$stmt_ay = $pdo->query("SELECT id, name FROM academic_years WHERE is_active = 1 LIMIT 1");
$active_year = $stmt_ay->fetch() ?: ['id' => 1, 'name' => '2025-2026'];

$classes = $pdo->query("SELECT id, name FROM classes ORDER BY name ASC")->fetchAll();
$subjects = $pdo->query("SELECT id, name, code FROM subjects ORDER BY name ASC")->fetchAll();

$class_id = (int)($_GET['class_id'] ?? ($classes[0]['id'] ?? 0));
$subject_id = (int)($_GET['subject_id'] ?? ($subjects[0]['id'] ?? 0));
$term = sanitize_input($_GET['term'] ?? 'Term 1');
$exam_type = sanitize_input($_GET['exam_type'] ?? 'End of Term Exam');

// Handle Marks Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_marks') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf)) {
        set_flash('danger', 'Security validation mismatch.');
        header("Location: marks.php?class_id={$class_id}&subject_id={$subject_id}&term={$term}&exam_type={$exam_type}");
        exit;
    }

    $sub_class_id = (int)$_POST['class_id'];
    $sub_subject_id = (int)$_POST['subject_id'];
    $sub_term = sanitize_input($_POST['term']);
    $sub_exam_type = sanitize_input($_POST['exam_type']);
    $max_marks = max(1, (float)($_POST['max_marks'] ?? 100));

    $marks_data = $_POST['marks'] ?? [];
    $remarks_data = $_POST['remarks'] ?? [];

    if (!empty($marks_data)) {
        $stmt_ins = $pdo->prepare("
            INSERT INTO marks (student_id, subject_id, teacher_id, academic_year_id, term, exam_type, marks_obtained, max_marks, grade, remarks)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE 
                marks_obtained = VALUES(marks_obtained),
                max_marks = VALUES(max_marks),
                grade = VALUES(grade),
                remarks = VALUES(remarks),
                teacher_id = VALUES(teacher_id)
        ");

        $saved_count = 0;
        foreach ($marks_data as $stu_id => $raw_mark) {
            $stu_id = (int)$stu_id;
            if ($raw_mark === '' || $raw_mark === null) continue;

            $mark_obtained = min(max(0, (float)$raw_mark), $max_marks);
            $pct = ($mark_obtained / $max_marks) * 100;
            $grade = calculate_grade($pct);
            $remark = sanitize_input($remarks_data[$stu_id] ?? '');

            $stmt_ins->execute([
                $stu_id,
                $sub_subject_id,
                $teacher_id,
                $active_year['id'],
                $sub_term,
                $sub_exam_type,
                $mark_obtained,
                $max_marks,
                $grade,
                $remark
            ]);
            $saved_count++;
        }

        log_audit($pdo, $current_user['id'], 'MARKS_RECORDED', "Recorded marks for {$saved_count} students in Subject #{$sub_subject_id}, Class #{$sub_class_id} ({$sub_exam_type} - {$sub_term})");
        set_flash('success', "Marks and grades recorded for {$saved_count} pupils successfully.");
        header("Location: marks.php?class_id={$sub_class_id}&subject_id={$sub_subject_id}&term={$sub_term}&exam_type={$sub_exam_type}");
        exit;
    }
}

// Fetch Pupils in selected class
$students = [];
if ($class_id > 0) {
    $stmt_s = $pdo->prepare("SELECT id, student_id_number, first_name, last_name, gender FROM students WHERE class_id = ? AND status = 'Active' ORDER BY last_name ASC");
    $stmt_s->execute([$class_id]);
    $students = $stmt_s->fetchAll();
}

// Fetch existing marks for this class, subject, term, exam_type
$existing_marks = [];
$current_max_marks = 100;
if ($class_id > 0 && $subject_id > 0) {
    $stmt_m = $pdo->prepare("
        SELECT student_id, marks_obtained, max_marks, grade, remarks 
        FROM marks 
        WHERE subject_id = ? AND term = ? AND exam_type = ? AND student_id IN (
            SELECT id FROM students WHERE class_id = ?
        )
    ");
    $stmt_m->execute([$subject_id, $term, $exam_type, $class_id]);
    while ($row = $stmt_m->fetch()) {
        $existing_marks[$row['student_id']] = $row;
        $current_max_marks = (float)$row['max_marks'];
    }
}

$page_title = "Record Exam Marks - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">Marks & Continuous Assessment Entry</h1>
            <p class="page-subtitle">Input marks, auto-compute standard grades (A–F), and track pupil performance</p>
        </div>
        <div style="display: flex; gap: 8px;">
            <a href="../admin/reports.php?class_id=<?= $class_id ?>" class="btn btn-outline btn-sm">
                View Class Report Sheet
            </a>
        </div>
    </div>

    <!-- Filter Configuration Toolbar (no-print) -->
    <div class="card no-print" style="margin-bottom: 24px;">
        <div class="card-body" style="padding: 16px 20px;">
            <form method="GET" action="marks.php" style="display: flex; gap: 14px; flex-wrap: wrap; align-items: flex-end;">
                <div style="flex: 1; min-width: 180px;">
                    <label class="form-label">Class Stream</label>
                    <select name="class_id" class="form-select" onchange="this.form.submit()">
                        <?php foreach ($classes as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= $class_id === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="flex: 1; min-width: 180px;">
                    <label class="form-label">Subject</label>
                    <select name="subject_id" class="form-select" onchange="this.form.submit()">
                        <?php foreach ($subjects as $s): ?>
                            <option value="<?= $s['id'] ?>" <?= $subject_id === (int)$s['id'] ? 'selected' : '' ?>><?= e($s['name']) ?> (<?= e($s['code']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="min-width: 130px;">
                    <label class="form-label">Term</label>
                    <select name="term" class="form-select" onchange="this.form.submit()">
                        <option value="Term 1" <?= $term === 'Term 1' ? 'selected' : '' ?>>Term 1</option>
                        <option value="Term 2" <?= $term === 'Term 2' ? 'selected' : '' ?>>Term 2</option>
                        <option value="Term 3" <?= $term === 'Term 3' ? 'selected' : '' ?>>Term 3</option>
                    </select>
                </div>

                <div style="min-width: 170px;">
                    <label class="form-label">Exam Assessment</label>
                    <select name="exam_type" class="form-select" onchange="this.form.submit()">
                        <option value="Beginning of Term" <?= $exam_type === 'Beginning of Term' ? 'selected' : '' ?>>Beginning of Term</option>
                        <option value="Mid-Term Exam" <?= $exam_type === 'Mid-Term Exam' ? 'selected' : '' ?>>Mid-Term Exam</option>
                        <option value="End of Term Exam" <?= $exam_type === 'End of Term Exam' ? 'selected' : '' ?>>End of Term Exam</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary" style="height: 42px;">Load Students</button>
            </form>
        </div>
    </div>

    <!-- Official Grading Scale Reference Banner -->
    <div style="background: var(--slate-100); border: 1px solid var(--slate-200); border-radius: var(--radius-md); padding: 12px 18px; margin-bottom: 20px; display: flex; gap: 16px; flex-wrap: wrap; align-items: center; font-size: 13px;">
        <span style="font-weight: 700; color: var(--slate-700);">Grading Criteria:</span>
        <span><span class="badge badge-approved">Grade A</span> 80% – 100% (Excellent)</span>
        <span><span class="badge badge-approved">Grade B</span> 70% – 79% (Very Good)</span>
        <span><span class="badge badge-pending">Grade C</span> 60% – 69% (Good)</span>
        <span><span class="badge badge-pending">Grade D</span> 50% – 59% (Pass)</span>
        <span><span class="badge badge-danger">Grade F</span> Below 50% (Fail)</span>
    </div>

    <!-- Marks Entry Sheet Table -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Marks Roster: <?= e($term) ?> — <?= e($exam_type) ?></h3>
            <span class="badge badge-primary"><?= count($students) ?> Pupils in class</span>
        </div>
        <div class="card-body" style="padding: 0;">
            <?php if (empty($students)): ?>
                <div style="padding: 32px; text-align: center; color: var(--slate-500);">
                    No active students enrolled in this class.
                </div>
            <?php else: ?>
                <form action="marks.php?class_id=<?= $class_id ?>&subject_id=<?= $subject_id ?>&term=<?= $term ?>&exam_type=<?= $exam_type ?>" method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="save_marks">
                    <input type="hidden" name="class_id" value="<?= $class_id ?>">
                    <input type="hidden" name="subject_id" value="<?= $subject_id ?>">
                    <input type="hidden" name="term" value="<?= e($term) ?>">
                    <input type="hidden" name="exam_type" value="<?= e($exam_type) ?>">

                    <div style="padding: 14px 20px; background: #f8fafc; border-bottom: 1px solid var(--slate-200); display: flex; align-items: center; gap: 12px;">
                        <label class="form-label" style="margin: 0; font-size: 13px;">Assessment Maximum Marks:</label>
                        <input type="number" name="max_marks" id="assessmentMaxMarks" class="form-control" style="width: 100px; padding: 6px 10px;" value="<?= $current_max_marks ?>" min="1" max="1000" required>
                    </div>

                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th style="width: 5%;">#</th>
                                    <th style="width: 25%;">Pupil Name</th>
                                    <th style="width: 18%;">Marks Obtained</th>
                                    <th style="width: 15%;">Calculated Grade</th>
                                    <th style="width: 27%;">Teacher Remarks</th>
                                    <th style="width: 10%;">Bulletin</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $idx = 1; foreach ($students as $stu): ?>
                                    <?php 
                                        $rec = $existing_marks[$stu['id']] ?? null;
                                        $val = $rec ? $rec['marks_obtained'] : '';
                                        $grade = $rec ? $rec['grade'] : '-';
                                        $remark = $rec ? $rec['remarks'] : '';
                                    ?>
                                    <tr>
                                        <td><?= $idx++ ?></td>
                                        <td>
                                            <strong><?= e($stu['first_name'] . ' ' . $stu['last_name']) ?></strong>
                                            <div style="font-size: 11.5px; color: var(--slate-500);"><?= e($stu['student_id_number']) ?></div>
                                        </td>
                                        <td>
                                            <input type="number" step="0.5" min="0" max="<?= $current_max_marks ?>" 
                                                   name="marks[<?= $stu['id'] ?>]" 
                                                   class="form-control mark-input-field" 
                                                   data-max="<?= $current_max_marks ?>" 
                                                   placeholder="0 - <?= $current_max_marks ?>" 
                                                   value="<?= $val !== '' ? number_format((float)$val, 1) : '' ?>">
                                        </td>
                                        <td>
                                            <span class="badge grade-badge-preview badge-<?= $grade === 'A' || $grade === 'B' ? 'approved' : ($grade === 'C' || $grade === 'D' ? 'pending' : ($grade === 'F' ? 'danger' : 'outline')) ?>">
                                                <?= e($grade) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <input type="text" name="remarks[<?= $stu['id'] ?>]" class="form-control" style="font-size: 12.5px; padding: 6px 10px;" placeholder="Optional remark" value="<?= e($remark) ?>">
                                        </td>
                                        <td>
                                            <a href="../admin/reports.php?type=student&student_id=<?= $stu['id'] ?>&term=<?= $term ?>" class="btn btn-outline btn-sm" target="_blank" title="Preview Terminal Bulletin">
                                                Card
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div style="padding: 16px 20px; background: var(--slate-50); border-top: 1px solid var(--slate-200); display: flex; justify-content: flex-end;">
                        <button type="submit" class="btn btn-primary btn-lg">
                            Save Marks & Auto-Calculate Grades
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
