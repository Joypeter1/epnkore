<?php
/**
 * EP NKORE - School Management System
 * Daily Attendance Register & Tracking System
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, ['Teacher', 'Head Teacher', 'Administrator']);

$classes = $pdo->query("SELECT id, name FROM classes ORDER BY name ASC")->fetchAll();

$class_id = (int)($_GET['class_id'] ?? ($classes[0]['id'] ?? 0));
$attendance_date = sanitize_input($_GET['date'] ?? date('Y-m-d'));

// Handle Attendance Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_attendance') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf)) {
        set_flash('danger', 'Security validation failed.');
        header("Location: attendance.php?class_id={$class_id}&date={$attendance_date}");
        exit;
    }

    $sub_class_id = (int)$_POST['class_id'];
    $sub_date = sanitize_input($_POST['attendance_date']);
    $attendance_data = $_POST['attendance'] ?? [];
    $remarks_data = $_POST['remarks'] ?? [];

    if (!empty($attendance_data)) {
        $stmt_ins = $pdo->prepare("
            INSERT INTO attendance (student_id, class_id, attendance_date, status, remarks, recorded_by)
            VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE status = VALUES(status), remarks = VALUES(remarks), recorded_by = VALUES(recorded_by)
        ");

        $count = 0;
        foreach ($attendance_data as $stu_id => $status) {
            $stu_id = (int)$stu_id;
            $remark = sanitize_input($remarks_data[$stu_id] ?? '');
            $valid_status = in_array($status, ['Present', 'Absent', 'Late', 'Excused']) ? $status : 'Present';

            $stmt_ins->execute([$stu_id, $sub_class_id, $sub_date, $valid_status, $remark, $current_user['id']]);
            $count++;
        }

        log_audit($pdo, $current_user['id'], 'ATTENDANCE_SAVED', "Recorded roll call for class ID {$sub_class_id} on {$sub_date} ({$count} pupils)");
        set_flash('success', "Attendance successfully saved for {$count} pupils on " . date('M d, Y', strtotime($sub_date)) . ".");
        header("Location: attendance.php?class_id={$sub_class_id}&date={$sub_date}");
        exit;
    }
}

// Fetch Pupils in selected class
$students = [];
if ($class_id > 0) {
    $stmt_stu = $pdo->prepare("SELECT id, student_id_number, first_name, last_name, gender FROM students WHERE class_id = ? AND status = 'Active' ORDER BY last_name ASC, first_name ASC");
    $stmt_stu->execute([$class_id]);
    $students = $stmt_stu->fetchAll();
}

// Fetch existing attendance records for selected class & date
$existing_attendance = [];
if ($class_id > 0 && !empty($attendance_date)) {
    $stmt_att = $pdo->prepare("SELECT student_id, status, remarks FROM attendance WHERE class_id = ? AND attendance_date = ?");
    $stmt_att->execute([$class_id, $attendance_date]);
    while ($r = $stmt_att->fetch()) {
        $existing_attendance[$r['student_id']] = [
            'status' => $r['status'],
            'remarks' => $r['remarks']
        ];
    }
}

// Summary stats for current roll call
$summary = ['Present' => 0, 'Absent' => 0, 'Late' => 0, 'Excused' => 0, 'Unmarked' => 0];
foreach ($students as $stu) {
    if (isset($existing_attendance[$stu['id']])) {
        $st = $existing_attendance[$stu['id']]['status'];
        if (isset($summary[$st])) $summary[$st]++;
    } else {
        $summary['Unmarked']++;
    }
}

$page_title = "Class Attendance - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">Daily Attendance Register</h1>
            <p class="page-subtitle">Track classroom attendance, absenteeism, and excused absences</p>
        </div>
        <div style="display: flex; gap: 8px;">
            <button type="button" class="btn btn-outline btn-sm btn-print-trigger">
                Print Register
            </button>
        </div>
    </div>

    <!-- Class & Date Selection Toolbar (no-print) -->
    <div class="card no-print" style="margin-bottom: 24px;">
        <div class="card-body" style="padding: 16px 20px;">
            <form method="GET" action="attendance.php" style="display: flex; gap: 14px; flex-wrap: wrap; align-items: flex-end;">
                <div style="flex: 1; min-width: 200px;">
                    <label class="form-label">Select Class Stream</label>
                    <select name="class_id" class="form-select" onchange="this.form.submit()">
                        <?php foreach ($classes as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= $class_id === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="min-width: 180px;">
                    <label class="form-label">Attendance Date</label>
                    <input type="date" name="date" class="form-control" value="<?= e($attendance_date) ?>" onchange="this.form.submit()">
                </div>

                <button type="submit" class="btn btn-primary" style="height: 42px;">Load Register</button>
            </form>
        </div>
    </div>

    <!-- Attendance Summary Statistics Pills -->
    <div style="display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 20px;">
        <div style="background: #ecfdf5; border: 1px solid #a7f3d0; padding: 10px 16px; border-radius: 8px; font-size: 13.5px;">
            <strong style="color: #065f46;">Present:</strong> <?= $summary['Present'] ?>
        </div>
        <div style="background: #fef2f2; border: 1px solid #fecaca; padding: 10px 16px; border-radius: 8px; font-size: 13.5px;">
            <strong style="color: #991b1b;">Absent:</strong> <?= $summary['Absent'] ?>
        </div>
        <div style="background: #fffbeb; border: 1px solid #fde68a; padding: 10px 16px; border-radius: 8px; font-size: 13.5px;">
            <strong style="color: #92400e;">Late:</strong> <?= $summary['Late'] ?>
        </div>
        <div style="background: #eff6ff; border: 1px solid #bfdbfe; padding: 10px 16px; border-radius: 8px; font-size: 13.5px;">
            <strong style="color: #1e40af;">Excused:</strong> <?= $summary['Excused'] ?>
        </div>
        <?php if ($summary['Unmarked'] > 0): ?>
            <div style="background: var(--slate-100); border: 1px solid var(--slate-200); padding: 10px 16px; border-radius: 8px; font-size: 13.5px;">
                <strong>Unrecorded:</strong> <?= $summary['Unmarked'] ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Roll Call Form Table -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Roll Call Sheet — <?= date('F d, Y', strtotime($attendance_date)) ?></h3>
            <div class="no-print">
                <button type="button" id="markAllPresentBtn" class="btn btn-outline btn-sm">
                    ✓ Mark All Present
                </button>
            </div>
        </div>
        <div class="card-body" style="padding: 0;">
            <?php if (empty($students)): ?>
                <div style="padding: 32px; text-align: center; color: var(--slate-500);">
                    No active students enrolled in this class.
                </div>
            <?php else: ?>
                <form action="attendance.php?class_id=<?= $class_id ?>&date=<?= $attendance_date ?>" method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="save_attendance">
                    <input type="hidden" name="class_id" value="<?= $class_id ?>">
                    <input type="hidden" name="attendance_date" value="<?= e($attendance_date) ?>">

                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th style="width: 5%;">#</th>
                                    <th style="width: 28%;">Student Name</th>
                                    <th style="width: 42%;">Attendance Status</th>
                                    <th style="width: 25%;">Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $idx = 1; foreach ($students as $stu): ?>
                                    <?php 
                                        $current_st = $existing_attendance[$stu['id']]['status'] ?? 'Present';
                                        $current_rm = $existing_attendance[$stu['id']]['remarks'] ?? '';
                                    ?>
                                    <tr>
                                        <td><?= $idx++ ?></td>
                                        <td>
                                            <strong><?= e($stu['first_name'] . ' ' . $stu['last_name']) ?></strong>
                                            <div style="font-size: 11.5px; color: var(--slate-500);"><?= e($stu['student_id_number']) ?></div>
                                        </td>
                                        <td>
                                            <div class="attendance-options">
                                                <label class="att-option opt-present">
                                                    <input type="radio" name="attendance[<?= $stu['id'] ?>]" value="Present" <?= $current_st === 'Present' ? 'checked' : '' ?>>
                                                    <span>Present</span>
                                                </label>
                                                <label class="att-option opt-absent">
                                                    <input type="radio" name="attendance[<?= $stu['id'] ?>]" value="Absent" <?= $current_st === 'Absent' ? 'checked' : '' ?>>
                                                    <span>Absent</span>
                                                </label>
                                                <label class="att-option opt-late">
                                                    <input type="radio" name="attendance[<?= $stu['id'] ?>]" value="Late" <?= $current_st === 'Late' ? 'checked' : '' ?>>
                                                    <span>Late</span>
                                                </label>
                                                <label class="att-option opt-excused">
                                                    <input type="radio" name="attendance[<?= $stu['id'] ?>]" value="Excused" <?= $current_st === 'Excused' ? 'checked' : '' ?>>
                                                    <span>Excused</span>
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <input type="text" name="remarks[<?= $stu['id'] ?>]" class="form-control" style="font-size: 12.5px; padding: 6px 10px;" placeholder="Optional remarks" value="<?= e($current_rm) ?>">
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div style="padding: 16px 20px; background: var(--slate-50); border-top: 1px solid var(--slate-200); display: flex; justify-content: flex-end;">
                        <button type="submit" class="btn btn-primary btn-lg">
                            Save Attendance Record
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
