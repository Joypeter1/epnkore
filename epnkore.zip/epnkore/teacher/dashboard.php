<?php
/**
 * EP NKORE - School Management System
 * Teacher Workspace & Daily Classroom Dashboard
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, ['Teacher', 'Head Teacher', 'Administrator']);

// Fetch Teacher Profile ID for the logged in user
$stmt_t = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$stmt_t->execute([$current_user['id']]);
$teacher_profile = $stmt_t->fetch();

$teacher_id = $teacher_profile['id'] ?? 0;

// Fetch teacher's assigned classes and subjects
$assignments = [];
if ($teacher_id > 0) {
    $stmt_as = $pdo->prepare("
        SELECT ts.id as assignment_id, s.id as subject_id, s.name as subject_name, s.code as subject_code,
               c.id as class_id, c.name as class_name, c.stream as class_stream,
               (SELECT COUNT(*) FROM students stu WHERE stu.class_id = c.id AND stu.status = 'Active') as enrolled_pupils
        FROM teacher_subjects ts
        JOIN subjects s ON ts.subject_id = s.id
        JOIN classes c ON ts.class_id = c.id
        WHERE ts.teacher_id = ?
        ORDER BY c.name ASC
    ");
    $stmt_as->execute([$teacher_id]);
    $assignments = $stmt_as->fetchAll();
}

// If admin/headteacher testing teacher view or no specific assignments, fetch general classes
$all_classes = $pdo->query("SELECT id, name FROM classes ORDER BY name ASC")->fetchAll();

$today_date = date('Y-m-d');

$page_title = "Teacher Dashboard - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">Teacher Workspace</h1>
            <p class="page-subtitle">Welcome, <?= e($current_user['first_name'] . ' ' . $current_user['last_name']) ?>. Manage student marks, daily attendance, and classroom rosters.</p>
        </div>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <a href="attendance.php" class="btn btn-primary btn-sm">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                Mark Attendance
            </a>
            <a href="marks.php" class="btn btn-success btn-sm">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                Enter Exam Marks
            </a>
        </div>
    </div>

    <!-- Quick Action Cards Grid -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-info">
                <span class="stat-label">Assigned Classes</span>
                <span class="stat-value"><?= count($assignments) ?></span>
                <span class="stat-subtext">Active Teaching Streams</span>
            </div>
            <div class="stat-icon blue">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-info">
                <span class="stat-label">Teacher Code</span>
                <span class="stat-value" style="font-size: 20px;"><?= e($teacher_profile['teacher_code'] ?? 'TCH-STAFF') ?></span>
                <span class="stat-subtext">EP NKORE Faculty</span>
            </div>
            <div class="stat-icon emerald">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-info">
                <span class="stat-label">Specialization</span>
                <span class="stat-value" style="font-size: 18px;"><?= e($teacher_profile['specialization'] ?? 'General') ?></span>
                <span class="stat-subtext"><?= e($teacher_profile['qualification'] ?? 'Certified Educator') ?></span>
            </div>
            <div class="stat-icon purple">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
            </div>
        </div>
    </div>

    <!-- Assigned Classes & Subjects -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-header">
            <h3 class="card-title">My Assigned Classes & Teaching Curriculum</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <?php if (empty($assignments)): ?>
                <div style="padding: 32px; text-align: center; color: var(--slate-500);">
                    <p>No direct classroom assignments assigned yet. Contact the Head Teacher or Administrator.</p>
                    <p style="font-size: 13px; margin-top: 4px;">You can still access attendance marking and marks entry for any school class below:</p>
                    <div style="margin-top: 12px;">
                        <a href="attendance.php" class="btn btn-primary btn-sm">Open Attendance Register</a>
                        <a href="marks.php" class="btn btn-secondary btn-sm">Open Marks Register</a>
                    </div>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Class Stream</th>
                                <th>Subject Taught</th>
                                <th>Enrolled Pupils</th>
                                <th>Quick Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($assignments as $a): ?>
                                <tr>
                                    <td><strong><?= e($a['class_name']) ?></strong> (<?= e($a['class_stream'] ?: 'Main') ?>)</td>
                                    <td><span class="badge badge-primary"><?= e($a['subject_name']) ?> (<?= e($a['subject_code']) ?>)</span></td>
                                    <td><?= (int)$a['enrolled_pupils'] ?> Active Pupils</td>
                                    <td>
                                        <div style="display: flex; gap: 6px;">
                                            <a href="attendance.php?class_id=<?= $a['class_id'] ?>" class="btn btn-outline btn-sm">Roll Call</a>
                                            <a href="marks.php?class_id=<?= $a['class_id'] ?>&subject_id=<?= $a['subject_id'] ?>" class="btn btn-primary btn-sm">Record Marks</a>
                                            <a href="../admin/students.php?class_id=<?= $a['class_id'] ?>" class="btn btn-secondary btn-sm">Pupil List</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
