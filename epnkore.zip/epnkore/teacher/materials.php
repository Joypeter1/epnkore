<?php
/**
 * EP NKORE - School Management System
 * Teacher Learning Materials (Notes, Exercises, Homework Upload)
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, ['Teacher', 'Head Teacher', 'Administrator']);

$classes = $pdo->query("SELECT * FROM classes ORDER BY grade_level ASC")->fetchAll();
$subjects = $pdo->query("SELECT * FROM subjects ORDER BY name ASC")->fetchAll();

// Handle Material Upload & Deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    if (verify_csrf_token($csrf)) {
        $action = $_POST['action'];

        if ($action === 'upload_material') {
            $class_id = (int)($_POST['class_id'] ?? 0);
            $subject_id = (int)($_POST['subject_id'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $material_type = in_array($_POST['material_type'] ?? '', ['Notes', 'Exercise', 'Homework']) ? $_POST['material_type'] : 'Notes';
            $description = trim($_POST['description'] ?? '');
            $content_text = trim($_POST['content_text'] ?? '');
            $external_link = trim($_POST['external_link'] ?? '');
            $due_date = !empty($_POST['due_date']) ? $_POST['due_date'] : null;

            if (empty($title) || $class_id <= 0 || $subject_id <= 0) {
                set_flash('danger', 'Title, target class, and subject are required.');
            } else {
                $file_path = null;
                $file_name = null;

                // Handle file upload if provided
                if (isset($_FILES['material_file']) && $_FILES['material_file']['error'] === UPLOAD_ERR_OK) {
                    $file = $_FILES['material_file'];
                    $allowed_exts = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'txt', 'jpg', 'jpeg', 'png'];
                    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

                    if (in_array($ext, $allowed_exts)) {
                        $target_dir = __DIR__ . '/../uploads/materials/';
                        if (!is_dir($target_dir)) {
                            mkdir($target_dir, 0755, true);
                        }
                        $clean_name = preg_replace('/[^a-zA-Z0-9_-]/', '_', pathinfo($file['name'], PATHINFO_FILENAME));
                        $new_filename = time() . '_' . substr($clean_name, 0, 30) . '.' . $ext;
                        $destination = $target_dir . $new_filename;

                        if (move_uploaded_file($file['tmp_name'], $destination)) {
                            $file_path = 'uploads/materials/' . $new_filename;
                            $file_name = $file['name'];
                        }
                    } else {
                        set_flash('danger', 'Invalid file type. Allowed: PDF, Word, PowerPoint, Excel, Images, Text.');
                        header('Location: materials.php');
                        exit;
                    }
                }

                $stmt = $pdo->prepare("INSERT INTO learning_materials (teacher_id, class_id, subject_id, title, description, material_type, file_path, file_name, external_link, content_text, due_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$current_user['id'], $class_id, $subject_id, $title, $description, $material_type, $file_path, $file_name, $external_link, $content_text, $due_date]);
                $mat_id = $pdo->lastInsertId();

                log_audit($pdo, $current_user['id'], 'MATERIAL_UPLOAD', "Uploaded {$material_type} #{$mat_id}: {$title}");
                set_flash('success', "{$material_type} '<strong>" . e($title) . "</strong>' uploaded successfully for pupils.");
                header('Location: materials.php');
                exit;
            }
        } elseif ($action === 'delete_material') {
            $mat_id = (int)($_POST['material_id'] ?? 0);
            $chk = $pdo->prepare("SELECT file_path FROM learning_materials WHERE id = ?");
            $chk->execute([$mat_id]);
            $row = $chk->fetch();

            if ($row) {
                if (!empty($row['file_path']) && file_exists(__DIR__ . '/../' . $row['file_path'])) {
                    @unlink(__DIR__ . '/../' . $row['file_path']);
                }
                $del = $pdo->prepare("DELETE FROM learning_materials WHERE id = ?");
                $del->execute([$mat_id]);
                log_audit($pdo, $current_user['id'], 'MATERIAL_DELETED', "Deleted material #{$mat_id}");
                set_flash('success', 'Learning material removed successfully.');
            }
            header('Location: materials.php');
            exit;
        }
    }
}

// Fetch materials
$filter_class = (int)($_GET['class_id'] ?? 0);
$filter_type = trim($_GET['type'] ?? '');

$query = "SELECT m.*, c.name AS class_name, s.name AS subject_name, u.first_name, u.last_name 
          FROM learning_materials m
          JOIN classes c ON m.class_id = c.id
          JOIN subjects s ON m.subject_id = s.id
          JOIN users u ON m.teacher_id = u.id
          WHERE 1=1";

$params = [];
if ($current_user['role'] === 'Teacher') {
    $query .= " AND m.teacher_id = ?";
    $params[] = $current_user['id'];
}
if ($filter_class > 0) {
    $query .= " AND m.class_id = ?";
    $params[] = $filter_class;
}
if (!empty($filter_type)) {
    $query .= " AND m.material_type = ?";
    $params[] = $filter_type;
}
$query .= " ORDER BY m.id DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$materials = $stmt->fetchAll();

$page_title = "Manage Notes & Homework - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">Digital Learning Materials</h1>
            <p class="page-subtitle">Upload class notes, revision exercises, and homework for pupils to download and study</p>
        </div>
        <div>
            <a href="<?= get_base_url() ?>materials.php" target="_blank" class="btn btn-outline btn-sm">
                View Pupil Portal ↗
            </a>
            <button type="button" class="btn btn-primary btn-sm" onclick="document.getElementById('uploadFormCard').scrollIntoView({behavior: 'smooth'})">
                + Upload New Material
            </button>
        </div>
    </div>

    <!-- Filter Bar -->
    <div class="card" style="margin-bottom: 20px;">
        <div class="card-body" style="padding: 14px 20px;">
            <form action="materials.php" method="GET" style="display: flex; gap: 12px; align-items: flex-end; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 180px;">
                    <label class="form-label" style="font-size: 12px;">Filter by Class</label>
                    <select name="class_id" class="form-select">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= $filter_class == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div style="flex: 1; min-width: 160px;">
                    <label class="form-label" style="font-size: 12px;">Filter by Type</label>
                    <select name="type" class="form-select">
                        <option value="">All Types (Notes, Exercises, Homework)</option>
                        <option value="Notes" <?= $filter_type === 'Notes' ? 'selected' : '' ?>>Notes</option>
                        <option value="Exercise" <?= $filter_type === 'Exercise' ? 'selected' : '' ?>>Exercise</option>
                        <option value="Homework" <?= $filter_type === 'Homework' ? 'selected' : '' ?>>Homework</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary btn-sm">Filter</button>
                <a href="materials.php" class="btn btn-secondary btn-sm">Reset</a>
            </form>
        </div>
    </div>

    <!-- Materials Table -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-header">
            <h3 class="card-title">Uploaded Class Materials (<?= count($materials) ?>)</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Title & Description</th>
                            <th>Class & Subject</th>
                            <th>File / Attachment</th>
                            <th>Due Date</th>
                            <th>Uploaded On</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($materials)): ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 24px; color: #64748b;">
                                    No learning materials found. Use the upload form below to add notes or homework.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($materials as $m): ?>
                                <tr>
                                    <td>
                                        <span class="badge badge-<?= $m['material_type'] === 'Notes' ? 'info' : ($m['material_type'] === 'Homework' ? 'warning' : 'success') ?>">
                                            <?= e($m['material_type']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <strong><?= e($m['title']) ?></strong>
                                        <?php if (!empty($m['description'])): ?>
                                            <div style="font-size: 12px; color: #64748b;"><?= e($m['description']) ?></div>
                                        <?php endif; ?>
                                        <div style="font-size: 11px; color: #94a3b8;">By: <?= e($m['first_name'] . ' ' . $m['last_name']) ?></div>
                                    </td>
                                    <td>
                                        <div><?= e($m['class_name']) ?></div>
                                        <div style="font-size: 12px; color: #64748b;"><?= e($m['subject_name']) ?></div>
                                    </td>
                                    <td>
                                        <?php if (!empty($m['file_path'])): ?>
                                            <a href="<?= get_base_url() . e($m['file_path']) ?>" target="_blank" class="btn btn-outline btn-sm" style="font-size: 11px; padding: 4px 8px;">
                                                📥 Download <?= e(pathinfo($m['file_name'] ?? 'File', PATHINFO_EXTENSION)) ?>
                                            </a>
                                        <?php elseif (!empty($m['external_link'])): ?>
                                            <a href="<?= e($m['external_link']) ?>" target="_blank" class="btn btn-outline btn-sm" style="font-size: 11px; padding: 4px 8px;">
                                                🔗 Open Link
                                            </a>
                                        <?php else: ?>
                                            <span style="font-size: 12px; color: #64748b;">Text Only</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="font-size: 12px;">
                                        <?= !empty($m['due_date']) ? '<strong style="color: #dc2626;">' . date('M d, Y', strtotime($m['due_date'])) . '</strong>' : '<span style="color: #94a3b8;">N/A</span>' ?>
                                    </td>
                                    <td style="font-size: 12px; color: #64748b;">
                                        <?= date('M d, Y', strtotime($m['created_at'])) ?>
                                    </td>
                                    <td>
                                        <form action="materials.php" method="POST" onsubmit="return confirm('Permanently delete this material?');">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="action" value="delete_material">
                                            <input type="hidden" name="material_id" value="<?= $m['id'] ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Upload New Material Form Card -->
    <div class="card" id="uploadFormCard">
        <div class="card-header">
            <h3 class="card-title">+ Upload Notes, Exercises or Homework</h3>
        </div>
        <div class="card-body" style="padding: 24px;">
            <form action="materials.php" method="POST" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="upload_material">

                <div style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 16px; margin-bottom: 16px;">
                    <div>
                        <label class="form-label">Material Title *</label>
                        <input type="text" name="title" class="form-control" placeholder="e.g. P6 Mathematics Term 1 Fractions & Decimals" required>
                    </div>
                    <div>
                        <label class="form-label">Category / Type *</label>
                        <select name="material_type" class="form-select" required>
                            <option value="Notes">Notes (Amanota y'isomo)</option>
                            <option value="Exercise">Exercise (Imyitozo)</option>
                            <option value="Homework">Homework (Umukoro wo mu rugo)</option>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Target Class *</label>
                        <select name="class_id" class="form-select" required>
                            <option value="">Select Class...</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?= $c['id'] ?>"><?= e($c['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Subject *</label>
                        <select name="subject_id" class="form-select" required>
                            <option value="">Select Subject...</option>
                            <?php foreach ($subjects as $s): ?>
                                <option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
                    <div>
                        <label class="form-label">Attach Document File (PDF, DOCX, PPTX, Images)</label>
                        <input type="file" name="material_file" class="form-control" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.jpg,.jpeg,.png">
                        <small style="color: #64748b; font-size: 11px;">Max 20MB file size. Pupils can download directly.</small>
                    </div>
                    <div>
                        <label class="form-label">Submission Due Date (Optional for Homework/Exercises)</label>
                        <input type="date" name="due_date" class="form-control">
                    </div>
                </div>

                <div style="margin-bottom: 16px;">
                    <label class="form-label">External Link (Optional)</label>
                    <input type="url" name="external_link" class="form-control" placeholder="https://example.com/reb-elearning or Google Drive link">
                </div>

                <div style="margin-bottom: 16px;">
                    <label class="form-label">Brief Description</label>
                    <input type="text" name="description" class="form-control" placeholder="e.g. Complete questions 1 to 15 in your science notebook before Friday.">
                </div>

                <div style="margin-bottom: 20px;">
                    <label class="form-label">Full Text Content / Questions (Optional - for direct on-screen reading)</label>
                    <textarea name="content_text" class="form-control" rows="4" placeholder="You can type or paste the notes or exercise questions here directly so pupils can read them without downloading large files..."></textarea>
                </div>

                <button type="submit" class="btn btn-primary btn-lg">Publish Learning Material to Pupils</button>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
