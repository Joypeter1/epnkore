<?php
/**
 * EP NKORE - School Management System
 * Online Quizzes & Tests Management (Teacher & Admin)
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, ['Teacher', 'Head Teacher', 'Administrator']);

$classes = $pdo->query("SELECT * FROM classes ORDER BY grade_level ASC")->fetchAll();
$subjects = $pdo->query("SELECT * FROM subjects ORDER BY name ASC")->fetchAll();

// Handle Form Submissions: Create Quiz, Add Question, Delete Quiz
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    if (verify_csrf_token($csrf)) {
        $action = $_POST['action'];

        if ($action === 'create_quiz') {
            $class_id = (int)($_POST['class_id'] ?? 0);
            $subject_id = (int)($_POST['subject_id'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $instructions = trim($_POST['instructions'] ?? '');
            $duration = max(5, (int)($_POST['duration_minutes'] ?? 30));
            $show_immediately = isset($_POST['show_results_immediately']) ? 1 : 0;
            $auto_record = isset($_POST['auto_record_marks']) ? 1 : 0;
            $status = in_array($_POST['status'] ?? '', ['Draft', 'Published', 'Closed']) ? $_POST['status'] : 'Published';

            if (!empty($title) && $class_id > 0 && $subject_id > 0) {
                $stmt = $pdo->prepare("INSERT INTO quizzes (teacher_id, class_id, subject_id, title, instructions, duration_minutes, show_results_immediately, auto_record_marks, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$current_user['id'], $class_id, $subject_id, $title, $instructions, $duration, $show_immediately, $auto_record, $status]);
                $quiz_id = $pdo->lastInsertId();

                log_audit($pdo, $current_user['id'], 'QUIZ_CREATED', "Created online quiz #{$quiz_id}: {$title}");
                set_flash('success', "Online Quiz <strong>" . e($title) . "</strong> created! Now add your evaluation questions below.");
                header("Location: quizzes.php?quiz_id={$quiz_id}");
                exit;
            } else {
                set_flash('danger', 'Please provide a valid quiz title, class, and subject.');
            }
        } elseif ($action === 'add_question') {
            $quiz_id = (int)($_POST['quiz_id'] ?? 0);
            $q_text = trim($_POST['question_text'] ?? '');
            $opt_a = trim($_POST['option_a'] ?? '');
            $opt_b = trim($_POST['option_b'] ?? '');
            $opt_c = trim($_POST['option_c'] ?? '');
            $opt_d = trim($_POST['option_d'] ?? '');
            $correct = strtoupper(trim($_POST['correct_answer'] ?? 'A'));
            $points = (float)($_POST['points'] ?? 10.00);
            $explanation = trim($_POST['explanation'] ?? '');

            if ($quiz_id > 0 && !empty($q_text) && !empty($opt_a) && !empty($opt_b)) {
                $stmt = $pdo->prepare("INSERT INTO quiz_questions (quiz_id, question_text, option_a, option_b, option_c, option_d, correct_answer, points, explanation) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$quiz_id, $q_text, $opt_a, $opt_b, $opt_c, $opt_d, $correct, $points, $explanation]);

                // Recalculate total marks for the quiz
                $tot_stmt = $pdo->prepare("SELECT SUM(points) FROM quiz_questions WHERE quiz_id = ?");
                $tot_stmt->execute([$quiz_id]);
                $total_pts = (float)$tot_stmt->fetchColumn();
                $upd = $pdo->prepare("UPDATE quizzes SET total_marks = ? WHERE id = ?");
                $upd->execute([$total_pts, $quiz_id]);

                set_flash('success', "Question added successfully (Points: {$points}). Total Quiz Marks: {$total_pts} pts.");
                header("Location: quizzes.php?quiz_id={$quiz_id}");
                exit;
            } else {
                set_flash('danger', 'Question text and at least Options A and B are required.');
            }
        } elseif ($action === 'delete_question') {
            $q_id = (int)($_POST['question_id'] ?? 0);
            $quiz_id = (int)($_POST['quiz_id'] ?? 0);
            $del = $pdo->prepare("DELETE FROM quiz_questions WHERE id = ? AND quiz_id = ?");
            $del->execute([$q_id, $quiz_id]);

            $tot_stmt = $pdo->prepare("SELECT COALESCE(SUM(points), 0) FROM quiz_questions WHERE quiz_id = ?");
            $tot_stmt->execute([$quiz_id]);
            $total_pts = (float)$tot_stmt->fetchColumn();
            $upd = $pdo->prepare("UPDATE quizzes SET total_marks = ? WHERE id = ?");
            $upd->execute([$total_pts, $quiz_id]);

            set_flash('success', 'Question deleted successfully.');
            header("Location: quizzes.php?quiz_id={$quiz_id}");
            exit;
        } elseif ($action === 'delete_quiz') {
            $quiz_id = (int)($_POST['quiz_id'] ?? 0);
            $del = $pdo->prepare("DELETE FROM quizzes WHERE id = ?");
            $del->execute([$quiz_id]);
            log_audit($pdo, $current_user['id'], 'QUIZ_DELETED', "Deleted quiz #{$quiz_id}");
            set_flash('success', 'Quiz deleted permanently.');
            header("Location: quizzes.php");
            exit;
        }
    }
}

// Fetch quizzes list
$query = "SELECT q.*, c.name AS class_name, s.name AS subject_name, u.first_name, u.last_name,
                 (SELECT COUNT(*) FROM quiz_questions WHERE quiz_id = q.id) AS questions_count,
                 (SELECT COUNT(*) FROM quiz_attempts WHERE quiz_id = q.id) AS attempts_count
          FROM quizzes q
          JOIN classes c ON q.class_id = c.id
          JOIN subjects s ON q.subject_id = s.id
          JOIN users u ON q.teacher_id = u.id";

if ($current_user['role'] === 'Teacher') {
    $query .= " WHERE q.teacher_id = " . (int)$current_user['id'];
}
$query .= " ORDER BY q.id DESC";
$quizzes = $pdo->query($query)->fetchAll();

// Active Quiz selected for question editing
$selected_quiz_id = (int)($_GET['quiz_id'] ?? 0);
$selected_quiz = null;
$quiz_questions = [];
$quiz_attempts = [];

if ($selected_quiz_id > 0) {
    $sq_stmt = $pdo->prepare("SELECT q.*, c.name AS class_name, s.name AS subject_name FROM quizzes q JOIN classes c ON q.class_id = c.id JOIN subjects s ON q.subject_id = s.id WHERE q.id = ?");
    $sq_stmt->execute([$selected_quiz_id]);
    $selected_quiz = $sq_stmt->fetch();

    if ($selected_quiz) {
        $qq_stmt = $pdo->prepare("SELECT * FROM quiz_questions WHERE quiz_id = ? ORDER BY id ASC");
        $qq_stmt->execute([$selected_quiz_id]);
        $quiz_questions = $qq_stmt->fetchAll();

        $qa_stmt = $pdo->prepare("SELECT a.*, s.first_name, s.last_name, s.student_id AS reg_no 
                                 FROM quiz_attempts a 
                                 JOIN students s ON a.student_id = s.id 
                                 WHERE a.quiz_id = ? 
                                 ORDER BY a.score_obtained DESC");
        $qa_stmt->execute([$selected_quiz_id]);
        $quiz_attempts = $qa_stmt->fetchAll();
    }
}

$page_title = "Online Quizzes & Assessments - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">Online Quizzes & Assessments</h1>
            <p class="page-subtitle">Create digital tests, configure instant or hidden scoring, and auto-record grades</p>
        </div>
        <div>
            <button type="button" class="btn btn-primary btn-sm" onclick="document.getElementById('createQuizCard').scrollIntoView({behavior: 'smooth'})">
                + Create New Quiz
            </button>
        </div>
    </div>

    <!-- Active Quiz Questions & Attempts View if selected -->
    <?php if ($selected_quiz): ?>
        <div class="card" style="margin-bottom: 24px; border: 2px solid var(--primary);">
            <div class="card-header" style="background: #eff6ff; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                <div>
                    <span style="font-size: 11px; background: #2563eb; color: white; padding: 2px 8px; border-radius: 9999px; font-weight: 700; text-transform: uppercase;">
                        Active Quiz: #<?= $selected_quiz['id'] ?>
                    </span>
                    <h2 style="font-size: 18px; margin: 4px 0 2px; color: #1e3a8a; font-weight: 800;">
                        <?= e($selected_quiz['title']) ?>
                    </h2>
                    <div style="font-size: 12px; color: #64748b;">
                        <strong><?= e($selected_quiz['class_name']) ?></strong> • <?= e($selected_quiz['subject_name']) ?> • 
                        Duration: <strong><?= $selected_quiz['duration_minutes'] ?> Mins</strong> • 
                        Total Points: <strong><?= number_format($selected_quiz['total_marks'], 1) ?> pts</strong>
                    </div>
                </div>

                <div style="display: flex; gap: 8px; align-items: center;">
                    <a href="<?= get_base_url() ?>quiz_take.php?quiz_id=<?= $selected_quiz['id'] ?>" target="_blank" class="btn btn-warning btn-sm" style="display: flex; align-items: center; gap: 4px;">
                        <span>Take Test Live</span> ↗
                    </a>
                    <a href="quizzes.php" class="btn btn-secondary btn-sm">Close View</a>
                </div>
            </div>

            <div class="card-body" style="padding: 20px;">
                <!-- Quiz Configurations Badges -->
                <div style="display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 20px; padding: 12px; background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 12.5px;">
                    <div>
                        <strong>Instant Results:</strong> 
                        <?php if ($selected_quiz['show_results_immediately']): ?>
                            <span style="color: #059669; font-weight: 700;">✓ Yes (Pupils see scores & corrections immediately)</span>
                        <?php else: ?>
                            <span style="color: #d97706; font-weight: 700;">✕ Hidden (Scores hidden until teacher publishes)</span>
                        <?php endif; ?>
                    </div>
                    <div style="border-left: 1px solid #cbd5e1; padding-left: 12px;">
                        <strong>Auto-Record to Gradebook:</strong> 
                        <?php if ($selected_quiz['auto_record_marks']): ?>
                            <span style="color: #059669; font-weight: 700;">✓ Enabled (Grades automatically saved to student marks)</span>
                        <?php else: ?>
                            <span style="color: #64748b;">Disabled (Practice test only)</span>
                        <?php endif; ?>
                    </div>
                    <div style="border-left: 1px solid #cbd5e1; padding-left: 12px;">
                        <strong>Status:</strong> <span class="badge badge-success"><?= e($selected_quiz['status']) ?></span>
                    </div>
                </div>

                <!-- Tab Navigation between Questions and Student Submissions -->
                <div style="display: flex; gap: 10px; border-bottom: 2px solid #e2e8f0; margin-bottom: 20px;">
                    <button type="button" id="tabQuestionsBtn" class="btn btn-outline btn-sm" style="border-bottom: 3px solid #2563eb; font-weight: 700;" onclick="showQuizTab('questions')">
                        Questions (<?= count($quiz_questions) ?>)
                    </button>
                    <button type="button" id="tabAttemptsBtn" class="btn btn-outline btn-sm" style="font-weight: 700;" onclick="showQuizTab('attempts')">
                        Pupil Submissions / Results (<?= count($quiz_attempts) ?>)
                    </button>
                </div>

                <!-- Questions List & Add Form -->
                <div id="quizQuestionsTab">
                    <div style="display: grid; grid-template-columns: 1fr; gap: 16px; margin-bottom: 24px;">
                        <?php if (empty($quiz_questions)): ?>
                            <div style="padding: 30px; text-align: center; background: #f8fafc; border-radius: 8px; color: #64748b;">
                                No questions added yet. Use the form below to add your first question!
                            </div>
                        <?php else: ?>
                            <?php foreach ($quiz_questions as $index => $q): ?>
                                <div style="background: white; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
                                        <div style="font-weight: 700; color: #0f172a; font-size: 14px;">
                                            Question <?= $index + 1 ?>: <span style="font-weight: 500;"><?= e($q['question_text']) ?></span>
                                        </div>
                                        <div style="display: flex; gap: 8px; align-items: center;">
                                            <span style="background: #e0f2fe; color: #0369a1; padding: 2px 8px; border-radius: 4px; font-weight: 700; font-size: 11px;">
                                                <?= number_format($q['points'], 1) ?> pts
                                            </span>
                                            <form action="quizzes.php" method="POST" onsubmit="return confirm('Delete this question?');">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="action" value="delete_question">
                                                <input type="hidden" name="quiz_id" value="<?= $selected_quiz['id'] ?>">
                                                <input type="hidden" name="question_id" value="<?= $q['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm" style="padding: 2px 8px; font-size: 11px;">Delete</button>
                                            </form>
                                        </div>
                                    </div>

                                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 8px; margin-bottom: 10px; font-size: 13px;">
                                        <div style="padding: 8px; border-radius: 6px; background: <?= $q['correct_answer'] === 'A' ? '#dcfce7; border: 1px solid #86efac; font-weight: 700;' : '#f8fafc; border: 1px solid #e2e8f0;' ?>">
                                            <strong>A:</strong> <?= e($q['option_a']) ?> <?= $q['correct_answer'] === 'A' ? '✓ (Correct)' : '' ?>
                                        </div>
                                        <div style="padding: 8px; border-radius: 6px; background: <?= $q['correct_answer'] === 'B' ? '#dcfce7; border: 1px solid #86efac; font-weight: 700;' : '#f8fafc; border: 1px solid #e2e8f0;' ?>">
                                            <strong>B:</strong> <?= e($q['option_b']) ?> <?= $q['correct_answer'] === 'B' ? '✓ (Correct)' : '' ?>
                                        </div>
                                        <?php if (!empty($q['option_c'])): ?>
                                            <div style="padding: 8px; border-radius: 6px; background: <?= $q['correct_answer'] === 'C' ? '#dcfce7; border: 1px solid #86efac; font-weight: 700;' : '#f8fafc; border: 1px solid #e2e8f0;' ?>">
                                                <strong>C:</strong> <?= e($q['option_c']) ?> <?= $q['correct_answer'] === 'C' ? '✓ (Correct)' : '' ?>
                                            </div>
                                        <?php endif; ?>
                                        <?php if (!empty($q['option_d'])): ?>
                                            <div style="padding: 8px; border-radius: 6px; background: <?= $q['correct_answer'] === 'D' ? '#dcfce7; border: 1px solid #86efac; font-weight: 700;' : '#f8fafc; border: 1px solid #e2e8f0;' ?>">
                                                <strong>D:</strong> <?= e($q['option_d']) ?> <?= $q['correct_answer'] === 'D' ? '✓ (Correct)' : '' ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <?php if (!empty($q['explanation'])): ?>
                                        <div style="font-size: 12px; color: #475569; background: #f1f5f9; padding: 6px 10px; border-radius: 4px;">
                                            <strong>Explanation:</strong> <?= e($q['explanation']) ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                    <!-- Add New Question Form -->
                    <div style="background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 20px;">
                        <h3 style="font-size: 15px; font-weight: 700; margin-bottom: 12px; color: #1e293b;">
                            + Add Evaluation Question to this Quiz
                        </h3>
                        <form action="quizzes.php" method="POST">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="add_question">
                            <input type="hidden" name="quiz_id" value="<?= $selected_quiz['id'] ?>">

                            <div style="margin-bottom: 12px;">
                                <label class="form-label" style="font-size: 12px;">Question Text *</label>
                                <textarea name="question_text" class="form-control" rows="2" placeholder="e.g. Solve for x: 2x + 8 = 20" required></textarea>
                            </div>

                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px;">
                                <div>
                                    <label class="form-label" style="font-size: 12px;">Option A *</label>
                                    <input type="text" name="option_a" class="form-control" placeholder="Option A answer" required>
                                </div>
                                <div>
                                    <label class="form-label" style="font-size: 12px;">Option B *</label>
                                    <input type="text" name="option_b" class="form-control" placeholder="Option B answer" required>
                                </div>
                                <div>
                                    <label class="form-label" style="font-size: 12px;">Option C (Optional)</label>
                                    <input type="text" name="option_c" class="form-control" placeholder="Option C answer">
                                </div>
                                <div>
                                    <label class="form-label" style="font-size: 12px;">Option D (Optional)</label>
                                    <input type="text" name="option_d" class="form-control" placeholder="Option D answer">
                                </div>
                            </div>

                            <div style="display: grid; grid-template-columns: 1fr 1fr 2fr; gap: 12px; margin-bottom: 14px;">
                                <div>
                                    <label class="form-label" style="font-size: 12px;">Correct Answer *</label>
                                    <select name="correct_answer" class="form-select" required>
                                        <option value="A">Option A</option>
                                        <option value="B">Option B</option>
                                        <option value="C">Option C</option>
                                        <option value="D">Option D</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="form-label" style="font-size: 12px;">Points / Marks *</label>
                                    <input type="number" step="0.5" name="points" class="form-control" value="20" required>
                                </div>
                                <div>
                                    <label class="form-label" style="font-size: 12px;">Explanation (Feedback to student)</label>
                                    <input type="text" name="explanation" class="form-control" placeholder="Why this option is correct...">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">Save & Add Question</button>
                        </form>
                    </div>
                </div>

                <!-- Attempts & Grades Tab -->
                <div id="quizAttemptsTab" style="display: none;">
                    <?php if (empty($quiz_attempts)): ?>
                        <div style="padding: 30px; text-align: center; background: #f8fafc; border-radius: 8px; color: #64748b;">
                            No student submissions recorded yet. Share the live link with pupils!
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Student ID</th>
                                        <th>Student Name</th>
                                        <th>Score</th>
                                        <th>Percentage</th>
                                        <th>Auto-Recorded</th>
                                        <th>Submitted At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($quiz_attempts as $att): ?>
                                        <tr>
                                            <td><strong><?= e($att['reg_no']) ?></strong></td>
                                            <td><?= e($att['first_name'] . ' ' . $att['last_name']) ?></td>
                                            <td>
                                                <strong style="color: #0f172a;"><?= number_format($att['score_obtained'], 1) ?></strong> / <?= number_format($att['total_possible'], 1) ?> pts
                                            </td>
                                            <td>
                                                <span class="badge badge-<?= $att['percentage'] >= 50 ? 'success' : 'danger' ?>">
                                                    <?= number_format($att['percentage'], 1) ?>%
                                                </span>
                                            </td>
                                            <td>
                                                <?= $att['is_recorded'] ? '<span style="color: #059669; font-weight: 700;">✓ Gradebook</span>' : '<span style="color: #64748b;">Practice</span>' ?>
                                            </td>
                                            <td style="font-size: 12px; color: #64748b;">
                                                <?= date('M d, H:i', strtotime($att['submitted_at'])) ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Quizzes Table List -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-header">
            <h3 class="card-title">Available Quizzes & Online Tests (<?= count($quizzes) ?>)</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Quiz Title</th>
                            <th>Class & Subject</th>
                            <th>Duration</th>
                            <th>Questions</th>
                            <th>Instant Score</th>
                            <th>Auto-Record</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($quizzes)): ?>
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 24px; color: #64748b;">
                                    No quizzes created yet. Use the form below to create your first test.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($quizzes as $q): ?>
                                <tr>
                                    <td>
                                        <strong><?= e($q['title']) ?></strong>
                                        <div style="font-size: 11px; color: #64748b;">By: <?= e($q['first_name'] . ' ' . $q['last_name']) ?></div>
                                    </td>
                                    <td>
                                        <div><?= e($q['class_name']) ?></div>
                                        <div style="font-size: 12px; color: #64748b;"><?= e($q['subject_name']) ?></div>
                                    </td>
                                    <td><?= $q['duration_minutes'] ?> mins</td>
                                    <td>
                                        <span class="badge badge-info"><?= $q['questions_count'] ?> Qs</span>
                                        <span style="font-size: 11px; color: #64748b;">(<?= number_format($q['total_marks'], 0) ?> pts)</span>
                                    </td>
                                    <td>
                                        <?= $q['show_results_immediately'] ? '<span style="color: #059669; font-weight: 700;">Immediate</span>' : '<span style="color: #d97706; font-weight: 700;">Hidden</span>' ?>
                                    </td>
                                    <td>
                                        <?= $q['auto_record_marks'] ? '<span style="color: #059669; font-weight: 700;">Auto-Grade</span>' : '<span style="color: #64748b;">No</span>' ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?= $q['status'] === 'Published' ? 'success' : 'secondary' ?>"><?= e($q['status']) ?></span>
                                    </td>
                                    <td>
                                        <div style="display: flex; gap: 6px; align-items: center;">
                                            <a href="quizzes.php?quiz_id=<?= $q['id'] ?>" class="btn btn-primary btn-sm">
                                                Manage & Qs
                                            </a>
                                            <a href="<?= get_base_url() ?>quiz_take.php?quiz_id=<?= $q['id'] ?>" target="_blank" class="btn btn-warning btn-sm" title="Live Test Link">
                                                Take
                                            </a>
                                            <form action="quizzes.php" method="POST" onsubmit="return confirm('Delete this quiz and all its questions?');" style="display: inline-block;">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="action" value="delete_quiz">
                                                <input type="hidden" name="quiz_id" value="<?= $q['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Create Quiz Form Card -->
    <div class="card" id="createQuizCard">
        <div class="card-header">
            <h3 class="card-title">+ Create New Online Quiz or Test</h3>
        </div>
        <div class="card-body" style="padding: 24px;">
            <form action="quizzes.php" method="POST">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_quiz">

                <div style="display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 16px; margin-bottom: 16px;">
                    <div>
                        <label class="form-label">Quiz / Test Title *</label>
                        <input type="text" name="title" class="form-control" placeholder="e.g. Primary 5 Mathematics Evaluation" required>
                    </div>
                    <div>
                        <label class="form-label">Target Class *</label>
                        <select name="class_id" class="form-select" required>
                            <option value="">Select Class...</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?= $c['id'] ?>"><?= e($c['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Subject *</label>
                        <select name="subject_id" class="form-select" required>
                            <option value="">Select Subject...</option>
                            <?php foreach ($subjects as $s): ?>
                                <option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
                    <div>
                        <label class="form-label">Duration (Minutes) *</label>
                        <input type="number" name="duration_minutes" class="form-control" value="30" min="5" max="180" required>
                    </div>
                    <div>
                        <label class="form-label">Publishing Status</label>
                        <select name="status" class="form-select">
                            <option value="Published">Published (Students can take it)</option>
                            <option value="Draft">Draft (Hidden from students)</option>
                            <option value="Closed">Closed (Submissions ended)</option>
                        </select>
                    </div>
                </div>

                <div style="margin-bottom: 16px;">
                    <label class="form-label">Instructions for Pupils</label>
                    <textarea name="instructions" class="form-control" rows="2" placeholder="e.g. Read each question carefully and select the best answer. Calculators are not allowed."></textarea>
                </div>

                <!-- Core requested features: Instant Results & Auto-Record to marks -->
                <div style="background: #f0fdf4; border: 1px solid #86efac; border-radius: 8px; padding: 16px; margin-bottom: 20px;">
                    <h4 style="font-size: 13px; font-weight: 700; color: #166534; margin-bottom: 8px;">
                        Automatic Grading & Results Display Settings
                    </h4>
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px;">
                            <input type="checkbox" name="show_results_immediately" value="1" checked style="width: 18px; height: 18px;">
                            <span><strong>Show marks immediately to pupils</strong> (Abanyeshuri bamaze kubikora bahita babona amanota yabo ako kanya)</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px;">
                            <input type="checkbox" name="auto_record_marks" value="1" checked style="width: 18px; height: 18px;">
                            <span><strong>Auto-record marks into gradebook</strong> (Ayo manota ahite yiyandika mu buryo bwa automatique muri student marks)</span>
                        </label>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-lg">Create Quiz & Proceed to Questions</button>
            </form>
        </div>
    </div>
</div>

<script>
function showQuizTab(tab) {
    if (tab === 'questions') {
        document.getElementById('quizQuestionsTab').style.display = 'block';
        document.getElementById('quizAttemptsTab').style.display = 'none';
        document.getElementById('tabQuestionsBtn').style.borderBottom = '3px solid #2563eb';
        document.getElementById('tabAttemptsBtn').style.borderBottom = 'none';
    } else {
        document.getElementById('quizQuestionsTab').style.display = 'none';
        document.getElementById('quizAttemptsTab').style.display = 'block';
        document.getElementById('tabAttemptsBtn').style.borderBottom = '3px solid #2563eb';
        document.getElementById('tabQuestionsBtn').style.borderBottom = 'none';
    }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
