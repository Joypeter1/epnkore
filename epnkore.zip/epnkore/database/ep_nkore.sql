-- ==========================================================
-- EP NKORE - School Management System Database
-- Target Platform: MySQL 5.7+ / MySQL 8.0 / MariaDB (PHP 8.x)
-- Compatible with shared hosting: InfinityFree, cPanel, etc.
-- ==========================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- --------------------------------------------------------
-- Table structure for: users
-- --------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(100) NOT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(30) NOT NULL UNIQUE,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('Administrator', 'Head Teacher', 'Teacher') NOT NULL DEFAULT 'Teacher',
  `profile_photo` VARCHAR(255) DEFAULT 'default_avatar.png',
  `status` ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL DEFAULT 'PENDING',
  `must_change_password` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_users_phone` (`phone`),
  INDEX `idx_users_email` (`email`),
  INDEX `idx_users_status` (`status`),
  INDEX `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: otp_codes
-- --------------------------------------------------------
DROP TABLE IF EXISTS `otp_codes`;
CREATE TABLE `otp_codes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `otp_code` VARCHAR(10) NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `attempts` INT(11) NOT NULL DEFAULT 0,
  `is_used` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_otp_user` (`user_id`),
  INDEX `idx_otp_code` (`otp_code`),
  CONSTRAINT `fk_otp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: academic_years
-- --------------------------------------------------------
DROP TABLE IF EXISTS `academic_years`;
CREATE TABLE `academic_years` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL UNIQUE,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `is_current` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: terms
-- --------------------------------------------------------
DROP TABLE IF EXISTS `terms`;
CREATE TABLE `terms` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `academic_year_id` INT(11) NOT NULL,
  `name` VARCHAR(50) NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `is_current` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_terms_academic_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: classes
-- --------------------------------------------------------
DROP TABLE IF EXISTS `classes`;
CREATE TABLE `classes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `level` VARCHAR(50) NOT NULL,
  `class_teacher_id` INT(11) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_class_teacher` (`class_teacher_id`),
  CONSTRAINT `fk_class_teacher` FOREIGN KEY (`class_teacher_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: subjects
-- --------------------------------------------------------
DROP TABLE IF EXISTS `subjects`;
CREATE TABLE `subjects` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `code` VARCHAR(20) NOT NULL UNIQUE,
  `description` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_subjects_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: teachers
-- --------------------------------------------------------
DROP TABLE IF EXISTS `teachers`;
CREATE TABLE `teachers` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL UNIQUE,
  `teacher_code` VARCHAR(50) NOT NULL UNIQUE,
  `qualification` VARCHAR(150) DEFAULT NULL,
  `specialization` VARCHAR(150) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_teachers_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: teacher_subjects
-- --------------------------------------------------------
DROP TABLE IF EXISTS `teacher_subjects`;
CREATE TABLE `teacher_subjects` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_teacher_assignment` (`teacher_id`, `subject_id`, `class_id`),
  CONSTRAINT `fk_ts_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ts_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ts_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: students
-- --------------------------------------------------------
DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id_number` VARCHAR(50) NOT NULL UNIQUE,
  `first_name` VARCHAR(100) NOT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `gender` ENUM('Male', 'Female') NOT NULL,
  `dob` DATE NOT NULL,
  `parent_name` VARCHAR(150) NOT NULL,
  `parent_phone` VARCHAR(30) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `academic_year_id` INT(11) NOT NULL,
  `student_photo` VARCHAR(255) DEFAULT 'default_student.png',
  `status` ENUM('Active', 'Inactive', 'Transferred', 'Graduated') NOT NULL DEFAULT 'Active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_students_class` (`class_id`),
  INDEX `idx_students_status` (`status`),
  CONSTRAINT `fk_students_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_students_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: student_marks
-- --------------------------------------------------------
DROP TABLE IF EXISTS `student_marks`;
CREATE TABLE `student_marks` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `term_id` INT(11) NOT NULL,
  `academic_year_id` INT(11) NOT NULL,
  `assessment_type` VARCHAR(50) NOT NULL DEFAULT 'End of Term Exam',
  `marks` DECIMAL(5,2) NOT NULL,
  `max_marks` DECIMAL(5,2) NOT NULL DEFAULT 100.00,
  `teacher_id` INT(11) DEFAULT NULL,
  `date_recorded` DATE NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_student_mark` (`student_id`, `subject_id`, `term_id`, `assessment_type`),
  INDEX `idx_marks_student` (`student_id`),
  INDEX `idx_marks_class` (`class_id`),
  INDEX `idx_marks_subject` (`subject_id`),
  CONSTRAINT `fk_marks_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_marks_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_marks_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_marks_term` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: attendance
-- --------------------------------------------------------
DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `attendance_date` DATE NOT NULL,
  `status` ENUM('Present', 'Absent', 'Late', 'Excused') NOT NULL DEFAULT 'Present',
  `recorded_by` INT(11) DEFAULT NULL,
  `notes` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_daily_attendance` (`student_id`, `attendance_date`),
  INDEX `idx_attendance_class_date` (`class_id`, `attendance_date`),
  CONSTRAINT `fk_att_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_att_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: settings
-- --------------------------------------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `setting_key` VARCHAR(100) NOT NULL UNIQUE,
  `setting_value` TEXT NOT NULL,
  `description` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_settings_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: audit_logs
-- --------------------------------------------------------
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) DEFAULT NULL,
  `action` VARCHAR(100) NOT NULL,
  `details` TEXT DEFAULT NULL,
  `ip_address` VARCHAR(50) DEFAULT NULL,
  `user_agent` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_audit_user` (`user_id`),
  INDEX `idx_audit_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: quizzes (Online Tests & Quizzes)
-- --------------------------------------------------------
DROP TABLE IF EXISTS `quizzes`;
CREATE TABLE `quizzes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `instructions` TEXT DEFAULT NULL,
  `duration_minutes` INT(11) NOT NULL DEFAULT 30,
  `total_marks` DECIMAL(5,2) NOT NULL DEFAULT 100.00,
  `show_results_immediately` TINYINT(1) NOT NULL DEFAULT 1,
  `auto_record_marks` TINYINT(1) NOT NULL DEFAULT 1,
  `status` ENUM('Draft', 'Published', 'Closed') NOT NULL DEFAULT 'Published',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_quiz_class` (`class_id`),
  INDEX `idx_quiz_subject` (`subject_id`),
  CONSTRAINT `fk_quiz_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_quiz_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_quiz_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: quiz_questions
-- --------------------------------------------------------
DROP TABLE IF EXISTS `quiz_questions`;
CREATE TABLE `quiz_questions` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` INT(11) NOT NULL,
  `question_text` TEXT NOT NULL,
  `option_a` VARCHAR(255) NOT NULL,
  `option_b` VARCHAR(255) NOT NULL,
  `option_c` VARCHAR(255) DEFAULT NULL,
  `option_d` VARCHAR(255) DEFAULT NULL,
  `correct_answer` VARCHAR(10) NOT NULL,
  `points` DECIMAL(5,2) NOT NULL DEFAULT 20.00,
  `explanation` TEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_question_quiz` (`quiz_id`),
  CONSTRAINT `fk_qq_quiz` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: quiz_attempts
-- --------------------------------------------------------
DROP TABLE IF EXISTS `quiz_attempts`;
CREATE TABLE `quiz_attempts` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `score_obtained` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  `total_possible` DECIMAL(5,2) NOT NULL DEFAULT 100.00,
  `percentage` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  `answers_json` TEXT DEFAULT NULL,
  `is_recorded` TINYINT(1) NOT NULL DEFAULT 0,
  `submitted_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_attempt_quiz` (`quiz_id`),
  INDEX `idx_attempt_student` (`student_id`),
  CONSTRAINT `fk_qa_quiz` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qa_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: learning_materials (Notes, Exercises, Homework)
-- --------------------------------------------------------
DROP TABLE IF EXISTS `learning_materials`;
CREATE TABLE `learning_materials` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `material_type` ENUM('Notes', 'Exercise', 'Homework') NOT NULL DEFAULT 'Notes',
  `file_path` VARCHAR(255) DEFAULT NULL,
  `file_name` VARCHAR(255) DEFAULT NULL,
  `external_link` VARCHAR(255) DEFAULT NULL,
  `content_text` MEDIUMTEXT DEFAULT NULL,
  `due_date` DATE DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_mat_class` (`class_id`),
  INDEX `idx_mat_subject` (`subject_id`),
  CONSTRAINT `fk_mat_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mat_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mat_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for: news_updates (School News, Photos & Videos)
-- --------------------------------------------------------
DROP TABLE IF EXISTS `news_updates`;
CREATE TABLE `news_updates` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `author_id` INT(11) DEFAULT NULL,
  `title` VARCHAR(255) NOT NULL,
  `summary` VARCHAR(500) DEFAULT NULL,
  `content` MEDIUMTEXT NOT NULL,
  `media_type` ENUM('text', 'image', 'video') NOT NULL DEFAULT 'image',
  `image_url` VARCHAR(255) DEFAULT NULL,
  `video_url` VARCHAR(255) DEFAULT NULL,
  `is_published` TINYINT(1) NOT NULL DEFAULT 1,
  `published_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_news_pub` (`is_published`, `published_at`),
  CONSTRAINT `fk_news_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================================
-- SEED DATA
-- ==========================================================

-- Settings
INSERT INTO `settings` (`setting_key`, `setting_value`, `description`) VALUES
('school_name', 'EP NKORE', 'Official school name'),
('school_motto', 'Excellence, Discipline, and Innovation in Basic Education', 'School motto'),
('school_email', 'jeanpierret772@gmail.com', 'Official contact email'),
('school_phone', '+250781125809', 'Official contact telephone (Calls & WhatsApp)'),
('school_address', 'Nyamagabe District, Musange Sector, Masangano Cell, Gasagara Village, Rwanda', 'Physical campus address'),
('currency', 'RWF', 'Currency code'),
('grading_scale', '[{\"grade\":\"A\",\"min\":80,\"max\":100,\"remarks\":\"Distinction\"},{\"grade\":\"B\",\"min\":70,\"max\":79.99,\"remarks\":\"Very Good\"},{\"grade\":\"C\",\"min\":60,\"max\":69.99,\"remarks\":\"Good\"},{\"grade\":\"D\",\"min\":50,\"max\":59.99,\"remarks\":\"Pass\"},{\"grade\":\"F\",\"min\":0,\"max\":49.99,\"remarks\":\"Fail\"}]', 'Configurable grading thresholds');

-- Academic Years
INSERT INTO `academic_years` (`id`, `name`, `start_date`, `end_date`, `is_current`) VALUES
(1, '2025-2026', '2025-09-01', '2026-07-15', 1),
(2, '2024-2025', '2024-09-02', '2025-07-12', 0);

-- Terms
INSERT INTO `terms` (`id`, `academic_year_id`, `name`, `start_date`, `end_date`, `is_current`) VALUES
(1, 1, 'Term 1', '2025-09-01', '2025-12-15', 1),
(2, 1, 'Term 2', '2026-01-05', '2026-04-03', 0),
(3, 1, 'Term 3', '2026-04-20', '2026-07-15', 0);

-- Initial Users
-- Password for initial accounts is: Admin12345 (also supports Admin@Nkore2025)
INSERT INTO `users` (`id`, `first_name`, `last_name`, `phone`, `email`, `password_hash`, `role`, `profile_photo`, `status`, `must_change_password`) VALUES
(1, 'Jean Pierre', 'Administrator', '+250781125809', 'jeanpierret772@gmail.com', '$2y$10$jLs6ReHiWKzyjnjWTREHuOPPEQhdWFhDBajNcQ4T3mT1qj03OV3RS', 'Administrator', 'default_avatar.png', 'APPROVED', 0),
(2, 'Jean Paul', 'Habimana', '+250788000002', 'headteacher@epnkore.edu.rw', '$2y$10$jLs6ReHiWKzyjnjWTREHuOPPEQhdWFhDBajNcQ4T3mT1qj03OV3RS', 'Head Teacher', 'default_avatar.png', 'APPROVED', 0),
(3, 'Marie Claire', 'Uwase', '+250788000003', 'teacher@epnkore.edu.rw', '$2y$10$jLs6ReHiWKzyjnjWTREHuOPPEQhdWFhDBajNcQ4T3mT1qj03OV3RS', 'Teacher', 'default_avatar.png', 'APPROVED', 0),
(4, 'Eric', 'Nkurunziza', '+250788000004', 'pending.teacher@epnkore.edu.rw', '$2y$10$jLs6ReHiWKzyjnjWTREHuOPPEQhdWFhDBajNcQ4T3mT1qj03OV3RS', 'Teacher', 'default_avatar.png', 'PENDING', 0),
(5, 'Main', 'Administrator', '+250780000000', 'admin@epnkore.com', '$2y$10$jLs6ReHiWKzyjnjWTREHuOPPEQhdWFhDBajNcQ4T3mT1qj03OV3RS', 'Administrator', 'default_avatar.png', 'APPROVED', 0);

-- Teachers Profile
INSERT INTO `teachers` (`id`, `user_id`, `teacher_code`, `qualification`, `specialization`) VALUES
(1, 3, 'TCH-001', 'Bachelor of Education (Science)', 'Mathematics & Science'),
(2, 4, 'TCH-002', 'Diploma in Basic Education', 'English & Social Studies');

-- Classes
INSERT INTO `classes` (`id`, `name`, `level`, `class_teacher_id`) VALUES
(1, 'Primary 1 A', 'Lower Primary', 3),
(2, 'Primary 2 A', 'Lower Primary', NULL),
(3, 'Primary 3 A', 'Lower Primary', NULL),
(4, 'Primary 4 A', 'Upper Primary', NULL),
(5, 'Primary 5 A', 'Upper Primary', NULL),
(6, 'Primary 6 A', 'Upper Primary', 3);

-- Subjects
INSERT INTO `subjects` (`id`, `name`, `code`, `description`) VALUES
(1, 'Mathematics', 'MATH', 'Core numeracy, basic arithmetic and logical problem solving'),
(2, 'English Language', 'ENG', 'Grammar, reading comprehension and creative writing'),
(3, 'Kinyarwanda', 'KINY', 'National language, literature and cultural heritage'),
(4, 'Science & Elementary Technology', 'SET', 'Integrated natural sciences, health and digital basic skills'),
(5, 'Social & Religious Studies', 'SRS', 'Civics, geography, history and values'),
(6, 'Creative Arts & Physical Education', 'CAPE', 'Fine arts, music, dance and physical fitness'),
(7, 'French', 'FRN', 'Introductory communicative French');

-- Teacher Assigned Subjects
INSERT INTO `teacher_subjects` (`teacher_id`, `subject_id`, `class_id`) VALUES
(1, 1, 6), -- Marie Claire teaches Math in P6 A
(1, 4, 6), -- Marie Claire teaches SET in P6 A
(1, 1, 1); -- Marie Claire teaches Math in P1 A

-- Students
INSERT INTO `students` (`id`, `student_id_number`, `first_name`, `last_name`, `gender`, `dob`, `parent_name`, `parent_phone`, `class_id`, `academic_year_id`, `status`) VALUES
(1, 'STU-2025-001', 'Kevine', 'Ingabire', 'Female', '2013-04-12', 'Emmanuel Munyaneza', '+250788111222', 6, 1, 'Active'),
(2, 'STU-2025-002', 'Patrick', 'Mugisha', 'Male', '2013-08-25', 'Agnes Mukamana', '+250788333444', 6, 1, 'Active'),
(3, 'STU-2025-003', 'Divine', 'Uwera', 'Female', '2013-02-14', 'Francois Bizimana', '+250788555666', 6, 1, 'Active'),
(4, 'STU-2025-004', 'Aimable', 'Niyonkuru', 'Male', '2013-11-09', 'Chantal Uwimana', '+250788777888', 6, 1, 'Active'),
(5, 'STU-2025-005', 'Sandrine', 'Mutoni', 'Female', '2014-01-30', 'Joseph Hakizimana', '+250788999000', 6, 1, 'Active'),
(6, 'STU-2025-006', 'David', 'Kwizera', 'Male', '2017-06-18', 'Aline Uwamahoro', '+250789123456', 1, 1, 'Active'),
(7, 'STU-2025-007', 'Bella', 'Ineza', 'Female', '2017-09-05', 'Claude Ndahiro', '+250789654321', 1, 1, 'Active'),
(8, 'STU-2025-008', 'Cedrick', 'Manzi', 'Male', '2016-03-21', 'Beatrice Mukandori', '+250789789123', 2, 1, 'Active');

-- Sample Marks for P6 A Term 1
INSERT INTO `student_marks` (`student_id`, `subject_id`, `class_id`, `term_id`, `academic_year_id`, `assessment_type`, `marks`, `max_marks`, `teacher_id`, `date_recorded`) VALUES
(1, 1, 6, 1, 1, 'End of Term Exam', 88.50, 100.00, 1, '2025-12-10'),
(1, 4, 6, 1, 1, 'End of Term Exam', 92.00, 100.00, 1, '2025-12-10'),
(2, 1, 6, 1, 1, 'End of Term Exam', 74.00, 100.00, 1, '2025-12-10'),
(2, 4, 6, 1, 1, 'End of Term Exam', 81.50, 100.00, 1, '2025-12-10'),
(3, 1, 6, 1, 1, 'End of Term Exam', 95.00, 100.00, 1, '2025-12-10'),
(3, 4, 6, 1, 1, 'End of Term Exam', 90.00, 100.00, 1, '2025-12-10'),
(4, 1, 6, 1, 1, 'End of Term Exam', 62.50, 100.00, 1, '2025-12-10'),
(4, 4, 6, 1, 1, 'End of Term Exam', 68.00, 100.00, 1, '2025-12-10'),
(5, 1, 6, 1, 1, 'End of Term Exam', 84.00, 100.00, 1, '2025-12-10'),
(5, 4, 6, 1, 1, 'End of Term Exam', 87.50, 100.00, 1, '2025-12-10');

-- Sample Attendance for today
INSERT INTO `attendance` (`student_id`, `class_id`, `attendance_date`, `status`, `recorded_by`, `notes`) VALUES
(1, 6, CURDATE(), 'Present', 3, 'On time'),
(2, 6, CURDATE(), 'Present', 3, 'On time'),
(3, 6, CURDATE(), 'Late', 3, 'Arrived 15 mins late with parent note'),
(4, 6, CURDATE(), 'Absent', 3, 'Sick leave'),
(5, 6, CURDATE(), 'Present', 3, 'On time');

-- Initial Audit Log
INSERT INTO `audit_logs` (`user_id`, `action`, `details`, `ip_address`, `user_agent`) VALUES
(1, 'SYSTEM_INITIALIZED', 'EP NKORE database initialized successfully with standard schema and initial data.', '127.0.0.1', 'Installation Script');

-- Sample Online Quizzes / Tests
INSERT INTO `quizzes` (`id`, `teacher_id`, `class_id`, `subject_id`, `title`, `instructions`, `duration_minutes`, `total_marks`, `show_results_immediately`, `auto_record_marks`, `status`) VALUES
(1, 3, 6, 1, 'P6 Mathematics Term 1 Evaluation', 'Answer all 5 questions carefully. Each question carries 20 points. Calculators are not allowed.', 25, 100.00, 1, 1, 'Published'),
(2, 3, 6, 4, 'Science & Technology: Human Body Systems', 'Read each question and select the single best option. Results will be recorded into terminal assessment.', 20, 50.00, 0, 1, 'Published');

-- Sample Quiz Questions for Quiz #1 (Math)
INSERT INTO `quiz_questions` (`id`, `quiz_id`, `question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_answer`, `points`, `explanation`) VALUES
(1, 1, 'What is the value of 15% of 600 kg of beans?', '60 kg', '90 kg', '120 kg', '150 kg', 'B', 20.00, 'Calculation: (15 / 100) * 600 = 90 kg.'),
(2, 1, 'Solve for x: 3x + 12 = 45', 'x = 9', 'x = 11', 'x = 15', 'x = 19', 'B', 20.00, 'Calculation: 3x = 45 - 12 = 33 => x = 11.'),
(3, 1, 'Find the area of a right-angled triangle with base 8 cm and height 15 cm.', '120 cm²', '60 cm²', '46 cm²', '30 cm²', 'B', 20.00, 'Area = 1/2 * base * height = 0.5 * 8 * 15 = 60 cm².'),
(4, 1, 'What is the lowest common multiple (LCM) of 12 and 18?', '36', '72', '24', '48', 'A', 20.00, 'Multiples of 12: 12, 24, 36. Multiples of 18: 18, 36. LCM = 36.'),
(5, 1, 'A car travels 240 km in 3 hours. What is its average speed in km/h?', '60 km/h', '70 km/h', '80 km/h', '90 km/h', 'C', 20.00, 'Speed = Distance / Time = 240 / 3 = 80 km/h.');

-- Sample Quiz Questions for Quiz #2 (Science)
INSERT INTO `quiz_questions` (`id`, `quiz_id`, `question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_answer`, `points`, `explanation`) VALUES
(6, 2, 'Which organ is primarily responsible for pumping blood throughout the human body?', 'Lungs', 'Liver', 'Heart', 'Kidneys', 'C', 25.00, 'The human heart is the muscular pump that circulates blood through arteries and veins.'),
(7, 2, 'What process do green plants use to manufacture food using sunlight?', 'Photosynthesis', 'Respiration', 'Transpiration', 'Germination', 'A', 25.00, 'Photosynthesis converts sunlight, water, and CO2 into glucose and oxygen.');

-- Sample Student Attempt on Quiz #1 (Student STU-2025-001: Keza Divine)
INSERT INTO `quiz_attempts` (`id`, `quiz_id`, `student_id`, `score_obtained`, `total_possible`, `percentage`, `answers_json`, `is_recorded`, `submitted_at`) VALUES
(1, 1, 1, 100.00, 100.00, 100.00, '{\"1\":\"B\",\"2\":\"B\",\"3\":\"B\",\"4\":\"A\",\"5\":\"C\"}', 1, '2025-11-20 10:15:00'),
(2, 1, 2, 80.00, 100.00, 80.00, '{\"1\":\"B\",\"2\":\"A\",\"3\":\"B\",\"4\":\"A\",\"5\":\"C\"}', 1, '2025-11-20 10:22:00');

-- Sample Learning Materials (Notes, Exercises, Homework)
INSERT INTO `learning_materials` (`id`, `teacher_id`, `class_id`, `subject_id`, `title`, `description`, `material_type`, `file_name`, `file_path`, `external_link`, `content_text`, `due_date`) VALUES
(1, 3, 6, 1, 'P6 Unit 3: Fractions, Decimals, and Percentages Notes', 'Comprehensive class revision notes and worked examples for P6 pupils preparing for national evaluations.', 'Notes', 'P6_Math_Fractions_Decimals.pdf', 'uploads/materials/P6_Math_Fractions_Decimals.pdf', NULL, 'Review rules for dividing fractions: keep, change, flip. Memorize common decimal conversions: 1/4 = 0.25, 1/2 = 0.5, 3/4 = 0.75.', NULL),
(2, 3, 6, 1, 'Weekly Homework 04: Word Problems on Algebra', 'Solve questions 1 through 10 in your exercise book. Submit to teacher on Monday morning.', 'Homework', 'Math_HW_Algebra_Week4.pdf', 'uploads/materials/Math_HW_Algebra_Week4.pdf', NULL, '1. Twice a number plus 7 equals 29. Find the number.\n2. A father is 3 times older than his daughter...', '2026-09-22'),
(3, 3, 6, 4, 'Science Exercise: Plant Tropism and Photosynthesis', 'Fill-in-the-blank practice exercise for Primary 6 science learners.', 'Exercise', 'Science_Unit2_Tropism.pdf', 'uploads/materials/Science_Unit2_Tropism.pdf', NULL, 'Complete the matching table on phototropism, geotropism, and hydrotropism.', '2026-09-25');

-- Sample School News & Media Updates (Words, Photos & Videos)
INSERT INTO `news_updates` (`id`, `author_id`, `title`, `summary`, `content`, `media_type`, `image_url`, `video_url`, `is_published`, `published_at`) VALUES
(1, 1, 'EP NKORE Celebrates Outstanding 100% PLE National Exam Pass Rate', 'Our Primary 6 graduating class has achieved an exemplary 100% pass rate in national examinations with top division placements across Nyamagabe District.', 'We are immensely proud to announce that our 2025 candidates at EP NKORE in Musange Sector, Masangano Cell, Gasagara Village have recorded exceptional results in the Primary Leaving Examinations (PLE). 82% of pupils attained Division One distinctions in Mathematics, Science, and English.\n\nThe school management extends heartfelt gratitude to dedicated teachers, supportive parents, and hardworking pupils. New digital learning tools and continuous assessment quizzes have played a pivotal role in this milestone.', 'image', 'https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&w=1000&q=80', NULL, 1, '2026-09-10 09:00:00'),
(2, 1, 'School Tour & Smart Lab Demonstration (Video Showcase)', 'Watch our pupils in action during modern ICT and digital literacy sessions in the new EP NKORE computer laboratory.', 'Step inside EP NKORE with this video showcase featuring our computer laboratory, interactive classroom teaching, school garden projects, and sports tournaments. Parents and community members can explore how technology is transforming basic education in Rwanda.', 'video', 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1000&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1, '2026-09-12 14:30:00'),
(3, 1, 'Tree Planting & Environmental Awareness Day at Gasagara Campus', 'Pupils and teachers joined hands to plant 300 fruit and shade trees as part of green school initiatives.', 'On Saturday morning, the EP NKORE eco-club spearheaded an environmental conservation day across the campus grounds in Gasagara Village. Over 300 seedlings of avocado, grevillea, and mango were planted to provide future shade, nutrition, and environmental protection.', 'image', 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=1000&q=80', NULL, 1, '2026-09-14 11:00:00');

SET FOREIGN_KEY_CHECKS = 1;
