<?php
/**
 * EP NKORE - School Management System
 * Role-Based Sidebar Navigation Component
 */

if (!isset($current_user) || !$current_user) {
    return;
}

$role = $current_user['role'];
$base = get_base_url();
$current_page = basename($_SERVER['SCRIPT_NAME']);

// Fetch count of pending user accounts for Admin badge
$pending_count = 0;
if ($role === 'Administrator' && isset($pdo)) {
    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'PENDING'");
        $pending_count = (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        $pending_count = 0;
    }
}
?>
<aside class="app-sidebar" id="appSidebar">
    <div class="sidebar-user-card">
        <div class="sidebar-avatar">
            <?= strtoupper(substr($current_user['first_name'], 0, 1) . substr($current_user['last_name'], 0, 1)) ?>
        </div>
        <div class="sidebar-user-info">
            <span class="user-fullname"><?= e($current_user['first_name'] . ' ' . $current_user['last_name']) ?></span>
            <span class="user-role-label"><?= e($current_user['role']) ?></span>
        </div>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-section-label">MAIN NAVIGATION</div>

        <?php if ($role === 'Administrator'): ?>
            <a href="<?= $base ?>admin/dashboard.php" class="sidebar-link <?= ($current_page === 'dashboard.php' && str_contains($_SERVER['SCRIPT_NAME'], '/admin/')) ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                <span>Dashboard</span>
            </a>
            <a href="<?= $base ?>admin/approve_users.php" class="sidebar-link <?= ($current_page === 'approve_users.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>
                <span>Approve Users</span>
                <?php if ($pending_count > 0): ?>
                    <span class="badge badge-pill badge-warning"><?= $pending_count ?></span>
                <?php endif; ?>
            </a>
            <a href="<?= $base ?>admin/users.php" class="sidebar-link <?= ($current_page === 'users.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                <span>Manage Users</span>
            </a>
            <a href="<?= $base ?>admin/students.php" class="sidebar-link <?= ($current_page === 'students.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
                <span>Students</span>
            </a>
            <a href="<?= $base ?>admin/teachers.php" class="sidebar-link <?= ($current_page === 'teachers.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                <span>Teachers</span>
            </a>
            <a href="<?= $base ?>admin/classes.php" class="sidebar-link <?= ($current_page === 'classes.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                <span>Classes</span>
            </a>
            <a href="<?= $base ?>admin/subjects.php" class="sidebar-link <?= ($current_page === 'subjects.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
                <span>Subjects</span>
            </a>
            <a href="<?= $base ?>admin/reports.php" class="sidebar-link <?= ($current_page === 'reports.php' && str_contains($_SERVER['SCRIPT_NAME'], '/admin/')) ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
                <span>Reports</span>
            </a>
            <a href="<?= $base ?>admin/news.php" class="sidebar-link <?= ($current_page === 'news.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2"/><path d="M18 14h-8"/><path d="M15 18h-5"/><path d="M10 6h8v4h-8V6Z"/></svg>
                <span>School News & Media</span>
            </a>
            <a href="<?= $base ?>teacher/quizzes.php" class="sidebar-link <?= ($current_page === 'quizzes.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
                <span>Quizzes & Tests</span>
            </a>
            <a href="<?= $base ?>teacher/materials.php" class="sidebar-link <?= ($current_page === 'materials.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                <span>Notes & Homework</span>
            </a>
            <a href="<?= $base ?>admin/settings.php" class="sidebar-link <?= ($current_page === 'settings.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                <span>Settings & Audit</span>
            </a>

        <?php elseif ($role === 'Teacher'): ?>
            <a href="<?= $base ?>teacher/dashboard.php" class="sidebar-link <?= ($current_page === 'dashboard.php' && str_contains($_SERVER['SCRIPT_NAME'], '/teacher/')) ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                <span>Dashboard</span>
            </a>
            <a href="<?= $base ?>teacher/students.php" class="sidebar-link <?= ($current_page === 'students.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
                <span>My Students</span>
            </a>
            <a href="<?= $base ?>teacher/quizzes.php" class="sidebar-link <?= ($current_page === 'quizzes.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
                <span>Quizzes & Tests</span>
            </a>
            <a href="<?= $base ?>teacher/materials.php" class="sidebar-link <?= ($current_page === 'materials.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                <span>Notes & Homework</span>
            </a>
            <a href="<?= $base ?>teacher/marks.php" class="sidebar-link <?= ($current_page === 'marks.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
                <span>Enter & Edit Marks</span>
            </a>
            <a href="<?= $base ?>teacher/attendance.php" class="sidebar-link <?= ($current_page === 'attendance.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><path d="M9 16l2 2 4-4"/></svg>
                <span>Daily Attendance</span>
            </a>
            <a href="<?= $base ?>teacher/reports.php" class="sidebar-link <?= ($current_page === 'reports.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
                <span>Marks & Performance</span>
            </a>

        <?php elseif ($role === 'Head Teacher'): ?>
            <a href="<?= $base ?>headteacher/dashboard.php" class="sidebar-link <?= ($current_page === 'dashboard.php' && str_contains($_SERVER['SCRIPT_NAME'], '/headteacher/')) ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                <span>Dashboard</span>
            </a>
            <a href="<?= $base ?>headteacher/teachers.php" class="sidebar-link <?= ($current_page === 'teachers.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                <span>Teachers Directory</span>
            </a>
            <a href="<?= $base ?>headteacher/students.php" class="sidebar-link <?= ($current_page === 'students.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
                <span>Students Registry</span>
            </a>
            <a href="<?= $base ?>headteacher/marks.php" class="sidebar-link <?= ($current_page === 'marks.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                <span>Marks Review</span>
            </a>
            <a href="<?= $base ?>headteacher/attendance.php" class="sidebar-link <?= ($current_page === 'attendance.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                <span>Attendance Monitor</span>
            </a>
            <a href="<?= $base ?>headteacher/reports.php" class="sidebar-link <?= ($current_page === 'reports.php') ? 'active' : '' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
                <span>Academic Reports</span>
            </a>
        <?php endif; ?>

        <div class="nav-section-label">ACCOUNT</div>
        <a href="<?= $base ?>profile.php" class="sidebar-link <?= ($current_page === 'profile.php') ? 'active' : '' ?>">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            <span>My Profile</span>
        </a>
        <a href="<?= $base ?>logout.php" class="sidebar-link text-danger">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            <span>Sign Out</span>
        </a>
    </nav>
</aside>
