</main>

<footer class="app-footer">
    <div class="footer-container">
        <div class="footer-col">
            <div class="footer-brand">
                <span class="footer-title">EP NKORE</span>
                <p class="footer-desc">Excellence, Discipline, and Innovation in Basic Education. Delivering quality primary learning and community progress in Rwanda.</p>
            </div>
        </div>
        <div class="footer-col">
            <h4 class="footer-heading">Contact & Location</h4>
            <p class="footer-contact">
                <strong>Address:</strong> Nyamagabe District, Musange Sector, Masangano Cell, Gasagara Village<br>
                <strong>Tel / Call:</strong> <a href="tel:+250781125809" style="color: inherit; text-decoration: underline;">+250 781 125 809</a><br>
                <strong>WhatsApp:</strong> <a href="https://wa.me/250781125809" target="_blank" style="color: #22c55e; font-weight: 600; text-decoration: none;">💬 +250 781 125 809 (Chat on WhatsApp)</a><br>
                <strong>Email:</strong> <a href="mailto:jeanpierret772@gmail.com" style="color: inherit; text-decoration: underline;">jeanpierret772@gmail.com</a>
            </p>
        </div>
        <div class="footer-col">
            <h4 class="footer-heading">Hosting & System</h4>
            <p class="footer-contact">
                <strong>Platform:</strong> PHP 8.x + MySQL PDO<br>
                <strong>Runtime:</strong> Shared Hosting Compatible (InfinityFree / cPanel)<br>
                <strong>Version:</strong> EP NKORE v2.4 (2025/2026 Academic Year)
            </p>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="footer-bottom-inner">
            <p>&copy; <?= date('Y') ?> EP NKORE. All rights reserved.</p>
            <p class="dev-tag">Engineered for low-bandwidth, mobile-first shared hosting environments.</p>
        </div>
    </div>
</footer>

<script src="<?= $base_url ?>assets/js/script.js"></script>
</body>
</html>
