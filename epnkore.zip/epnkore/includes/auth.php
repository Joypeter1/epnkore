<?php
/**
 * EP NKORE - School Management System
 * Authentication & Role-Based Access Middleware
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

/**
 * Authenticate and log a user into session and durable cookie
 */
function login_user_session($user) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_role'] = $user['role'];
    $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['otp_verified'] = true;

    // Set durable authentication cookie to prevent session expiration across redirects
    $secret = defined('DB_PASS') ? DB_PASS : 'EP_NKORE_SECRET';
    $signature = hash_hmac('sha256', $user['id'] . '|' . $user['email'] . '|' . $user['password_hash'], $secret);
    $token = base64_encode($user['id'] . ':' . $signature);

    if (PHP_VERSION_ID >= 70300) {
        setcookie('ep_auth', $token, [
            'expires'  => time() + (86400 * 30),
            'path'     => '/',
            'domain'   => '',
            'secure'   => false,
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
    } else {
        setcookie('ep_auth', $token, time() + (86400 * 30), '/; samesite=Lax', '', false, true);
    }
}

/**
 * Restore session from authentication cookie if session was dropped by server
 */
function try_restore_session_from_cookie($pdo) {
    if (!empty($_SESSION['user_id']) && !empty($_SESSION['otp_verified'])) {
        return;
    }

    if (empty($_COOKIE['ep_auth']) || !$pdo) {
        return;
    }

    try {
        $raw = base64_decode($_COOKIE['ep_auth'], true);
        if (!$raw || !str_contains($raw, ':')) {
            return;
        }

        list($user_id, $sig) = explode(':', $raw, 2);
        $user_id = (int)$user_id;

        if ($user_id <= 0) {
            return;
        }

        $stmt = $pdo->prepare("SELECT id, first_name, last_name, phone, email, password_hash, role, status FROM users WHERE id = ? LIMIT 1");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();

        if ($user && $user['status'] === 'APPROVED') {
            $secret = defined('DB_PASS') ? DB_PASS : 'EP_NKORE_SECRET';
            $expected_sig = hash_hmac('sha256', $user['id'] . '|' . $user['email'] . '|' . $user['password_hash'], $secret);

            if (hash_equals($expected_sig, $sig)) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['otp_verified'] = true;
            }
        }
    } catch (Exception $e) {
        // Silently fail if cookie parsing fails
    }
}

/**
 * Check if the user is currently authenticated with a verified session
 */
function is_logged_in($pdo = null) {
    if (empty($_SESSION['user_id']) && !empty($_COOKIE['ep_auth'])) {
        global $pdo;
        try_restore_session_from_cookie($pdo);
    }
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']) && isset($_SESSION['otp_verified']) && $_SESSION['otp_verified'] === true;
}

/**
 * Get the current authenticated user record
 */
function current_user($pdo) {
    if (!is_logged_in($pdo)) {
        return null;
    }

    static $cached_user = null;
    if ($cached_user !== null) {
        return $cached_user;
    }

    try {
        $stmt = $pdo->prepare("SELECT id, first_name, last_name, phone, email, role, profile_photo, status, must_change_password FROM users WHERE id = ? LIMIT 1");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();

        if (!$user) {
            logout_user();
            return null;
        }

        // If status changed to non-approved while session was active, immediately logout
        if ($user['status'] !== 'APPROVED') {
            logout_user();
            header('Location: ' . get_base_url() . 'login.php?error=not_approved');
            exit;
        }

        $cached_user = $user;
        return $user;
    } catch (Exception $e) {
        return null;
    }
}

/**
 * Helper to compute root or relative base URL for links and redirects
 */
function get_base_url() {
    // Determine relative depth based on current script location
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    if (str_contains($script, '/admin/') || str_contains($script, '/teacher/') || str_contains($script, '/headteacher/')) {
        return '../';
    }
    return '';
}

/**
 * Require login. Redirects to login.php if unauthenticated.
 */
function require_login($pdo) {
    if (!is_logged_in($pdo)) {
        $base = get_base_url();
        header("Location: {$base}login.php?error=session_expired");
        exit;
    }

    $user = current_user($pdo);
    if (!$user) {
        $base = get_base_url();
        header("Location: {$base}login.php?error=unauthorized");
        exit;
    }

    return $user;
}

/**
 * Require specific role or array of allowed roles
 * 
 * @param PDO $pdo
 * @param string|array $allowed_roles e.g. 'Administrator' or ['Administrator', 'Head Teacher']
 */
function require_role($pdo, $allowed_roles) {
    $user = require_login($pdo);

    if (is_string($allowed_roles)) {
        $allowed_roles = [$allowed_roles];
    }

    if (!in_array($user['role'], $allowed_roles)) {
        $base = get_base_url();
        // Redirect to authorized dashboard
        $target = match($user['role']) {
            'Administrator' => "{$base}admin/dashboard.php",
            'Head Teacher'  => "{$base}headteacher/dashboard.php",
            'Teacher'       => "{$base}teacher/dashboard.php",
            default         => "{$base}login.php"
        };
        header("Location: {$target}?error=access_denied");
        exit;
    }

    return $user;
}

/**
 * Terminate session securely
 */
function logout_user() {
    if (session_status() === PHP_SESSION_ACTIVE) {
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params["path"],
                $params["domain"],
                $params["secure"],
                $params["httponly"]
            );
        }
        session_destroy();
    }
    // Also remove durable auth cookie
    setcookie('ep_auth', '', time() - 3600, '/');
}
