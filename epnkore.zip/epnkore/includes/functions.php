<?php
/**
 * EP NKORE - School Management System
 * Core Utility and Helper Functions
 */

if (session_status() === PHP_SESSION_NONE) {
    // Configure session cookie parameters safely for shared hosting & HTTP/HTTPS
    @ini_set('session.cookie_httponly', '1');
    @ini_set('session.use_only_cookies', '1');
    @ini_set('session.gc_maxlifetime', '2592000'); // 30 days
    
    // Set cookie params explicitly with path=/ and secure=false for compatibility with http:// domains
    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params([
            'lifetime' => 2592000,
            'path' => '/',
            'domain' => '',
            'secure' => false,
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
    } else {
        session_set_cookie_params(2592000, '/; samesite=Lax', '', false, true);
    }
    session_start();
}

/**
 * Escape HTML output to prevent XSS attacks
 */
function e($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

/**
 * Sanitize string input
 */
function sanitize_input($data) {
    if (is_array($data)) {
        return array_map('sanitize_input', $data);
    }
    return trim(strip_tags((string)$data));
}

/**
 * Generate CSRF token
 */
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Output hidden CSRF token input
 */
function csrf_field() {
    $token = generate_csrf_token();
    return '<input type="hidden" name="csrf_token" value="' . e($token) . '">';
}

/**
 * Verify CSRF token from POST request
 */
function verify_csrf_token($token) {
    if (!isset($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Validate password requirements:
 * - Min 8 characters
 * - At least 1 uppercase letter
 * - At least 1 lowercase letter
 * - At least 1 number
 * - At least 1 special character
 */
function validate_password_strength($password) {
    $errors = [];
    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters long.";
    }
    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = "Password must include at least one uppercase letter (A-Z).";
    }
    if (!preg_match('/[a-z]/', $password)) {
        $errors[] = "Password must include at least one lowercase letter (a-z).";
    }
    if (!preg_match('/[0-9]/', $password)) {
        $errors[] = "Password must include at least one number (0-9).";
    }
    if (!preg_match('/[\W_]/', $password)) {
        $errors[] = "Password must include at least one special character (!@#$%^&* etc).";
    }

    return [
        'is_valid' => empty($errors),
        'errors' => $errors
    ];
}

/**
 * Normalize phone number (especially Rwanda format: +250 78/79/72/73)
 */
function normalize_phone($phone) {
    $clean = preg_replace('/[^\d+]/', '', $phone);
    if (str_starts_with($clean, '07')) {
        $clean = '+250' . substr($clean, 1);
    } elseif (str_starts_with($clean, '250')) {
        $clean = '+' . $clean;
    } elseif (!str_starts_with($clean, '+')) {
        $clean = '+' . $clean;
    }
    return $clean;
}

/**
 * Set flash alert message
 */
function set_flash($type, $message) {
    if (!isset($_SESSION['flash_messages'])) {
        $_SESSION['flash_messages'] = [];
    }
    $_SESSION['flash_messages'][] = [
        'type' => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

/**
 * Retrieve and clear flash alert messages
 */
function get_flashes() {
    $flashes = $_SESSION['flash_messages'] ?? [];
    unset($_SESSION['flash_messages']);
    return $flashes;
}

/**
 * Render flash alert banners
 */
function display_flashes() {
    $flashes = get_flashes();
    if (empty($flashes)) {
        return '';
    }

    $html = '<div class="flash-container">';
    foreach ($flashes as $flash) {
        $type = e($flash['type']);
        $text = e($flash['message']);
        $icon = match($type) {
            'success' => '✓',
            'danger'  => '✕',
            'warning' => '⚠',
            default   => 'ℹ'
        };
        $html .= "<div class='alert alert-{$type}'>
                    <span class='alert-icon'>{$icon}</span>
                    <span class='alert-text'>{$text}</span>
                    <button type='button' class='alert-close' onclick='this.parentElement.remove();'>&times;</button>
                  </div>";
    }
    $html .= '</div>';
    return $html;
}

/**
 * Record action in audit log table
 */
function log_audit($pdo, $user_id, $action, $details = '') {
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
        $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? 'UNKNOWN', 0, 250);
        $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, details, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $action, $details, $ip, $ua]);
    } catch (Exception $e) {
        error_log("Audit log failure: " . $e->getMessage());
    }
}

/**
 * Fetch setting value by key
 */
function get_setting($pdo, $key, $default = '') {
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1");
        $stmt->execute([$key]);
        $val = $stmt->fetchColumn();
        return $val !== false ? $val : $default;
    } catch (Exception $e) {
        return $default;
    }
}

/**
 * Calculate grade and remarks from percentage based on configured grading scale
 */
function calculate_grade_info($marks, $max_marks = 100, $grading_scale_json = null) {
    if ($max_marks <= 0) {
        $max_marks = 100;
    }
    $percentage = ($marks / $max_marks) * 100;

    $scale = [];
    if (!empty($grading_scale_json)) {
        $scale = json_decode($grading_scale_json, true);
    }
    if (empty($scale)) {
        // Standard Rwandan Basic Education Default Scale
        $scale = [
            ['grade' => 'A', 'min' => 80, 'max' => 100, 'remarks' => 'Distinction'],
            ['grade' => 'B', 'min' => 70, 'max' => 79.99, 'remarks' => 'Very Good'],
            ['grade' => 'C', 'min' => 60, 'max' => 69.99, 'remarks' => 'Good'],
            ['grade' => 'D', 'min' => 50, 'max' => 59.99, 'remarks' => 'Pass'],
            ['grade' => 'F', 'min' => 0,  'max' => 49.99, 'remarks' => 'Fail']
        ];
    }

    foreach ($scale as $item) {
        if ($percentage >= $item['min'] && $percentage <= $item['max']) {
            return [
                'percentage' => round($percentage, 2),
                'grade' => $item['grade'],
                'remarks' => $item['remarks']
            ];
        }
    }

    return [
        'percentage' => round($percentage, 2),
        'grade' => 'F',
        'remarks' => 'Fail'
    ];
}

/**
 * Handle secure image upload (e.g. for profile photo or student photo)
 */
function upload_profile_photo($file, $target_dir, &$error = null) {
    if (!isset($file) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return null; // Optional upload
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = "Error uploading file. Code: " . $file['error'];
        return false;
    }

    // Max 3MB
    if ($file['size'] > 3 * 1024 * 1024) {
        $error = "File size must not exceed 3MB.";
        return false;
    }

    // Validate MIME type and extension
    $allowed_mimes = ['image/jpeg', 'image/png', 'image/webp'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime_type, $allowed_mimes)) {
        $error = "Only JPG, PNG, and WebP images are permitted.";
        return false;
    }

    $ext = match($mime_type) {
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        default      => 'jpg'
    };

    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0755, true);
    }

    $filename = 'img_' . bin2hex(random_bytes(10)) . '.' . $ext;
    $destination = rtrim($target_dir, '/') . '/' . $filename;

    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return $filename;
    }

    $error = "Failed to save the uploaded image to directory.";
    return false;
}
