<?php
/**
 * EP NKORE - School Management System
 * Shared Header Template
 */

if (!isset($pdo)) {
    require_once __DIR__ . '/../config/database.php';
}
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

$current_user = current_user($pdo);
$page_title = isset($page_title) ? $page_title . ' - EP NKORE' : 'EP NKORE - School Management System';
$base_url = get_base_url();

// Check if user has must_change_password
if ($current_user && $current_user['must_change_password'] && !str_contains($_SERVER['SCRIPT_NAME'], 'profile.php')) {
    set_flash('warning', 'Security Alert: You are using a temporary password. Please update your password immediately.');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?= e($page_title) ?></title>
    <meta name="description" content="EP NKORE - Basic Education School Management System. Student records, marks, attendance, and academic reports.">
    <meta name="theme-color" content="#1e3a8a">
    <link rel="stylesheet" href="<?= $base_url ?>assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="<?= isset($body_class) ? e($body_class) : '' ?>">

<!-- Main Application Navigation -->
<header class="app-header">
    <div class="nav-container">
        <div class="brand-area">
            <?php if ($current_user): ?>
                <button type="button" class="mobile-toggle-btn" id="sidebarToggle" aria-label="Toggle Navigation">
                    <span class="bar"></span>
                    <span class="bar"></span>
                    <span class="bar"></span>
                </button>
            <?php endif; ?>
            <a href="<?= $base_url ?>index.php" class="brand-link">
                <div class="brand-crest">
                    <svg viewBox="0 0 40 40" class="crest-svg" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect width="40" height="40" rx="8" fill="#1e3a8a"/>
                        <path d="M20 7L8 14L20 21L32 14L20 7Z" fill="#fbbf24"/>
                        <path d="M12 17.5V25.5C12 29 15.5 33 20 33C24.5 33 28 29 28 25.5V17.5L20 22.5L12 17.5Z" fill="#38bdf8"/>
                        <circle cx="20" cy="14" r="2.5" fill="#1e3a8a"/>
                    </svg>
                </div>
                <div class="brand-text">
                    <span class="brand-name">EP NKORE</span>
                    <span class="brand-tagline">School Management System</span>
                </div>
            </a>
        </div>

        <nav class="nav-menu">
            <a href="<?= $base_url ?>news.php" class="nav-item">School News</a>
            <a href="<?= $base_url ?>materials.php" class="nav-item">Notes & Homework</a>
            <a href="<?= $base_url ?>quiz_take.php" class="nav-item">Online Tests</a>
            <?php if (!$current_user): ?>
                <a href="<?= $base_url ?>register.php" class="nav-item">Create Account</a>
                <a href="<?= $base_url ?>login.php" class="btn btn-primary btn-sm">Sign In</a>
            <?php else: ?>
                <div class="user-role-badge badge-<?= strtolower(str_replace(' ', '-', $current_user['role'])) ?>">
                    <?= e($current_user['role']) ?>
                </div>

                <div class="user-dropdown">
                    <button type="button" class="user-profile-btn" id="userMenuBtn">
                        <div class="user-avatar-sm">
                            <?= strtoupper(substr($current_user['first_name'], 0, 1) . substr($current_user['last_name'], 0, 1)) ?>
                        </div>
                        <span class="user-name-display"><?= e($current_user['first_name']) ?></span>
                        <svg class="chevron-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
                    </button>
                    <div class="user-menu-dropdown" id="userMenuDropdown">
                        <div class="dropdown-header">
                            <strong><?= e($current_user['first_name'] . ' ' . $current_user['last_name']) ?></strong>
                            <small><?= e($current_user['email']) ?></small>
                        </div>
                        <a href="<?= $base_url ?>profile.php" class="dropdown-link">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                            My Profile & Password
                        </a>
                        <a href="<?= $base_url ?>dashboard.php" class="dropdown-link">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                            My Dashboard
                        </a>
                        <hr class="dropdown-divider">
                        <a href="<?= $base_url ?>logout.php" class="dropdown-link text-danger">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                            Sign Out
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </nav>
    </div>
</header>

<!-- Flash notification messages -->
<div class="flash-messages-wrapper">
    <?= display_flashes() ?>
</div>

<main class="main-content-layout <?= $current_user ? 'has-sidebar' : 'no-sidebar' ?>">
