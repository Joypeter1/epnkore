<?php
/**
 * EP NKORE - School Management System
 * User Profile & Password Management
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$current_user = require_login($pdo);
$user_id = $current_user['id'];

$errors = [];
$success_msg = null;

// Handle Profile Details Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf)) {
        $errors[] = "Security validation error. Please try again.";
    } else {
        $first_name = sanitize_input($_POST['first_name'] ?? '');
        $last_name = sanitize_input($_POST['last_name'] ?? '');
        $phone_raw = sanitize_input($_POST['phone'] ?? '');
        $email = sanitize_input(filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL));

        if (empty($first_name) || empty($last_name) || empty($phone_raw) || empty($email)) {
            $errors[] = "All profile fields are required.";
        }

        $phone = normalize_phone($phone_raw);

        // Check duplicate email or phone for other accounts
        if (empty($errors)) {
            $dup = $pdo->prepare("SELECT id FROM users WHERE (email = ? OR phone = ?) AND id != ? LIMIT 1");
            $dup->execute([$email, $phone, $user_id]);
            if ($dup->fetch()) {
                $errors[] = "Another user account is already using that email or phone number.";
            }
        }

        // Handle Photo Upload
        $profile_photo = $current_user['profile_photo'];
        if (empty($errors) && isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] !== UPLOAD_ERR_NO_FILE) {
            $upload_err = null;
            $new_photo = upload_profile_photo($_FILES['profile_photo'], __DIR__ . '/uploads/profiles', $upload_err);
            if ($new_photo === false) {
                $errors[] = $upload_err ?: "Photo upload failed.";
            } elseif ($new_photo) {
                $profile_photo = $new_photo;
            }
        }

        if (empty($errors)) {
            $stmt = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ?, phone = ?, email = ?, profile_photo = ? WHERE id = ?");
            $stmt->execute([$first_name, $last_name, $phone, $email, $profile_photo, $user_id]);

            log_audit($pdo, $user_id, 'PROFILE_UPDATED', "User updated personal profile details");
            set_flash('success', 'Profile information updated successfully.');
            header('Location: profile.php');
            exit;
        }
    }
}

// Handle Password Change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf)) {
        $errors[] = "Security validation error. Please try again.";
    } else {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        // Fetch current hash
        $stmt_pw = $pdo->prepare("SELECT password_hash FROM users WHERE id = ?");
        $stmt_pw->execute([$user_id]);
        $hash = $stmt_pw->fetchColumn();

        if (!password_verify($current_password, $hash)) {
            $errors[] = "Your current password was entered incorrectly.";
        }

        $strength = validate_password_strength($new_password);
        if (!$strength['is_valid']) {
            $errors = array_merge($errors, $strength['errors']);
        }

        if ($new_password !== $confirm_password) {
            $errors[] = "New password and confirmation do not match.";
        }

        if (empty($errors)) {
            $new_hash = password_hash($new_password, PASSWORD_BCRYPT, ['cost' => 10]);
            $update_pw = $pdo->prepare("UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?");
            $update_pw->execute([$new_hash, $user_id]);

            log_audit($pdo, $user_id, 'PASSWORD_CHANGED', "User changed account password");
            set_flash('success', 'Password updated successfully! Next login will require your new password.');
            header('Location: profile.php');
            exit;
        }
    }
}

// Refresh user info
$stmt_refresh = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt_refresh->execute([$user_id]);
$current_user = $stmt_refresh->fetch();

$page_title = "My Profile - EP NKORE";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">My Profile & Account</h1>
            <p class="page-subtitle">Manage your credentials, phone number for OTP, and security</p>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <div>
                <strong>Errors encountered:</strong>
                <ul style="margin: 4px 0 0 16px;">
                    <?php foreach ($errors as $e): ?>
                        <li><?= e($e) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 24px;">
        <!-- Profile Details Card -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Personal Details</h3>
                <span class="badge badge-<?= strtolower(str_replace(' ', '-', $current_user['role'])) ?>">
                    <?= e($current_user['role']) ?>
                </span>
            </div>
            <div class="card-body">
                <form action="profile.php" method="POST" enctype="multipart/form-data">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="update_profile">

                    <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 20px;">
                        <div class="sidebar-avatar" style="width: 64px; height: 64px; font-size: 22px;">
                            <?= strtoupper(substr($current_user['first_name'], 0, 1) . substr($current_user['last_name'], 0, 1)) ?>
                        </div>
                        <div>
                            <label class="form-label" style="margin-bottom: 4px;">Update Profile Photo</label>
                            <input type="file" name="profile_photo" class="form-control" accept="image/jpeg,image/png,image/webp">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">First Name</label>
                            <input type="text" name="first_name" class="form-control" value="<?= e($current_user['first_name']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="last_name" class="form-control" value="<?= e($current_user['last_name']) ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Phone Number (For OTP)</label>
                        <input type="text" name="phone" class="form-control" value="<?= e($current_user['phone']) ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Email Address</label>
                        <input type="email" name="email" class="form-control" value="<?= e($current_user['email']) ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Account Status</label>
                        <span class="badge badge-approved"><?= e($current_user['status']) ?></span>
                    </div>

                    <button type="submit" class="btn btn-primary" style="margin-top: 10px;">
                        Save Profile Changes
                    </button>
                </form>
            </div>
        </div>

        <!-- Password Security Card -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Change Password</h3>
            </div>
            <div class="card-body">
                <form action="profile.php" method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="change_password">

                    <div class="form-group">
                        <label class="form-label">Current Password</label>
                        <input type="password" name="current_password" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">New Password</label>
                        <input type="password" id="regPassword" name="new_password" class="form-control" required autocomplete="new-password">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Confirm New Password</label>
                        <input type="password" id="regConfirmPassword" name="confirm_password" class="form-control" required autocomplete="new-password">
                    </div>

                    <!-- Password rules -->
                    <div class="password-requirements" style="margin-bottom: 16px;">
                        <div class="req-title">New Password Criteria:</div>
                        <ul class="req-list">
                            <li class="req-item" id="reqLength"><span class="req-icon">○</span> 8+ characters</li>
                            <li class="req-item" id="reqUpper"><span class="req-icon">○</span> 1 uppercase (A-Z)</li>
                            <li class="req-item" id="reqLower"><span class="req-icon">○</span> 1 lowercase (a-z)</li>
                            <li class="req-item" id="reqNumber"><span class="req-icon">○</span> 1 number (0-9)</li>
                            <li class="req-item" id="reqSpecial"><span class="req-icon">○</span> 1 special char</li>
                            <li class="req-item" id="reqMatch"><span class="req-icon">○</span> Passwords match</li>
                        </ul>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        Update Password
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
