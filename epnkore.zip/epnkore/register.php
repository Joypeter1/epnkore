<?php
/**
 * EP NKORE - School Management System
 * Staff Registration Page
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

$errors = [];
$first_name = '';
$last_name = '';
$phone = '';
$email = '';
$role = 'Teacher';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf)) {
        $errors[] = "Security validation failed. Please reload the form.";
    }

    $first_name = sanitize_input($_POST['first_name'] ?? '');
    $last_name = sanitize_input($_POST['last_name'] ?? '');
    $phone_raw = sanitize_input($_POST['phone'] ?? '');
    $email = sanitize_input(filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL));
    $role = sanitize_input($_POST['role'] ?? 'Teacher');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Validate Required Fields
    if (empty($first_name) || empty($last_name) || empty($phone_raw) || empty($email) || empty($password)) {
        $errors[] = "Please complete all required fields.";
    }

    // Role validation
    $allowed_roles = ['Teacher', 'Head Teacher', 'Administrator'];
    if (!in_array($role, $allowed_roles)) {
        $errors[] = "Invalid role selected.";
    }

    // Email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please provide a valid email address.";
    }

    // Phone format
    $phone = normalize_phone($phone_raw);
    if (strlen($phone) < 10) {
        $errors[] = "Please enter a valid phone number (e.g. +250 788 123 456).";
    }

    // Password strength check
    $strength_check = validate_password_strength($password);
    if (!$strength_check['is_valid']) {
        $errors = array_merge($errors, $strength_check['errors']);
    }

    // Password confirmation
    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    }

    // Check duplicate phone or email
    if (empty($errors)) {
        try {
            $check = $pdo->prepare("SELECT id FROM users WHERE email = ? OR phone = ? LIMIT 1");
            $check->execute([$email, $phone]);
            if ($check->fetch()) {
                $errors[] = "An account with this email address or phone number already exists.";
            }
        } catch (Exception $e) {
            $errors[] = "Database check failed: " . $e->getMessage();
        }
    }

    // Profile photo upload (optional)
    $profile_photo = 'default_avatar.png';
    if (empty($errors) && isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] !== UPLOAD_ERR_NO_FILE) {
        $upload_err = null;
        $uploaded = upload_profile_photo($_FILES['profile_photo'], __DIR__ . '/uploads/profiles', $upload_err);
        if ($uploaded === false) {
            $errors[] = $upload_err ?: "Photo upload failed.";
        } elseif ($uploaded) {
            $profile_photo = $uploaded;
        }
    }

    // If all validation passes, create user with PENDING status
    if (empty($errors)) {
        try {
            $password_hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);

            $stmt = $pdo->prepare("
                INSERT INTO users (first_name, last_name, phone, email, password_hash, role, profile_photo, status, must_change_password)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'PENDING', 0)
            ");
            $stmt->execute([
                $first_name,
                $last_name,
                $phone,
                $email,
                $password_hash,
                $role,
                $profile_photo
            ]);

            $new_user_id = $pdo->lastInsertId();

            // If registering as a teacher, create teacher profile entry
            if ($role === 'Teacher') {
                $code = 'TCH-' . str_pad($new_user_id, 3, '0', STR_PAD_LEFT);
                $stmt_tch = $pdo->prepare("INSERT INTO teachers (user_id, teacher_code, qualification, specialization) VALUES (?, ?, 'Pending Verification', 'General Education')");
                $stmt_tch->execute([$new_user_id, $code]);
            }

            log_audit($pdo, $new_user_id, 'USER_REGISTERED', "New user registration submitted with role: {$role} (Status: PENDING)");

            set_flash('success', 'Account created successfully! Your account is waiting for administrator approval before you can log in.');
            header('Location: login.php');
            exit;

        } catch (Exception $e) {
            error_log("Registration Error: " . $e->getMessage());
            $errors[] = "An unexpected error occurred during account creation. Please try again.";
        }
    }
}

$page_title = "Register Staff Account - EP NKORE";
require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 640px; margin: 40px auto; padding: 0 16px;">
    <div class="card" style="padding: 32px; border-radius: var(--radius-lg); box-shadow: var(--shadow-md);">
        <div style="text-align: center; margin-bottom: 24px;">
            <div class="brand-crest" style="width: 48px; height: 48px; margin: 0 auto 10px;">
                <svg viewBox="0 0 40 40" class="crest-svg" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect width="40" height="40" rx="8" fill="#1e3a8a"/>
                    <path d="M20 7L8 14L20 21L32 14L20 7Z" fill="#fbbf24"/>
                    <path d="M12 17.5V25.5C12 29 15.5 33 20 33C24.5 33 28 29 28 25.5V17.5L20 22.5L12 17.5Z" fill="#38bdf8"/>
                    <circle cx="20" cy="14" r="2.5" fill="#1e3a8a"/>
                </svg>
            </div>
            <h2 style="font-size: 24px; font-weight: 700; color: var(--slate-900);">Create Staff Account</h2>
            <p style="font-size: 13.5px; color: var(--slate-500); margin-top: 4px;">Accounts require Administrator approval before first login</p>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger" style="display: block;">
                <strong>Please resolve the following errors:</strong>
                <ul style="margin: 6px 0 0 18px; font-size: 13.5px;">
                    <?php foreach ($errors as $err): ?>
                        <li><?= e($err) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="register.php" method="POST" enctype="multipart/form-data">
            <?= csrf_field() ?>

            <div class="form-row">
                <div class="form-group">
                    <label for="first_name" class="form-label">First Name <span class="required">*</span></label>
                    <input type="text" id="first_name" name="first_name" class="form-control" value="<?= e($first_name) ?>" required>
                </div>
                <div class="form-group">
                    <label for="last_name" class="form-label">Last Name <span class="required">*</span></label>
                    <input type="text" id="last_name" name="last_name" class="form-control" value="<?= e($last_name) ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="phone" class="form-label">Phone Number <span class="required">*</span></label>
                    <input type="tel" id="phone" name="phone" class="form-control" placeholder="+250 788 123 456" value="<?= e($phone) ?>" required>
                    <small class="form-text">Used for SMS OTP verification</small>
                </div>
                <div class="form-group">
                    <label for="email" class="form-label">Email Address <span class="required">*</span></label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="staff@epnkore.edu.rw" value="<?= e($email) ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="role" class="form-label">School Role <span class="required">*</span></label>
                    <select id="role" name="role" class="form-select" required>
                        <option value="Teacher" <?= $role === 'Teacher' ? 'selected' : '' ?>>Teacher</option>
                        <option value="Head Teacher" <?= $role === 'Head Teacher' ? 'selected' : '' ?>>Head Teacher</option>
                        <option value="Administrator" <?= $role === 'Administrator' ? 'selected' : '' ?>>Administrator</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="profile_photo" class="form-label">Profile Photo (Optional)</label>
                    <input type="file" id="profile_photo" name="profile_photo" class="form-control" accept="image/jpeg,image/png,image/webp">
                    <small class="form-text">Max 3MB (JPG, PNG)</small>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="regPassword" class="form-label">Password <span class="required">*</span></label>
                    <input type="password" id="regPassword" name="password" class="form-control" required autocomplete="new-password">
                </div>
                <div class="form-group">
                    <label for="regConfirmPassword" class="form-label">Confirm Password <span class="required">*</span></label>
                    <input type="password" id="regConfirmPassword" name="confirm_password" class="form-control" required autocomplete="new-password">
                </div>
            </div>

            <!-- Password Requirements Visual Box -->
            <div class="password-requirements">
                <div class="req-title">Password Security Requirements:</div>
                <ul class="req-list">
                    <li class="req-item" id="reqLength"><span class="req-icon">○</span> At least 8 characters</li>
                    <li class="req-item" id="reqUpper"><span class="req-icon">○</span> At least 1 uppercase (A-Z)</li>
                    <li class="req-item" id="reqLower"><span class="req-icon">○</span> At least 1 lowercase (a-z)</li>
                    <li class="req-item" id="reqNumber"><span class="req-icon">○</span> At least 1 number (0-9)</li>
                    <li class="req-item" id="reqSpecial"><span class="req-icon">○</span> At least 1 special char (!@#$)</li>
                    <li class="req-item" id="reqMatch"><span class="req-icon">○</span> Passwords match</li>
                </ul>
            </div>

            <div style="background: var(--warning-light); border: 1px solid var(--warning-border); padding: 12px; border-radius: var(--radius-sm); margin: 18px 0; font-size: 13px; color: #92400e;">
                <strong>Notice:</strong> Upon submission, your account status will be set to <strong>PENDING</strong>. You will receive an SMS notification once the Head of School or System Administrator approves your account.
            </div>

            <button type="submit" class="btn btn-primary btn-lg" style="width: 100%;">
                Submit Registration
            </button>
        </form>

        <div style="margin-top: 24px; text-align: center; font-size: 13.5px; color: var(--slate-600); border-top: 1px solid var(--slate-200); padding-top: 16px;">
            Already have an approved account?
            <a href="login.php" style="font-weight: 700; color: var(--primary);">Sign In here</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
