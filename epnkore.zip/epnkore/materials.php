<?php
/**
 * EP NKORE - School Management System
 * Pupil & Parent Learning Materials Hub
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$classes = $pdo->query("SELECT * FROM classes ORDER BY grade_level ASC")->fetchAll();
$subjects = $pdo->query("SELECT * FROM subjects ORDER BY name ASC")->fetchAll();

$filter_class = (int)($_GET['class_id'] ?? 0);
$filter_type = trim($_GET['type'] ?? '');
$search = trim($_GET['search'] ?? '');

$query = "SELECT m.*, c.name AS class_name, s.name AS subject_name, u.first_name, u.last_name 
          FROM learning_materials m
          JOIN classes c ON m.class_id = c.id
          JOIN subjects s ON m.subject_id = s.id
          JOIN users u ON m.teacher_id = u.id
          WHERE 1=1";

$params = [];
if ($filter_class > 0) {
    $query .= " AND m.class_id = ?";
    $params[] = $filter_class;
}
if (!empty($filter_type)) {
    $query .= " AND m.material_type = ?";
    $params[] = $filter_type;
}
if (!empty($search)) {
    $query .= " AND (m.title LIKE ? OR m.description LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}
$query .= " ORDER BY m.id DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$materials = $stmt->fetchAll();

$page_title = "Pupil Learning Hub - Notes, Exercises & Homework - EP NKORE";
require_once __DIR__ . '/includes/header.php';
?>

<div class="content-body" style="max-width: 1100px; margin: 0 auto; padding: 30px 20px;">
    <!-- Portal Banner -->
    <div style="background: linear-gradient(135deg, #1e3a8a, #0284c7); border-radius: 16px; padding: 32px; color: white; margin-bottom: 30px; box-shadow: 0 10px 25px -5px rgba(2, 132, 199, 0.3);">
        <div style="display: inline-block; background: rgba(255,255,255,0.2); padding: 4px 12px; border-radius: 9999px; font-size: 12px; font-weight: 700; text-transform: uppercase; margin-bottom: 12px;">
            Digital Learning Resources
        </div>
        <h1 style="font-size: 28px; font-weight: 800; margin-bottom: 8px;">
            Pupil Learning Hub: Notes, Exercises & Homework
        </h1>
        <p style="font-size: 15px; opacity: 0.9; max-width: 700px; margin-bottom: 0;">
            Access teacher-approved revision materials, weekly homework tasks, and subject summaries. Download attachments or read directly on any mobile phone or computer.
        </p>
    </div>

    <!-- Search & Filter Bar -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-body" style="padding: 16px 20px;">
            <form action="materials.php" method="GET" style="display: flex; gap: 12px; align-items: flex-end; flex-wrap: wrap;">
                <div style="flex: 2; min-width: 200px;">
                    <label class="form-label" style="font-size: 12px;">Search Topic / Keyword</label>
                    <input type="text" name="search" class="form-control" placeholder="Search by title, subject, chapter..." value="<?= e($search) ?>">
                </div>
                <div style="flex: 1; min-width: 150px;">
                    <label class="form-label" style="font-size: 12px;">Filter Class</label>
                    <select name="class_id" class="form-select">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= $filter_class == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div style="flex: 1; min-width: 150px;">
                    <label class="form-label" style="font-size: 12px;">Category</label>
                    <select name="type" class="form-select">
                        <option value="">All Types</option>
                        <option value="Notes" <?= $filter_type === 'Notes' ? 'selected' : '' ?>>Notes (Amanota)</option>
                        <option value="Exercise" <?= $filter_type === 'Exercise' ? 'selected' : '' ?>>Exercise (Imyitozo)</option>
                        <option value="Homework" <?= $filter_type === 'Homework' ? 'selected' : '' ?>>Homework (Umukoro)</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary btn-sm">Filter</button>
                <a href="materials.php" class="btn btn-secondary btn-sm">Reset</a>
            </form>
        </div>
    </div>

    <!-- Materials Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 20px;">
        <?php if (empty($materials)): ?>
            <div class="card" style="grid-column: 1 / -1; text-align: center; padding: 50px 20px; color: #64748b;">
                <div style="font-size: 36px; margin-bottom: 12px;">📚</div>
                <h3 style="font-size: 18px; font-weight: 700; color: #0f172a; margin-bottom: 6px;">No Materials Found</h3>
                <p>Try adjusting your class or category filters, or check back later when teachers upload new coursework.</p>
            </div>
        <?php else: ?>
            <?php foreach ($materials as $m): ?>
                <div class="card" style="display: flex; flex-direction: column; justify-content: space-between; border-top: 4px solid <?= $m['material_type'] === 'Notes' ? '#0284c7' : ($m['material_type'] === 'Homework' ? '#ea580c' : '#16a34a') ?>;">
                    <div class="card-body" style="padding: 20px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                            <span class="badge badge-<?= $m['material_type'] === 'Notes' ? 'info' : ($m['material_type'] === 'Homework' ? 'warning' : 'success') ?>">
                                <?= e($m['material_type']) ?>
                            </span>
                            <span style="font-size: 12px; font-weight: 700; color: #1e3a8a;">
                                <?= e($m['class_name']) ?>
                            </span>
                        </div>

                        <h3 style="font-size: 16px; font-weight: 700; color: #0f172a; margin-bottom: 6px; line-height: 1.4;">
                            <?= e($m['title']) ?>
                        </h3>
                        <div style="font-size: 12px; color: #64748b; margin-bottom: 12px;">
                            Subject: <strong><?= e($m['subject_name']) ?></strong> • By: <?= e($m['first_name'] . ' ' . $m['last_name']) ?>
                        </div>

                        <?php if (!empty($m['description'])): ?>
                            <p style="font-size: 13px; color: #475569; margin-bottom: 12px; line-height: 1.5;">
                                <?= e($m['description']) ?>
                            </p>
                        <?php endif; ?>

                        <?php if (!empty($m['due_date'])): ?>
                            <div style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 6px; padding: 6px 12px; font-size: 12px; color: #b91c1c; margin-bottom: 14px; font-weight: 600;">
                                ⏰ Due Date: <?= date('l, M d, Y', strtotime($m['due_date'])) ?>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($m['content_text'])): ?>
                            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px 12px; font-size: 12px; color: #334155; margin-bottom: 14px; max-height: 140px; overflow-y: auto; white-space: pre-line;">
                                <?= e($m['content_text']) ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="card-footer" style="background: #f8fafc; padding: 12px 20px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 11px; color: #94a3b8;">
                            <?= date('M d, Y', strtotime($m['created_at'])) ?>
                        </span>

                        <div style="display: flex; gap: 8px;">
                            <?php if (!empty($m['file_path'])): ?>
                                <a href="<?= get_base_url() . e($m['file_path']) ?>" target="_blank" download class="btn btn-primary btn-sm" style="display: flex; align-items: center; gap: 4px;">
                                    <span>Download</span> 📥
                                </a>
                            <?php endif; ?>
                            <?php if (!empty($m['external_link'])): ?>
                                <a href="<?= e($m['external_link']) ?>" target="_blank" class="btn btn-outline btn-sm">
                                    Link ↗
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
