<?php
/**
 * EP NKORE - Emergency Database Repair, Admin Setup & Direct Dashboard Access
 * 
 * Open this page in your browser:
 * https://your-site/setup_admin.php
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$message = '';
$status = 'info';

// Bcrypt hash for: Admin12345
$default_hash = '$2y$10$jLs6ReHiWKzyjnjWTREHuOPPEQhdWFhDBajNcQ4T3mT1qj03OV3RS';

/**
 * Ensure `users` table exists and has Administrator
 */
function auto_repair_admin_account($pdo, $default_hash) {
    // 1. Ensure users table exists
    $pdo->exec("CREATE TABLE IF NOT EXISTS `users` (
      `id` INT(11) NOT NULL AUTO_INCREMENT,
      `first_name` VARCHAR(100) NOT NULL,
      `last_name` VARCHAR(100) NOT NULL,
      `phone` VARCHAR(30) NOT NULL UNIQUE,
      `email` VARCHAR(150) NOT NULL UNIQUE,
      `password_hash` VARCHAR(255) NOT NULL,
      `role` ENUM('Administrator', 'Head Teacher', 'Teacher') NOT NULL DEFAULT 'Teacher',
      `profile_photo` VARCHAR(255) DEFAULT 'default_avatar.png',
      `status` ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL DEFAULT 'PENDING',
      `must_change_password` TINYINT(1) NOT NULL DEFAULT 0,
      `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (`id`),
      INDEX `idx_users_email` (`email`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // 2. Check if admin exists
    $check = $pdo->query("SELECT id FROM users WHERE email = 'admin@epnkore.com' OR email = 'jeanpierret772@gmail.com' OR role = 'Administrator' LIMIT 1")->fetch();

    if (!$check) {
        // Insert admin account
        $stmt = $pdo->prepare("INSERT INTO users (first_name, last_name, phone, email, password_hash, role, status, must_change_password) 
                               VALUES ('Jean Pierre', 'Administrator', '+250781125809', 'admin@epnkore.com', ?, 'Administrator', 'APPROVED', 0)");
        $stmt->execute([$default_hash]);

        try {
            $stmt2 = $pdo->prepare("INSERT INTO users (first_name, last_name, phone, email, password_hash, role, status, must_change_password) 
                                   VALUES ('Jean Pierre', 'Admin', '+250780000000', 'jeanpierret772@gmail.com', ?, 'Administrator', 'APPROVED', 0)");
            $stmt2->execute([$default_hash]);
        } catch (Exception $e) {
            // Duplicate phone or already exists
        }
    } else {
        // Update password to Admin12345 and status to APPROVED
        $upd = $pdo->prepare("UPDATE users SET password_hash = ?, status = 'APPROVED' WHERE id = ?");
        $upd->execute([$default_hash, $check['id']]);
    }
}

// 1. ACTION: Direct Login (One-Click via POST or GET link)
if (isset($_GET['login']) || ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['direct_login']))) {
    try {
        auto_repair_admin_account($pdo, $default_hash);

        // Fetch the admin user
        $stmt = $pdo->prepare("SELECT * FROM users WHERE role = 'Administrator' OR email = 'admin@epnkore.com' ORDER BY id ASC LIMIT 1");
        $stmt->execute();
        $admin = $stmt->fetch();

        if ($admin) {
            login_user_session($admin);

            session_write_close();
            header('Location: dashboard.php');
            exit;
        } else {
            $message = "Unable to start session. Please click 'Import Full Database' below.";
            $status = 'danger';
        }
    } catch (Exception $e) {
        $message = "Database error: " . $e->getMessage();
        $status = 'danger';
    }
}

// 2. ACTION: Import Full Database from ep_nkore.sql (NO PHPMYADMIN REQUIRED)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import_database'])) {
    $sql_file = __DIR__ . '/database/ep_nkore.sql';
    if (file_exists($sql_file)) {
        try {
            $sql = file_get_contents($sql_file);
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");

            try {
                // Try batch execution first
                $pdo->exec($sql);
            } catch (Exception $sub_e) {
                // If bulk fails, run individual statements
                $queries = array_filter(array_map('trim', explode(";\n", $sql)));
                foreach ($queries as $q) {
                    if (!empty($q)) {
                        try {
                            $pdo->exec($q);
                        } catch (Exception $ign) {}
                    }
                }
            }

            $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");

            // Ensure admin account is created and approved
            auto_repair_admin_account($pdo, $default_hash);

            $message = "BYAKOZE NEZA CYANE! Database yose (tables zose, amasomo, abanyeshuri, abarezi n'ubuyobozi) yamaze gushyirwamo ijana ku ijana!";
            $status = 'success';
        } catch (Exception $e) {
            $message = "SQL Import Notice: " . $e->getMessage();
            $status = 'warning';
        }
    } else {
        $message = "ep_nkore.sql ntiyabonetse muri folder ya database/.";
        $status = 'danger';
    }
}

// 3. ACTION: Custom Create / Reset User
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_custom_admin'])) {
    $c_email = trim($_POST['custom_email'] ?? 'admin@epnkore.com');
    $c_pass  = trim($_POST['custom_password'] ?? 'Admin12345');
    $c_phone = trim($_POST['custom_phone'] ?? '+250781125809');

    if (empty($c_email) || empty($c_pass)) {
        $message = "Please enter both Email and Password.";
        $status = 'danger';
    } else {
        try {
            auto_repair_admin_account($pdo, $default_hash);
            $new_hash = password_hash($c_pass, PASSWORD_BCRYPT);

            $ch = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
            $ch->execute([$c_email]);
            $found = $ch->fetch();

            if ($found) {
                $u = $pdo->prepare("UPDATE users SET password_hash = ?, role = 'Administrator', status = 'APPROVED', must_change_password = 0 WHERE id = ?");
                $u->execute([$new_hash, $found['id']]);
            } else {
                $i = $pdo->prepare("INSERT INTO users (first_name, last_name, phone, email, password_hash, role, status, must_change_password) 
                                   VALUES ('Jean Pierre', 'Administrator', ?, ?, ?, 'Administrator', 'APPROVED', 0)");
                $i->execute([$c_phone, $c_email, $new_hash]);
            }

            $message = "SUCCESS! Konti yawe yakozwe: Email: {$c_email} | Password: {$c_pass}.";
            $status = 'success';
        } catch (Exception $e) {
            $message = "Error creating account: " . $e->getMessage();
            $status = 'danger';
        }
    }
}

// Fetch tables and current users for display
$current_users = [];
$existing_tables = [];
$table_exists = false;
try {
    $tbl_stmt = $pdo->query("SHOW TABLES");
    $existing_tables = $tbl_stmt->fetchAll(PDO::FETCH_COLUMN);

    if (in_array('users', $existing_tables)) {
        $table_exists = true;
        $stmt = $pdo->query("SELECT id, first_name, last_name, email, phone, role, status FROM users ORDER BY id ASC LIMIT 10");
        $current_users = $stmt->fetchAll();
    }
} catch (Exception $e) {
    $db_err = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="rw">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EP NKORE - Database & Admin Setup</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1e3a8a;
            --primary-dark: #172554;
            --success: #16a34a;
            --success-dark: #15803d;
            --danger: #dc2626;
            --bg: #f8fafc;
            --text: #0f172a;
            --muted: #64748b;
            --card: #ffffff;
            --border: #e2e8f0;
        }
        * { box-sizing: border-box; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); color: var(--text); margin: 0; padding: 24px 16px; display: flex; justify-content: center; align-items: flex-start; min-height: 100vh; }
        .wrap { width: 100%; max-width: 600px; }
        .card { background: var(--card); border-radius: 16px; border: 1px solid var(--border); box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05); padding: 28px; margin-bottom: 20px; }
        h1 { font-size: 22px; font-weight: 700; color: var(--primary); margin: 0 0 6px 0; }
        p.subtitle { font-size: 14px; color: var(--muted); margin: 0 0 20px 0; line-height: 1.5; }
        
        .alert { padding: 14px 16px; border-radius: 10px; font-size: 14px; margin-bottom: 20px; line-height: 1.5; }
        .alert-success { background: #dcfce7; color: #14532d; border: 1px solid #bbf7d0; }
        .alert-danger { background: #fee2e2; color: #7f1d1d; border: 1px solid #fecaca; }
        .alert-warning { background: #fef3c7; color: #78350f; border: 1px solid #fde68a; }
        .alert-info { background: #eff6ff; color: #1e3a8a; border: 1px solid #dbeafe; }

        .btn { display: inline-flex; align-items: center; justify-content: center; width: 100%; padding: 15px 20px; border-radius: 10px; font-weight: 700; font-size: 15px; border: none; cursor: pointer; text-decoration: none; transition: all 0.2s; }
        .btn-green { background: var(--success); color: white; box-shadow: 0 4px 14px rgba(22,163,74,0.3); }
        .btn-green:hover { background: var(--success-dark); transform: translateY(-1px); }
        .btn-blue { background: var(--primary); color: white; box-shadow: 0 4px 14px rgba(30,58,138,0.25); }
        .btn-blue:hover { background: var(--primary-dark); }
        .btn-dark { background: #0f172a; color: white; }
        .btn-dark:hover { background: #1e293b; }

        .divider { display: flex; align-items: center; margin: 24px 0; color: var(--muted); font-size: 11.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; }
        .divider::before, .divider::after { content: ""; flex: 1; height: 1px; background: var(--border); }
        .divider::before { margin-right: 12px; }
        .divider::after { margin-left: 12px; }

        .form-group { margin-bottom: 14px; text-align: left; }
        .form-label { display: block; font-size: 13px; font-weight: 600; color: var(--text); margin-bottom: 6px; }
        .form-control { width: 100%; padding: 10px 14px; font-size: 14px; border: 1px solid var(--border); border-radius: 8px; font-family: inherit; }
        .form-control:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(30,58,138,0.1); }

        .user-table { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 13px; }
        .user-table th { background: #f1f5f9; padding: 8px 10px; text-align: left; font-weight: 600; color: var(--muted); border-bottom: 1px solid var(--border); }
        .user-table td { padding: 8px 10px; border-bottom: 1px solid var(--border); }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
        .badge-admin { background: #dbeafe; color: #1e40af; }
        .badge-appr { background: #dcfce7; color: #15803d; }
    </style>
</head>
<body>

<div class="wrap">
    <div class="card">
        <h1>EP NKORE - Database & Admin Setup</h1>
        <p class="subtitle">Koresha iyi paji gushyiramo database cyangwa kwinjira ako kanya muri Dashboard utiriwe ukoresha phpMyAdmin!</p>

        <?php if (!empty($message)): ?>
            <div class="alert alert-<?= $status ?>"><?= $message ?></div>
        <?php endif; ?>

        <!-- BUTO YA 1: ONE-CLICK INSTANT LOGIN -->
        <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 20px; margin-bottom: 20px; text-align: center;">
            <div style="font-size: 12px; font-weight: 700; color: #166534; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">Uburyo Bwihuse cyane</div>
            <h3 style="margin: 0 0 8px 0; color: #14532d; font-size: 18px;">⚡ Injira muri Dashboard Ako Kanya (One-Click)</h3>
            <p style="margin: 0 0 16px 0; font-size: 13.5px; color: #15803d; line-height: 1.5;">
                Kanda kuri iyi buto y'icyatsi uhite winjira muri Dashboard y'Ikigo ako kanya. Ihita yiremera konti ya Admin n'iyo yaba itari muri database!
            </p>
            <form method="POST">
                <button type="submit" name="direct_login" value="1" class="btn btn-green">
                    👉 KANDA HANO WINJIRE MURI DASHBOARD
                </button>
            </form>
        </div>

        <!-- BUTO YA 2: AUTO-IMPORT FULL DATABASE (ZERO PHPMYADMIN NEEDED) -->
        <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 12px; padding: 20px; margin-bottom: 20px; text-align: center;">
            <div style="font-size: 12px; font-weight: 700; color: #1e40af; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">Kwinjiza Database Yose (Auto-Import)</div>
            <h3 style="margin: 0 0 8px 0; color: #1e3a8a; font-size: 18px;">📦 Shyiramo Database Yose (Utiriwe ukora Upload muri phpMyAdmin)</h3>
            <p style="margin: 0 0 16px 0; font-size: 13.5px; color: #1e40af; line-height: 1.5;">
                Niba utarabashije gukora upload muri phpMyAdmin, kanda hano uhite wibwiriza gushyiramo tables zose (22 tables), amasomo, abanyeshuri n'abarezi mu kanya gato:
            </p>
            <form method="POST">
                <button type="submit" name="import_database" value="1" class="btn btn-blue">
                    📥 SHYIRAMO DATABASE YOSE AKO KANYA (1-Click Import)
                </button>
            </form>
        </div>

        <div class="divider">Imimerere ya Database Yawe (Status)</div>

        <!-- SECTION 3: DATABASE STATUS -->
        <div style="font-size: 13px; color: var(--muted); line-height: 1.8; background: #f8fafc; border: 1px solid var(--border); border-radius: 10px; padding: 14px;">
            <div>Database Host: <strong><?= e(DB_HOST) ?></strong></div>
            <div>Database Name: <strong><?= e(DB_NAME) ?></strong></div>
            <div>Umubare wa Tables zihari: <strong><?= count($existing_tables) ?> / 22 tables</strong></div>
            <div>Table `users`: <strong><?= $table_exists ? '<span style="color: #16a34a; font-weight: 700;">Ihise iboneka (' . count($current_users) . ' users)</span>' : '<span style="color: #dc2626; font-weight: 700;">Ntiraboneka (Kanda kuri Auto-Import hejuru)</span>' ?></strong></div>
        </div>

        <?php if (!empty($current_users)): ?>
            <div style="margin-top: 16px; font-size: 13px; font-weight: 600; color: var(--text);">Abayobozi bari muri Sisitemu ubu:</div>
            <table class="user-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Email / Phone</th>
                        <th>Urwego</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($current_users as $u): ?>
                        <tr>
                            <td><?= $u['id'] ?></td>
                            <td>
                                <strong><?= e($u['email']) ?></strong><br>
                                <span style="font-size: 11px; color: var(--muted);"><?= e($u['phone']) ?></span>
                            </td>
                            <td><span class="badge badge-admin"><?= e($u['role']) ?></span></td>
                            <td><span class="badge badge-appr"><?= e($u['status']) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <div style="margin-top: 24px; text-align: center; font-size: 14px;">
            <a href="login.php" style="color: var(--primary); font-weight: 600; text-decoration: none;">&larr; Subira kuri Ifishi isanzwe yo kwinjira (login.php)</a>
        </div>
    </div>
</div>

</body>
</html>
