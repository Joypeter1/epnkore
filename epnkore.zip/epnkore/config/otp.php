<?php
/**
 * EP NKORE - School Management System
 * OTP (One-Time Password) & SMS Configuration
 * 
 * Flexible OTP delivery:
 * 1. OTP_DEV_MODE = true (Default):
 *    In development/testing, OTP is displayed on screen and logged to a local session file,
 *    allowing immediate testing without an active SMS gateway or credit balance.
 * 
 * 2. OTP_DEV_MODE = false (Production):
 *    Dispatches SMS via configurable SMS HTTP/REST gateway (Rwanda-compatible: Africa's Talking,
 *    Pindo, MNotify, Twilio, or any generic HTTP SMS gateway).
 */

// Environment Mode: Set to false in production after entering real SMS credentials
define('OTP_DEV_MODE', true);

// OTP Security Parameters
define('OTP_LENGTH', 6);
define('OTP_EXPIRY_MINUTES', 5);    // Valid for 5 minutes
define('OTP_MAX_ATTEMPTS', 3);      // Max 3 incorrect attempts before lockout
define('OTP_RESEND_COOLDOWN', 60);  // 60 seconds before allowing resend

// SMS Provider Placeholders (Do not commit real keys!)
define('SMS_PROVIDER', 'generic_http'); // 'dev', 'generic_http', 'africastalking', 'pindo'
define('SMS_API_KEY', 'YOUR_SMS_API_KEY_HERE');
define('SMS_API_SECRET', 'YOUR_SMS_API_SECRET_HERE');
define('SMS_SENDER_ID', 'EP_NKORE');
define('SMS_API_URL', 'https://api.sms-provider.com/v1/send'); // Generic API endpoint

/**
 * Generates a cryptographically secure 6-digit OTP
 */
function generate_secure_otp($length = 6) {
    return str_pad((string)random_int(100000, 999999), $length, '0', STR_PAD_LEFT);
}

/**
 * Dispatch OTP via configured SMS Gateway or Development Simulator
 * 
 * @param string $phone Recipient phone number (e.g. +250788123456)
 * @param string $otp_code The 6-digit OTP code
 * @return array ['success' => bool, 'message' => string, 'dev_code' => string|null]
 */
function send_otp_sms($phone, $otp_code) {
    $message = "Your EP NKORE verification code is: {$otp_code}. Valid for " . OTP_EXPIRY_MINUTES . " minutes. Do NOT share this code with anyone.";

    // If development mode is ON, simulate SMS delivery safely
    if (OTP_DEV_MODE === true) {
        // Record in error log and session for easy testing
        error_log("[EP NKORE OTP SIMULATION] To: {$phone} | Code: {$otp_code} | Msg: {$message}");
        
        return [
            'success' => true,
            'message' => 'OTP generated successfully (Development Mode Active)',
            'dev_code' => $otp_code
        ];
    }

    // Production SMS dispatch via cURL
    if (empty(SMS_API_KEY) || SMS_API_KEY === 'YOUR_SMS_API_KEY_HERE') {
        error_log("[EP NKORE SMS ERROR] SMS_API_KEY is not configured in config/otp.php");
        return [
            'success' => false,
            'message' => 'SMS Gateway is not configured. Please contact the administrator.',
            'dev_code' => null
        ];
    }

    // Generic HTTP POST SMS dispatch
    $post_data = [
        'api_key'   => SMS_API_KEY,
        'sender_id' => SMS_SENDER_ID,
        'recipient' => $phone,
        'message'   => $message
    ];

    $ch = curl_init(SMS_API_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($http_code >= 200 && $http_code < 300) {
        return [
            'success' => true,
            'message' => 'SMS sent successfully.',
            'dev_code' => null
        ];
    } else {
        error_log("[EP NKORE SMS ERROR] Failed to send SMS to {$phone}. HTTP: {$http_code}, Error: {$curl_error}, Response: {$response}");
        return [
            'success' => false,
            'message' => 'Failed to dispatch SMS. Please try again or contact administrator.',
            'dev_code' => null
        ];
    }
}
