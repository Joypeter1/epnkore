<?php
/**
 * EP NKORE - School Management System
 * Database Configuration File
 * 
 * IMPORTANT INSTRUCTIONS FOR SHARED HOSTING (e.g. InfinityFree / cPanel):
 * 1. Log in to your hosting Control Panel (vPanel / cPanel).
 * 2. Go to "MySQL Databases" to find your database credentials.
 * 3. Replace the placeholder values below with your real credentials.
 * 
 * Note for InfinityFree users:
 * - DB_HOST is usually something like 'sql300.infinityfree.com' (NOT localhost).
 * - DB_USER is usually something like 'epiz_12345678'.
 * - DB_NAME is usually something like 'epiz_12345678_ep_nkore'.
 * - DB_PASS is your hosting vPanel/account password.
 */

// DO NOT USE 'localhost' or 'root' with empty password on production shared hosting!
define('DB_HOST', 'sql_hostname_here');       // Example: sql300.infinityfree.com
define('DB_NAME', 'ep_nkore_db_name');       // Example: epiz_34567890_ep_nkore
define('DB_USER', 'db_username_here');       // Example: epiz_34567890
define('DB_PASS', 'db_password_here');       // Your hosting MySQL password
define('DB_PORT', '3306');
define('DB_CHARSET', 'utf8mb4');

/**
 * Returns a secure PDO instance.
 * Gracefully handles connection failures without exposing raw database credentials to end users.
 */
function get_db_connection() {
    static $pdo = null;

    if ($pdo === null) {
        // DSN configuration
        $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
            PDO::MYSQL_ATTR_MULTI_STATEMENTS => true
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Log real error on the server for debugging
            error_log("Database Connection Error: " . $e->getMessage());
            
            // Show a clean, user-friendly error page without exposing passwords
            http_response_code(500);
            die("
            <!DOCTYPE html>
            <html lang='en'>
            <head>
                <meta charset='UTF-8'>
                <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                <title>Database Connection Error - EP NKORE</title>
                <style>
                    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f8fafc; color: #1e293b; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 20px; }
                    .box { background: white; max-width: 540px; padding: 32px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.06); border-top: 5px solid #ef4444; }
                    h2 { margin-top: 0; color: #b91c1c; font-size: 22px; }
                    p { font-size: 15px; line-height: 1.6; color: #475569; }
                    .hint { background: #f1f5f9; padding: 14px; border-radius: 8px; font-size: 13px; margin: 16px 0; border-left: 3px solid #3b82f6; }
                    code { background: #e2e8f0; padding: 2px 6px; border-radius: 4px; font-size: 13px; color: #0f172a; }
                </style>
            </head>
            <body>
                <div class='box'>
                    <h2>Database Connection Notice</h2>
                    <p>EP NKORE could not connect to MySQL using your settings in <code>config/database.php</code>.</p>
                    <div style='background: #fee2e2; border: 1px solid #fca5a5; padding: 12px; border-radius: 8px; color: #991b1b; font-size: 13px; font-family: monospace; word-break: break-all; margin: 12px 0;'>
                        <strong>Server Message:</strong> " . htmlspecialchars($e->getMessage()) . "
                    </div>
                    <div class='hint'>
                        <strong>Quick Fix Checklist:</strong><br>
                        1. Open <strong>config/database.php</strong> in Online File Manager.<br>
                        2. Verify <code>DB_HOST</code> (usually something like <code>sql300.infinityfree.com</code>).<br>
                        3. Verify <code>DB_USER</code> (your epiz_... username) and <code>DB_PASS</code>.<br>
                        4. Verify <code>DB_NAME</code> (e.g. epiz_..._epnkore).
                    </div>
                </div>
            </body>
            </html>
            ");
        }
    }

    return $pdo;
}

// Instantiate global $pdo for includes
$pdo = get_db_connection();
