/**
 * EP NKORE - School Management System
 * Vanilla JavaScript (Zero-dependency, mobile-friendly)
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Mobile Sidebar Toggle
    const sidebarToggle = document.getElementById('sidebarToggle');
    const appSidebar = document.getElementById('appSidebar');

    if (sidebarToggle && appSidebar) {
        sidebarToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            appSidebar.classList.toggle('show');
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', (e) => {
            if (appSidebar.classList.contains('show') && !appSidebar.contains(e.target) && e.target !== sidebarToggle) {
                appSidebar.classList.remove('show');
            }
        });
    }

    // 2. User Menu Dropdown Toggle
    const userMenuBtn = document.getElementById('userMenuBtn');
    const userMenuDropdown = document.getElementById('userMenuDropdown');

    if (userMenuBtn && userMenuDropdown) {
        userMenuBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            userMenuDropdown.classList.toggle('show');
        });

        document.addEventListener('click', () => {
            userMenuDropdown.classList.remove('show');
        });
    }

    // 3. Real-time Password Strength Meter
    const regPassword = document.getElementById('regPassword');
    const regConfirmPassword = document.getElementById('regConfirmPassword');

    if (regPassword) {
        const reqLength = document.getElementById('reqLength');
        const reqUpper = document.getElementById('reqUpper');
        const reqLower = document.getElementById('reqLower');
        const reqNumber = document.getElementById('reqNumber');
        const reqSpecial = document.getElementById('reqSpecial');
        const reqMatch = document.getElementById('reqMatch');

        const updateRequirements = () => {
            const val = regPassword.value;
            const confirmVal = regConfirmPassword ? regConfirmPassword.value : '';

            // Length
            if (reqLength) {
                setValid(reqLength, val.length >= 8);
            }
            // Upper
            if (reqUpper) {
                setValid(reqUpper, /[A-Z]/.test(val));
            }
            // Lower
            if (reqLower) {
                setValid(reqLower, /[a-z]/.test(val));
            }
            // Number
            if (reqNumber) {
                setValid(reqNumber, /[0-9]/.test(val));
            }
            // Special
            if (reqSpecial) {
                setValid(reqSpecial, /[\W_]/.test(val));
            }
            // Match
            if (reqMatch && regConfirmPassword) {
                setValid(reqMatch, val.length > 0 && val === confirmVal);
            }
        };

        const setValid = (el, isValid) => {
            if (isValid) {
                el.classList.add('valid');
                el.classList.remove('invalid');
                el.querySelector('.req-icon').textContent = '✓';
            } else {
                el.classList.remove('valid');
                el.classList.add('invalid');
                el.querySelector('.req-icon').textContent = '○';
            }
        };

        regPassword.addEventListener('input', updateRequirements);
        if (regConfirmPassword) {
            regConfirmPassword.addEventListener('input', updateRequirements);
        }
    }

    // 4. OTP Countdown Timer
    const resendBtn = document.getElementById('otpResendBtn');
    const timerText = document.getElementById('otpTimerText');
    const timerSpan = document.getElementById('otpTimer');

    if (resendBtn && timerSpan) {
        let secondsLeft = 60;
        const interval = setInterval(() => {
            secondsLeft--;
            if (secondsLeft <= 0) {
                clearInterval(interval);
                resendBtn.removeAttribute('disabled');
                if (timerText) timerText.style.display = 'none';
            } else {
                timerSpan.textContent = secondsLeft;
            }
        }, 1000);
    }

    // 5. Dynamic Marks Grading Helper in Mark Entry table
    document.querySelectorAll('.mark-input-field').forEach(input => {
        input.addEventListener('input', function() {
            const row = this.closest('tr');
            if (!row) return;

            const max = parseFloat(this.getAttribute('data-max') || 100);
            const val = parseFloat(this.value);
            const badgeEl = row.querySelector('.grade-badge-preview');

            if (isNaN(val)) {
                if (badgeEl) badgeEl.textContent = '-';
                return;
            }

            if (val < 0) this.value = 0;
            if (val > max) this.value = max;

            const safeVal = Math.min(Math.max(parseFloat(this.value) || 0, 0), max);
            const pct = (safeVal / max) * 100;
            let grade = 'F';
            let bg = 'badge-danger';

            if (pct >= 80) { grade = 'A'; bg = 'badge-approved'; }
            else if (pct >= 70) { grade = 'B'; bg = 'badge-approved'; }
            else if (pct >= 60) { grade = 'C'; bg = 'badge-pending'; }
            else if (pct >= 50) { grade = 'D'; bg = 'badge-pending'; }

            if (badgeEl) {
                badgeEl.textContent = grade + ' (' + pct.toFixed(0) + '%)';
                badgeEl.className = 'badge grade-badge-preview ' + bg;
            }
        });
    });

    // 6. Attendance Quick "Mark All Present" Helper
    const markAllPresentBtn = document.getElementById('markAllPresentBtn');
    if (markAllPresentBtn) {
        markAllPresentBtn.addEventListener('click', () => {
            document.querySelectorAll('input[type="radio"][value="Present"]').forEach(radio => {
                radio.checked = true;
            });
        });
    }

    // 7. Generic Print Button
    document.querySelectorAll('.btn-print-trigger').forEach(btn => {
        btn.addEventListener('click', () => {
            window.print();
        });
    });
});
