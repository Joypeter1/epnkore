<?php
/**
 * EP NKORE - School Management System
 * School News, Photos & Video Updates Manager (Admin & Head Teacher)
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, ['Head Teacher', 'Administrator']);

// Handle Post, Edit, and Delete Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    if (verify_csrf_token($csrf)) {
        $action = $_POST['action'];

        if ($action === 'create_update') {
            $title = trim($_POST['title'] ?? '');
            $summary = trim($_POST['summary'] ?? '');
            $content = trim($_POST['content'] ?? '');
            $media_type = in_array($_POST['media_type'] ?? '', ['text', 'image', 'video']) ? $_POST['media_type'] : 'image';
            $image_url = trim($_POST['image_url'] ?? '');
            $video_url = trim($_POST['video_url'] ?? '');
            $is_published = isset($_POST['is_published']) ? 1 : 0;

            // Handle direct image upload if provided
            if (isset($_FILES['image_file']) && $_FILES['image_file']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['image_file'];
                $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'])) {
                    $target_dir = __DIR__ . '/../uploads/news/';
                    if (!is_dir($target_dir)) {
                        mkdir($target_dir, 0755, true);
                    }
                    $new_filename = time() . '_' . uniqid() . '.' . $ext;
                    if (move_uploaded_file($file['tmp_name'], $target_dir . $new_filename)) {
                        $image_url = 'uploads/news/' . $new_filename;
                    }
                }
            }

            // Standardize YouTube video links to embed format if needed
            if (!empty($video_url)) {
                if (preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $video_url, $match)) {
                    $video_url = 'https://www.youtube.com/embed/' . $match[1];
                }
            }

            if (!empty($title) && !empty($content)) {
                $stmt = $pdo->prepare("INSERT INTO news_updates (author_id, title, summary, content, media_type, image_url, video_url, is_published) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$current_user['id'], $title, $summary, $content, $media_type, $image_url, $video_url, $is_published]);
                $news_id = $pdo->lastInsertId();

                log_audit($pdo, $current_user['id'], 'NEWS_POSTED', "Published news update #{$news_id}: {$title}");
                set_flash('success', "News update '<strong>" . e($title) . "</strong>' published successfully to website.");
                header('Location: news.php');
                exit;
            } else {
                set_flash('danger', 'Title and full article content are required.');
            }
        } elseif ($action === 'delete_update') {
            $news_id = (int)($_POST['news_id'] ?? 0);
            $del = $pdo->prepare("DELETE FROM news_updates WHERE id = ?");
            $del->execute([$news_id]);
            log_audit($pdo, $current_user['id'], 'NEWS_DELETED', "Deleted news update #{$news_id}");
            set_flash('success', 'Update deleted successfully.');
            header('Location: news.php');
            exit;
        } elseif ($action === 'toggle_publish') {
            $news_id = (int)($_POST['news_id'] ?? 0);
            $current_state = (int)($_POST['current_state'] ?? 0);
            $new_state = $current_state ? 0 : 1;
            $upd = $pdo->prepare("UPDATE news_updates SET is_published = ? WHERE id = ?");
            $upd->execute([$new_state, $news_id]);
            set_flash('success', $new_state ? 'Update is now live on the website.' : 'Update was unpublished and moved to draft.');
            header('Location: news.php');
            exit;
        }
    }
}

$all_news = $pdo->query("SELECT n.*, u.first_name, u.last_name 
                         FROM news_updates n 
                         LEFT JOIN users u ON n.author_id = u.id 
                         ORDER BY n.id DESC")->fetchAll();

$page_title = "School News & Updates Manager - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">School News, Photos & Videos Manager</h1>
            <p class="page-subtitle">Post official school announcements, event photos, and video updates for website visitors and parents</p>
        </div>
        <div>
            <a href="<?= get_base_url() ?>news.php" target="_blank" class="btn btn-outline btn-sm">
                View Public News ↗
            </a>
            <button type="button" class="btn btn-primary btn-sm" onclick="document.getElementById('postNewsCard').scrollIntoView({behavior: 'smooth'})">
                + Post New Update
            </button>
        </div>
    </div>

    <!-- News Articles List -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-header">
            <h3 class="card-title">School Updates Published (<?= count($all_news) ?>)</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Media</th>
                            <th>Title & Summary</th>
                            <th>Media Type</th>
                            <th>Author</th>
                            <th>Date Posted</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($all_news)): ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 24px; color: #64748b;">
                                    No news updates published yet. Post your first update below!
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($all_news as $n): ?>
                                <tr>
                                    <td style="width: 70px;">
                                        <?php if (!empty($n['image_url'])): ?>
                                            <img src="<?= (strpos($n['image_url'], 'http') === 0 ? '' : get_base_url()) . e($n['image_url']) ?>" alt="Thumbnail" style="width: 60px; height: 42px; object-fit: cover; border-radius: 4px;">
                                        <?php elseif ($n['media_type'] === 'video'): ?>
                                            <div style="width: 60px; height: 42px; background: #0f172a; color: white; display: flex; align-items: center; justify-content: center; border-radius: 4px; font-size: 14px;">▶</div>
                                        <?php else: ?>
                                            <div style="width: 60px; height: 42px; background: #f1f5f9; color: #64748b; display: flex; align-items: center; justify-content: center; border-radius: 4px; font-size: 14px;">📄</div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong><?= e($n['title']) ?></strong>
                                        <?php if (!empty($n['summary'])): ?>
                                            <div style="font-size: 12px; color: #64748b; max-width: 400px;"><?= e(substr($n['summary'], 0, 120)) ?>...</div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?= $n['media_type'] === 'video' ? 'danger' : ($n['media_type'] === 'image' ? 'success' : 'info') ?>">
                                            <?= ucfirst(e($n['media_type'])) ?>
                                        </span>
                                    </td>
                                    <td style="font-size: 12px;"><?= e(($n['first_name'] ?? 'Admin') . ' ' . ($n['last_name'] ?? '')) ?></td>
                                    <td style="font-size: 12px; color: #64748b;"><?= date('M d, Y', strtotime($n['published_at'])) ?></td>
                                    <td>
                                        <form action="news.php" method="POST" style="display: inline-block;">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="action" value="toggle_publish">
                                            <input type="hidden" name="news_id" value="<?= $n['id'] ?>">
                                            <input type="hidden" name="current_state" value="<?= $n['is_published'] ?>">
                                            <button type="submit" class="btn btn-<?= $n['is_published'] ? 'success' : 'secondary' ?> btn-sm" style="font-size: 11px; padding: 2px 8px;">
                                                <?= $n['is_published'] ? 'Published' : 'Draft' ?>
                                            </button>
                                        </form>
                                    </td>
                                    <td>
                                        <form action="news.php" method="POST" onsubmit="return confirm('Delete this news update?');" style="display: inline-block;">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="action" value="delete_update">
                                            <input type="hidden" name="news_id" value="<?= $n['id'] ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Create News Form Card -->
    <div class="card" id="postNewsCard">
        <div class="card-header">
            <h3 class="card-title">+ Post New School Update (Text, Photos or Videos)</h3>
        </div>
        <div class="card-body" style="padding: 24px;">
            <form action="news.php" method="POST" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_update">

                <div style="margin-bottom: 16px;">
                    <label class="form-label">Headline / Title *</label>
                    <input type="text" name="title" class="form-control" placeholder="e.g. EP NKORE Celebrates Outstanding 100% PLE Exam Results" required>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
                    <div>
                        <label class="form-label">Format / Media Type *</label>
                        <select name="media_type" id="mediaTypeSelect" class="form-select" onchange="toggleMediaInputs(this.value)" required>
                            <option value="image">Photo Story (Amashusho n'Amagambo)</option>
                            <option value="video">Video Showcase (Video + Ibisobanuro)</option>
                            <option value="text">Announcement / Text Article (Amagambo gusa)</option>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Publication Status</label>
                        <label style="display: flex; align-items: center; gap: 8px; margin-top: 10px; cursor: pointer;">
                            <input type="checkbox" name="is_published" value="1" checked style="width: 18px; height: 18px;">
                            <span style="font-size: 13px;">Publish immediately on the website homepage</span>
                        </label>
                    </div>
                </div>

                <!-- Image Upload & URL Section -->
                <div id="imageInputSection" style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; background: #f8fafc; padding: 14px; border-radius: 8px; border: 1px solid #e2e8f0;">
                    <div>
                        <label class="form-label" style="font-size: 12px;">Upload Photo from Computer/Phone</label>
                        <input type="file" name="image_file" class="form-control" accept="image/*">
                        <small style="color: #64748b; font-size: 11px;">Supports JPG, PNG, WEBP</small>
                    </div>
                    <div>
                        <label class="form-label" style="font-size: 12px;">OR Enter Image Web URL</label>
                        <input type="url" name="image_url" class="form-control" placeholder="https://images.unsplash.com/...">
                    </div>
                </div>

                <!-- Video URL Section -->
                <div id="videoInputSection" style="display: none; margin-bottom: 16px; background: #fef2f2; padding: 14px; border-radius: 8px; border: 1px solid #fecaca;">
                    <label class="form-label" style="font-size: 12px;">YouTube Video Link or Embed URL</label>
                    <input type="url" name="video_url" class="form-control" placeholder="https://www.youtube.com/watch?v=... or https://youtu.be/...">
                    <small style="color: #991b1b; font-size: 11px;">Visitors will be able to play this video directly inside the school website.</small>
                </div>

                <div style="margin-bottom: 16px;">
                    <label class="form-label">Short Summary (Brief teaser shown in cards)</label>
                    <input type="text" name="summary" class="form-control" placeholder="1-2 sentences summarizing the update...">
                </div>

                <div style="margin-bottom: 20px;">
                    <label class="form-label">Full Article / Details *</label>
                    <textarea name="content" class="form-control" rows="5" placeholder="Write full details about the event, announcement, guidelines or achievement..." required></textarea>
                </div>

                <button type="submit" class="btn btn-primary btn-lg">Publish School Update</button>
            </form>
        </div>
    </div>
</div>

<script>
function toggleMediaInputs(val) {
    var imgSec = document.getElementById('imageInputSection');
    var vidSec = document.getElementById('videoInputSection');
    if (val === 'image') {
        imgSec.style.display = 'grid';
        vidSec.style.display = 'none';
    } else if (val === 'video') {
        imgSec.style.display = 'grid';
        vidSec.style.display = 'block';
    } else {
        imgSec.style.display = 'none';
        vidSec.style.display = 'none';
    }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
