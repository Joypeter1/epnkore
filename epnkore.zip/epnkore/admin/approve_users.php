<?php
/**
 * EP NKORE - School Management System
 * Pending User Approvals Management
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, 'Administrator');

// Process Approval / Rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    if (verify_csrf_token($csrf)) {
        $user_id = (int)($_POST['user_id'] ?? 0);
        $action = $_POST['action'];

        if ($action === 'approve') {
            $stmt = $pdo->prepare("UPDATE users SET status = 'APPROVED' WHERE id = ?");
            $stmt->execute([$user_id]);
            log_audit($pdo, $current_user['id'], 'USER_APPROVED', "Approved account registration for User ID #{$user_id}");
            set_flash('success', "User #{$user_id} has been APPROVED and can now sign in.");
        } elseif ($action === 'reject') {
            $stmt = $pdo->prepare("UPDATE users SET status = 'REJECTED' WHERE id = ?");
            $stmt->execute([$user_id]);
            log_audit($pdo, $current_user['id'], 'USER_REJECTED', "Rejected account registration for User ID #{$user_id}");
            set_flash('warning', "User #{$user_id} has been REJECTED.");
        }
        header('Location: approve_users.php');
        exit;
    }
}

// Fetch pending users
$stmt = $pdo->query("SELECT * FROM users WHERE status = 'PENDING' ORDER BY created_at ASC");
$pending_users = $stmt->fetchAll();

// Fetch recently processed users
$processed_stmt = $pdo->query("SELECT * FROM users WHERE status IN ('APPROVED', 'REJECTED') ORDER BY updated_at DESC LIMIT 8");
$processed_users = $processed_stmt->fetchAll();

$page_title = "Approve User Accounts - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">User Account Approvals</h1>
            <p class="page-subtitle">Review pending registrations and authorize access for Teachers, Head Teachers, and Administrators</p>
        </div>
        <div>
            <a href="users.php" class="btn btn-outline btn-sm">All System Users</a>
        </div>
    </div>

    <!-- Pending Queue -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Pending Account Requests (<?= count($pending_users) ?>)</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <?php if (empty($pending_users)): ?>
                <div style="padding: 40px; text-align: center; color: var(--slate-500);">
                    <div style="font-size: 36px; margin-bottom: 8px;">✓</div>
                    <h3 style="font-size: 18px; color: var(--slate-700);">No Pending Approvals</h3>
                    <p style="font-size: 14px; margin-top: 4px;">All submitted registrations have been verified and processed.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Photo</th>
                                <th>Full Name</th>
                                <th>Role Requested</th>
                                <th>Phone (For OTP)</th>
                                <th>Email</th>
                                <th>Registration Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($pending_users as $user): ?>
                                <tr>
                                    <td>
                                        <div class="user-avatar-sm">
                                            <?= strtoupper(substr($user['first_name'], 0, 1) . substr($user['last_name'], 0, 1)) ?>
                                        </div>
                                    </td>
                                    <td><strong><?= e($user['first_name'] . ' ' . $user['last_name']) ?></strong></td>
                                    <td>
                                        <span class="badge badge-<?= strtolower(str_replace(' ', '-', $user['role'])) ?>">
                                            <?= e($user['role']) ?>
                                        </span>
                                    </td>
                                    <td><?= e($user['phone']) ?></td>
                                    <td><?= e($user['email']) ?></td>
                                    <td><?= date('M d, Y H:i', strtotime($user['created_at'])) ?></td>
                                    <td>
                                        <div style="display: flex; gap: 6px;">
                                            <form action="approve_users.php" method="POST">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                <input type="hidden" name="action" value="approve">
                                                <button type="submit" class="btn btn-success btn-sm">
                                                    ✓ Approve
                                                </button>
                                            </form>
                                            <form action="approve_users.php" method="POST" onsubmit="return confirm('Are you sure you want to reject this account registration?');">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                <input type="hidden" name="action" value="reject">
                                                <button type="submit" class="btn btn-danger btn-sm">
                                                    ✕ Reject
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Recently Processed -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Recently Processed Accounts</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Phone</th>
                            <th>Last Updated</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($processed_users as $p): ?>
                            <tr>
                                <td>
                                    <strong><?= e($p['first_name'] . ' ' . $p['last_name']) ?></strong>
                                    <div style="font-size: 11.5px; color: var(--slate-500);"><?= e($p['email']) ?></div>
                                </td>
                                <td><?= e($p['role']) ?></td>
                                <td>
                                    <span class="badge badge-<?= strtolower($p['status']) ?>">
                                        <?= e($p['status']) ?>
                                    </span>
                                </td>
                                <td><?= e($p['phone']) ?></td>
                                <td><?= date('M d, Y H:i', strtotime($p['updated_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
