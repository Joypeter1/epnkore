<?php
/**
 * EP NKORE - School Management System
 * Academic Report Card & School Reports Generator
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, ['Administrator', 'Head Teacher', 'Teacher']);

$type = $_GET['type'] ?? 'overview';
$student_id = (int)($_GET['student_id'] ?? 0);
$class_id = (int)($_GET['class_id'] ?? 0);
$term = sanitize_input($_GET['term'] ?? 'Term 1');

// Fetch System Settings
$settings = [];
$st_rows = $pdo->query("SELECT setting_key, setting_value FROM system_settings")->fetchAll();
foreach ($st_rows as $row) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
$school_name = $settings['school_name'] ?? 'EP NKORE';
$school_motto = $settings['school_motto'] ?? 'Excellence in Education and Integrity';
$school_phone = $settings['school_phone'] ?? '+250 781 125 809';
$school_email = $settings['school_email'] ?? 'jeanpierret772@gmail.com';
$school_address = $settings['school_address'] ?? 'Nyamagabe District, Musange Sector, Masangano Cell, Gasagara Village';

// 1. Single Student Academic Report Card
$student = null;
$student_marks = [];
$student_attendance = ['present' => 0, 'absent' => 0, 'late' => 0, 'excused' => 0];

if ($type === 'student' && $student_id > 0) {
    // Fetch student profile
    $stmt_s = $pdo->prepare("
        SELECT s.*, c.name as class_name, a.name as year_name
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.id
        LEFT JOIN academic_years a ON s.academic_year_id = a.id
        WHERE s.id = ?
    ");
    $stmt_s->execute([$student_id]);
    $student = $stmt_s->fetch();

    if ($student) {
        // Fetch marks for selected term
        $stmt_m = $pdo->prepare("
            SELECT m.*, sub.name as subject_name, sub.code as subject_code
            FROM marks m
            JOIN subjects sub ON m.subject_id = sub.id
            WHERE m.student_id = ? AND m.term = ?
            ORDER BY sub.name ASC
        ");
        $stmt_m->execute([$student_id, $term]);
        $student_marks = $stmt_m->fetchAll();

        // Fetch attendance stats for this student
        $stmt_att = $pdo->prepare("
            SELECT status, COUNT(*) as count
            FROM attendance
            WHERE student_id = ?
            GROUP BY status
        ");
        $stmt_att->execute([$student_id]);
        while ($r = $stmt_att->fetch()) {
            $k = strtolower($r['status']);
            if (isset($student_attendance[$k])) {
                $student_attendance[$k] = (int)$r['count'];
            }
        }
    }
}

// 2. Class Performance Summary
$class_students = [];
$class_info = null;
if ($type === 'class_performance' && $class_id > 0) {
    $stmt_c = $pdo->prepare("SELECT * FROM classes WHERE id = ?");
    $stmt_c->execute([$class_id]);
    $class_info = $stmt_c->fetch();

    $stmt_cp = $pdo->prepare("
        SELECT s.id, s.student_id_number, s.first_name, s.last_name, s.gender,
               AVG(m.marks_obtained) as average_mark,
               COUNT(m.id) as subjects_count
        FROM students s
        LEFT JOIN marks m ON s.id = m.student_id AND m.term = ?
        WHERE s.class_id = ? AND s.status = 'Active'
        GROUP BY s.id
        ORDER BY average_mark DESC
    ");
    $stmt_cp->execute([$term, $class_id]);
    $class_students = $stmt_cp->fetchAll();
}

$all_classes = $pdo->query("SELECT id, name FROM classes ORDER BY name ASC")->fetchAll();
$all_students = $pdo->query("SELECT id, student_id_number, first_name, last_name FROM students WHERE status = 'Active' ORDER BY first_name ASC")->fetchAll();

$page_title = "Academic Reports - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <!-- Non-printable Filter Toolbar -->
    <div class="page-header no-print">
        <div>
            <h1 class="page-title">School Reports & Terminal Bulletins</h1>
            <p class="page-subtitle">Official primary school report cards, class rosters, and performance sheets</p>
        </div>
        <div style="display: flex; gap: 8px;">
            <button type="button" class="btn btn-primary btn-sm btn-print-trigger">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                Print / Save PDF
            </button>
        </div>
    </div>

    <!-- Filter Card (Hidden when printing) -->
    <div class="card no-print" style="margin-bottom: 24px;">
        <div class="card-body" style="padding: 16px 20px;">
            <div style="display: flex; gap: 16px; flex-wrap: wrap;">
                <!-- Student Report Card Filter Form -->
                <form method="GET" action="reports.php" style="display: flex; gap: 8px; flex-wrap: wrap; align-items: flex-end; flex: 1; min-width: 300px;">
                    <input type="hidden" name="type" value="student">
                    <div style="flex: 1; min-width: 180px;">
                        <label class="form-label" style="font-size: 12px;">Select Pupil for Report Card</label>
                        <select name="student_id" class="form-select" required>
                            <option value="">Choose Student</option>
                            <?php foreach ($all_students as $s): ?>
                                <option value="<?= $s['id'] ?>" <?= $student_id === (int)$s['id'] ? 'selected' : '' ?>>
                                    <?= e($s['first_name'] . ' ' . $s['last_name']) ?> (<?= e($s['student_id_number']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div style="min-width: 120px;">
                        <label class="form-label" style="font-size: 12px;">Term</label>
                        <select name="term" class="form-select">
                            <option value="Term 1" <?= $term === 'Term 1' ? 'selected' : '' ?>>Term 1</option>
                            <option value="Term 2" <?= $term === 'Term 2' ? 'selected' : '' ?>>Term 2</option>
                            <option value="Term 3" <?= $term === 'Term 3' ? 'selected' : '' ?>>Term 3</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary" style="height: 42px;">Load Bulletin</button>
                </form>

                <!-- Class Performance Summary Form -->
                <form method="GET" action="reports.php" style="display: flex; gap: 8px; flex-wrap: wrap; align-items: flex-end; min-width: 260px;">
                    <input type="hidden" name="type" value="class_performance">
                    <div>
                        <label class="form-label" style="font-size: 12px;">Class Ranking Sheet</label>
                        <select name="class_id" class="form-select" required>
                            <option value="">Choose Class</option>
                            <?php foreach ($all_classes as $c): ?>
                                <option value="<?= $c['id'] ?>" <?= $class_id === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-secondary" style="height: 42px;">View Class Sheet</button>
                </form>
            </div>
        </div>
    </div>

    <!-- 1. OFFICIAL STUDENT REPORT CARD / BULLETIN VIEW -->
    <?php if ($type === 'student' && $student): ?>
        <?php
            $total_obtained = 0;
            $total_possible = 0;
            foreach ($student_marks as $m) {
                $total_obtained += (float)$m['marks_obtained'];
                $total_possible += (float)$m['max_marks'];
            }
            $overall_pct = $total_possible > 0 ? ($total_obtained / $total_possible) * 100 : 0;
            $overall_grade = calculate_grade($overall_pct);
        ?>
        <div class="print-container">
            <div class="report-header">
                <div class="brand-crest" style="width: 60px; height: 60px; margin: 0 auto 8px;">
                    <svg viewBox="0 0 40 40" class="crest-svg" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect width="40" height="40" rx="8" fill="#1e3a8a"/>
                        <path d="M20 7L8 14L20 21L32 14L20 7Z" fill="#fbbf24"/>
                        <path d="M12 17.5V25.5C12 29 15.5 33 20 33C24.5 33 28 29 28 25.5V17.5L20 22.5L12 17.5Z" fill="#38bdf8"/>
                        <circle cx="20" cy="14" r="2.5" fill="#1e3a8a"/>
                    </svg>
                </div>
                <h1 style="font-size: 22px; font-weight: 800; text-transform: uppercase; color: #1e3a8a; margin: 0;"><?= e($school_name) ?></h1>
                <p style="font-size: 13px; font-style: italic; color: var(--slate-600); margin: 2px 0;"><?= e($school_motto) ?></p>
                <p style="font-size: 12px; color: var(--slate-500); margin: 0;"><?= e($school_address) ?> • <?= e($school_phone) ?> • <?= e($school_email) ?></p>
                <div style="border-bottom: 2px solid #1e3a8a; margin-top: 14px; padding-bottom: 6px;">
                    <h2 style="font-size: 16px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin: 0;">
                        Official Pupil Terminal Report Card — <?= e($term) ?>
                    </h2>
                </div>
            </div>

            <!-- Pupil Information Box -->
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; padding: 12px; background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: 6px; margin-bottom: 20px; font-size: 13.5px;">
                <div><strong>Pupil Name:</strong> <?= e($student['first_name'] . ' ' . $student['last_name']) ?></div>
                <div><strong>Student ID:</strong> <?= e($student['student_id_number']) ?></div>
                <div><strong>Gender:</strong> <?= e($student['gender']) ?></div>
                <div><strong>Class Stream:</strong> <?= e($student['class_name'] ?? 'N/A') ?></div>
                <div><strong>Academic Year:</strong> <?= e($student['year_name'] ?? '2025-2026') ?></div>
                <div><strong>Parent / Guardian:</strong> <?= e($student['parent_name']) ?></div>
            </div>

            <!-- Subject Marks Table -->
            <table class="report-table" style="margin-bottom: 20px;">
                <thead>
                    <tr>
                        <th style="width: 35%;">Subject / Learning Area</th>
                        <th style="text-align: center;">Max Marks</th>
                        <th style="text-align: center;">Marks Obtained</th>
                        <th style="text-align: center;">Percentage</th>
                        <th style="text-align: center;">Grade</th>
                        <th>Teacher Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($student_marks)): ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 24px; color: var(--slate-500);">
                                No exam marks recorded for this student in <?= e($term) ?>.
                            </td>
                        </tr>
                    <?php endif; ?>
                    <?php foreach ($student_marks as $m): ?>
                        <?php 
                            $pct = $m['max_marks'] > 0 ? ($m['marks_obtained'] / $m['max_marks']) * 100 : 0;
                        ?>
                        <tr>
                            <td><strong><?= e($m['subject_name']) ?></strong> (<?= e($m['subject_code']) ?>)</td>
                            <td style="text-align: center;"><?= number_format($m['max_marks'], 0) ?></td>
                            <td style="text-align: center; font-weight: 700;"><?= number_format($m['marks_obtained'], 1) ?></td>
                            <td style="text-align: center;"><?= number_format($pct, 1) ?>%</td>
                            <td style="text-align: center;">
                                <span class="badge badge-<?= $m['grade'] === 'A' || $m['grade'] === 'B' ? 'approved' : ($m['grade'] === 'C' ? 'pending' : 'danger') ?>">
                                    <?= e($m['grade']) ?>
                                </span>
                            </td>
                            <td><?= e($m['remarks'] ?: 'Satisfactory performance') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr style="background: var(--slate-100); font-weight: 700;">
                        <td>TOTALS / OVERALL AVERAGE</td>
                        <td style="text-align: center;"><?= number_format($total_possible, 0) ?></td>
                        <td style="text-align: center;"><?= number_format($total_obtained, 1) ?></td>
                        <td style="text-align: center;"><?= number_format($overall_pct, 1) ?>%</td>
                        <td style="text-align: center;"><span class="badge badge-approved" style="font-size: 14px;"><?= $overall_grade ?></span></td>
                        <td><?= $overall_pct >= 60 ? 'Promoted to Next Grade' : 'Needs Academic Remediation' ?></td>
                    </tr>
                </tfoot>
            </table>

            <!-- Attendance Summary Box -->
            <div style="display: flex; justify-content: space-between; border: 1px solid var(--slate-200); padding: 12px; border-radius: 6px; margin-bottom: 24px; background: #fff;">
                <div><strong>Attendance Summary:</strong></div>
                <div>Days Present: <span class="badge badge-approved"><?= $student_attendance['present'] ?></span></div>
                <div>Days Absent: <span class="badge badge-danger"><?= $student_attendance['absent'] ?></span></div>
                <div>Days Late: <span class="badge badge-pending"><?= $student_attendance['late'] ?></span></div>
                <div>Excused: <span class="badge badge-outline"><?= $student_attendance['excused'] ?></span></div>
            </div>

            <!-- Signatures Section -->
            <div class="report-signatures">
                <div class="signature-box">
                    <div class="signature-line"></div>
                    <div style="font-weight: 700; font-size: 13px;">Class Master / Teacher</div>
                    <div style="font-size: 11.5px; color: var(--slate-500);">Date & Signature</div>
                </div>
                <div class="signature-box">
                    <div class="signature-line"></div>
                    <div style="font-weight: 700; font-size: 13px;">Head Teacher / School Stamp</div>
                    <div style="font-size: 11.5px; color: var(--slate-500);"><?= e($school_name) ?> Administration</div>
                </div>
            </div>
        </div>

    <!-- 2. CLASS RANKING & PERFORMANCE VIEW -->
    <?php elseif ($type === 'class_performance' && $class_info): ?>
        <div class="print-container">
            <div class="report-header">
                <h1 style="font-size: 20px; font-weight: 800; color: #1e3a8a; margin: 0; text-transform: uppercase;"><?= e($school_name) ?></h1>
                <h2 style="font-size: 15px; font-weight: 700; margin: 4px 0;">Class Performance & Academic Ranking Sheet</h2>
                <p style="font-size: 13px; color: var(--slate-600); margin: 0;">Class: <strong><?= e($class_info['name']) ?></strong> | Term: <strong><?= e($term) ?></strong> | Generated: <?= date('M d, Y') ?></p>
            </div>

            <table class="report-table">
                <thead>
                    <tr>
                        <th style="width: 8%; text-align: center;">Rank</th>
                        <th>Student ID</th>
                        <th>Pupil Name</th>
                        <th>Gender</th>
                        <th style="text-align: center;">Subjects Tested</th>
                        <th style="text-align: center;">Average Mark</th>
                        <th style="text-align: center;">Overall Grade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($class_students)): ?>
                        <tr><td colspan="7" style="text-align: center; padding: 24px; color: var(--slate-500);">No pupils enrolled or marks recorded for this class.</td></tr>
                    <?php endif; ?>
                    <?php $rank = 1; foreach ($class_students as $cs): ?>
                        <?php 
                            $avg = (float)$cs['average_mark'];
                            $grd = calculate_grade($avg);
                        ?>
                        <tr>
                            <td style="text-align: center; font-weight: 700;">#<?= $rank++ ?></td>
                            <td><?= e($cs['student_id_number']) ?></td>
                            <td><strong><?= e($cs['first_name'] . ' ' . $cs['last_name']) ?></strong></td>
                            <td><?= e($cs['gender']) ?></td>
                            <td style="text-align: center;"><?= (int)$cs['subjects_count'] ?></td>
                            <td style="text-align: center; font-weight: 700;"><?= number_format($avg, 1) ?>%</td>
                            <td style="text-align: center;">
                                <span class="badge badge-<?= $grd === 'A' || $grd === 'B' ? 'approved' : 'pending' ?>"><?= $grd ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="report-signatures">
                <div class="signature-box">
                    <div class="signature-line"></div>
                    <div style="font-weight: 700; font-size: 13px;">Class Master</div>
                </div>
                <div class="signature-box">
                    <div class="signature-line"></div>
                    <div style="font-weight: 700; font-size: 13px;">Head of School Official Stamp</div>
                </div>
            </div>
        </div>

    <?php else: ?>
        <!-- Default State: Select a Report -->
        <div class="card" style="text-align: center; padding: 60px 20px;">
            <div style="font-size: 40px; margin-bottom: 12px; color: var(--primary);">📄</div>
            <h3 style="font-size: 20px; font-weight: 700; color: var(--slate-800);">Select a Report to Generate</h3>
            <p style="font-size: 14px; color: var(--slate-500); max-width: 500px; margin: 8px auto 20px;">
                Choose an enrolled pupil from the dropdown above to view an official Terminal Report Card, or select a class to view the full performance ranking sheet.
            </p>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
