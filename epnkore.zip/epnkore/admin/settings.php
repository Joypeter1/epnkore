<?php
/**
 * EP NKORE - School Management System
 * System Settings & Security Audit Logs (Administrator)
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, 'Administrator');

// Handle Settings Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf)) {
        set_flash('danger', 'Security token mismatch.');
        header('Location: settings.php');
        exit;
    }

    if ($_POST['action'] === 'save_school_info') {
        $allowed_keys = ['school_name', 'school_motto', 'school_phone', 'school_email', 'school_address', 'active_term'];
        foreach ($allowed_keys as $key) {
            if (isset($_POST[$key])) {
                $val = sanitize_input($_POST[$key]);
                $stmt = $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
                $stmt->execute([$key, $val, $val]);
            }
        }
        log_audit($pdo, $current_user['id'], 'SETTINGS_UPDATED', 'Updated school general configurations');
        set_flash('success', 'General school information updated successfully.');
        header('Location: settings.php');
        exit;

    } elseif ($_POST['action'] === 'add_academic_year') {
        $year_name = sanitize_input($_POST['year_name'] ?? '');
        $start_date = sanitize_input($_POST['start_date'] ?? '');
        $end_date = sanitize_input($_POST['end_date'] ?? '');
        $is_active = isset($_POST['is_active']) ? 1 : 0;

        if (!empty($year_name)) {
            if ($is_active) {
                $pdo->query("UPDATE academic_years SET is_active = 0");
            }
            $stmt = $pdo->prepare("INSERT INTO academic_years (name, start_date, end_date, is_active) VALUES (?, ?, ?, ?)");
            $stmt->execute([$year_name, $start_date, $end_date, $is_active]);
            log_audit($pdo, $current_user['id'], 'ACADEMIC_YEAR_ADDED', "Added academic calendar year: {$year_name}");
            set_flash('success', "Academic year {$year_name} added.");
        }
        header('Location: settings.php');
        exit;

    } elseif ($_POST['action'] === 'set_active_year') {
        $year_id = (int)($_POST['academic_year_id'] ?? 0);
        $pdo->query("UPDATE academic_years SET is_active = 0");
        $stmt = $pdo->prepare("UPDATE academic_years SET is_active = 1 WHERE id = ?");
        $stmt->execute([$year_id]);
        log_audit($pdo, $current_user['id'], 'ACADEMIC_YEAR_ACTIVATED', "Activated academic calendar ID: {$year_id}");
        set_flash('success', 'Active academic year updated.');
        header('Location: settings.php');
        exit;
    }
}

// Fetch all system settings as key-value pairs
$settings = [];
$st_rows = $pdo->query("SELECT setting_key, setting_value FROM system_settings")->fetchAll();
foreach ($st_rows as $row) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

// Fetch academic years
$academic_years = $pdo->query("SELECT * FROM academic_years ORDER BY id DESC")->fetchAll();

// Fetch audit logs (up to 50 entries)
$logs = $pdo->query("
    SELECT a.*, u.first_name, u.last_name, u.email, u.role
    FROM audit_logs a
    LEFT JOIN users u ON a.user_id = u.id
    ORDER BY a.id DESC
    LIMIT 50
")->fetchAll();

$page_title = "System Settings & Logs - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">System Settings & Security</h1>
            <p class="page-subtitle">School profiles, academic calendar terms, and security audit logs</p>
        </div>
    </div>

    <!-- Two-column: School Profile & Academic Year -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 24px; margin-bottom: 28px;">
        <!-- General School Information -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">School Identity & Contacts</h3>
            </div>
            <div class="card-body">
                <form action="settings.php" method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="save_school_info">

                    <div class="form-group">
                        <label class="form-label">School Name</label>
                        <input type="text" name="school_name" class="form-control" value="<?= e($settings['school_name'] ?? 'EP NKORE') ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">School Motto / Vision</label>
                        <input type="text" name="school_motto" class="form-control" value="<?= e($settings['school_motto'] ?? 'Excellence in Education and Integrity') ?>">
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Phone Number (Calls & WhatsApp)</label>
                            <input type="tel" name="school_phone" class="form-control" value="<?= e($settings['school_phone'] ?? '+250 781 125 809') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Official Email</label>
                            <input type="email" name="school_email" class="form-control" value="<?= e($settings['school_email'] ?? 'jeanpierret772@gmail.com') ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Campus Address</label>
                        <input type="text" name="school_address" class="form-control" value="<?= e($settings['school_address'] ?? 'Nyamagabe District, Musange Sector, Masangano Cell, Gasagara Village') ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Current Academic Term</label>
                        <select name="active_term" class="form-select">
                            <option value="Term 1" <?= ($settings['active_term'] ?? '') === 'Term 1' ? 'selected' : '' ?>>Term 1</option>
                            <option value="Term 2" <?= ($settings['active_term'] ?? '') === 'Term 2' ? 'selected' : '' ?>>Term 2</option>
                            <option value="Term 3" <?= ($settings['active_term'] ?? '') === 'Term 3' ? 'selected' : '' ?>>Term 3</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary" style="margin-top: 10px;">
                        Save School Settings
                    </button>
                </form>
            </div>
        </div>

        <!-- Academic Years Management -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Academic Calendar Years</h3>
            </div>
            <div class="card-body">
                <!-- Set Active Year -->
                <form action="settings.php" method="POST" style="margin-bottom: 20px;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="set_active_year">
                    <label class="form-label">Active Academic Year</label>
                    <div style="display: flex; gap: 8px;">
                        <select name="academic_year_id" class="form-select">
                            <?php foreach ($academic_years as $ay): ?>
                                <option value="<?= $ay['id'] ?>" <?= $ay['is_active'] ? 'selected' : '' ?>>
                                    <?= e($ay['name']) ?> <?= $ay['is_active'] ? '(Currently Active)' : '' ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-primary" style="white-space: nowrap;">Set Active</button>
                    </div>
                </form>

                <hr style="border: 0; border-top: 1px solid var(--slate-200); margin: 20px 0;">

                <!-- Add New Academic Year -->
                <h4 style="font-size: 14px; font-weight: 700; margin-bottom: 12px; color: var(--slate-800);">Add New Academic Calendar</h4>
                <form action="settings.php" method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="add_academic_year">

                    <div class="form-group">
                        <label class="form-label">Academic Year Name</label>
                        <input type="text" name="year_name" class="form-control" placeholder="e.g. 2026-2027" required>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Start Date</label>
                            <input type="date" name="start_date" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="form-label">End Date</label>
                            <input type="date" name="end_date" class="form-control">
                        </div>
                    </div>

                    <div style="margin-bottom: 16px;">
                        <label style="display: flex; align-items: center; gap: 8px; font-size: 13.5px; cursor: pointer;">
                            <input type="checkbox" name="is_active" value="1">
                            Set as active academic year immediately
                        </label>
                    </div>

                    <button type="submit" class="btn btn-secondary">
                        Add Academic Year
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Audit Logs Section -->
    <div class="card" id="audit-logs">
        <div class="card-header">
            <h3 class="card-title">Security & Action Audit Trail (Last 50 Events)</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Timestamp</th>
                            <th>Action Type</th>
                            <th>User / Actor</th>
                            <th>Details</th>
                            <th>IP Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $l): ?>
                            <tr>
                                <td style="white-space: nowrap; font-size: 12px; color: var(--slate-500);">
                                    <?= date('M d, Y H:i:s', strtotime($l['created_at'])) ?>
                                </td>
                                <td>
                                    <span class="badge badge-primary" style="font-size: 11px;"><?= e($l['action']) ?></span>
                                </td>
                                <td>
                                    <strong><?= e($l['first_name'] ? $l['first_name'] . ' ' . $l['last_name'] : 'Guest/System') ?></strong>
                                    <?php if ($l['role']): ?>
                                        <div style="font-size: 11px; color: var(--slate-500);"><?= e($l['role']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td style="font-size: 13px;"><?= e($l['details']) ?></td>
                                <td style="font-size: 12px; color: var(--slate-500);"><?= e($l['ip_address']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
