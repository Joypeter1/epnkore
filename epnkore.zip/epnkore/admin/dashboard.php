<?php
/**
 * EP NKORE - School Management System
 * Administrator Dashboard
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, 'Administrator');

// Handle Quick User Approval/Rejection action from dashboard
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    if (verify_csrf_token($csrf)) {
        $target_user_id = (int)($_POST['target_user_id'] ?? 0);
        if ($_POST['action'] === 'quick_approve') {
            $pdo->prepare("UPDATE users SET status = 'APPROVED' WHERE id = ?")->execute([$target_user_id]);
            log_audit($pdo, $current_user['id'], 'USER_APPROVED', "Approved user ID: {$target_user_id}");
            set_flash('success', "User account successfully approved.");
        } elseif ($_POST['action'] === 'quick_reject') {
            $pdo->prepare("UPDATE users SET status = 'REJECTED' WHERE id = ?")->execute([$target_user_id]);
            log_audit($pdo, $current_user['id'], 'USER_REJECTED', "Rejected user ID: {$target_user_id}");
            set_flash('warning', "User account rejected.");
        }
        header('Location: dashboard.php');
        exit;
    }
}

// Fetch Core Dashboard Statistics
$total_students = (int)$pdo->query("SELECT COUNT(*) FROM students WHERE status = 'Active'")->fetchColumn();
$total_teachers = (int)$pdo->query("SELECT COUNT(*) FROM teachers JOIN users ON teachers.user_id = users.id WHERE users.status = 'APPROVED'")->fetchColumn();
$pending_users = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE status = 'PENDING'")->fetchColumn();
$approved_users = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE status = 'APPROVED'")->fetchColumn();
$total_classes = (int)$pdo->query("SELECT COUNT(*) FROM classes")->fetchColumn();
$total_subjects = (int)$pdo->query("SELECT COUNT(*) FROM subjects")->fetchColumn();

// Fetch Pending Approvals List
$pending_stmt = $pdo->query("SELECT id, first_name, last_name, phone, email, role, created_at FROM users WHERE status = 'PENDING' ORDER BY id DESC LIMIT 5");
$pending_list = $pending_stmt->fetchAll();

// Fetch Recent Audit Logs
$logs_stmt = $pdo->query("SELECT a.*, u.first_name, u.last_name, u.role FROM audit_logs a LEFT JOIN users u ON a.user_id = u.id ORDER BY a.id DESC LIMIT 6");
$recent_logs = $logs_stmt->fetchAll();

$page_title = "Administrator Dashboard - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">Administrator Dashboard</h1>
            <p class="page-subtitle">Welcome, <?= e($current_user['first_name'] . ' ' . $current_user['last_name']) ?>. Complete school control and administration.</p>
        </div>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <a href="students.php?action=create" class="btn btn-primary btn-sm">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                Add Student
            </a>
            <a href="approve_users.php" class="btn btn-warning btn-sm">
                Pending Approvals (<?= $pending_users ?>)
            </a>
        </div>
    </div>

    <!-- Key Statistics Grid -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-info">
                <span class="stat-label">Total Students</span>
                <span class="stat-value"><?= number_format($total_students) ?></span>
                <span class="stat-subtext">Active Enrolled Pupils</span>
            </div>
            <div class="stat-icon blue">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-info">
                <span class="stat-label">Total Teachers</span>
                <span class="stat-value"><?= number_format($total_teachers) ?></span>
                <span class="stat-subtext">Qualified Staff</span>
            </div>
            <div class="stat-icon emerald">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-info">
                <span class="stat-label">Pending Users</span>
                <span class="stat-value" style="<?= $pending_users > 0 ? 'color: var(--warning);' : '' ?>"><?= number_format($pending_users) ?></span>
                <span class="stat-subtext">Awaiting Approval</span>
            </div>
            <div class="stat-icon amber">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-info">
                <span class="stat-label">Approved Users</span>
                <span class="stat-value"><?= number_format($approved_users) ?></span>
                <span class="stat-subtext">Active Accounts</span>
            </div>
            <div class="stat-icon purple">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-info">
                <span class="stat-label">Active Classes</span>
                <span class="stat-value"><?= number_format($total_classes) ?></span>
                <span class="stat-subtext">Primary Streams</span>
            </div>
            <div class="stat-icon blue">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-info">
                <span class="stat-label">Subjects</span>
                <span class="stat-value"><?= number_format($total_subjects) ?></span>
                <span class="stat-subtext">REB Curriculum</span>
            </div>
            <div class="stat-icon emerald">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
            </div>
        </div>
    </div>

    <!-- Two-Column Section: Pending Approvals & Audit Log -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(360px, 1fr)); gap: 24px;">
        <!-- Pending Users Queue -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Pending Account Approvals (<?= count($pending_list) ?>)</h3>
                <a href="approve_users.php" class="btn btn-outline btn-sm">View All</a>
            </div>
            <div class="card-body" style="padding: 0;">
                <?php if (empty($pending_list)): ?>
                    <div style="padding: 32px; text-align: center; color: var(--slate-500);">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin: 0 auto 8px; color: var(--success);"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                        <p>No pending account requests at this time. All users have been approved!</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Role</th>
                                    <th>Phone</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pending_list as $p): ?>
                                    <tr>
                                        <td>
                                            <strong><?= e($p['first_name'] . ' ' . $p['last_name']) ?></strong>
                                            <div style="font-size: 11.5px; color: var(--slate-500);"><?= e($p['email']) ?></div>
                                        </td>
                                        <td><span class="badge badge-<?= strtolower(str_replace(' ', '-', $p['role'])) ?>"><?= e($p['role']) ?></span></td>
                                        <td><?= e($p['phone']) ?></td>
                                        <td>
                                            <form action="dashboard.php" method="POST" style="display: inline-flex; gap: 4px;">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="target_user_id" value="<?= $p['id'] ?>">
                                                <button type="submit" name="action" value="quick_approve" class="btn btn-success btn-sm" title="Approve Account">✓ Approve</button>
                                                <button type="submit" name="action" value="quick_reject" class="btn btn-danger btn-sm" title="Reject Account" onclick="return confirm('Are you sure you want to reject this account?');">✕</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Audit Log -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Recent System Security Activity</h3>
                <a href="settings.php#audit-logs" class="btn btn-outline btn-sm">Full Audit Trail</a>
            </div>
            <div class="card-body" style="padding: 0;">
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Action</th>
                                <th>Actor</th>
                                <th>IP & Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_logs as $log): ?>
                                <tr>
                                    <td>
                                        <span class="badge badge-pill badge-primary" style="font-size: 11px;"><?= e($log['action']) ?></span>
                                        <div style="font-size: 12px; color: var(--slate-600); margin-top: 2px;"><?= e($log['details']) ?></div>
                                    </td>
                                    <td>
                                        <?= e($log['first_name'] ? $log['first_name'] . ' ' . $log['last_name'] : 'System/Guest') ?>
                                    </td>
                                    <td style="white-space: nowrap; font-size: 12px; color: var(--slate-500);">
                                        <?= date('M d, H:i', strtotime($log['created_at'])) ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
