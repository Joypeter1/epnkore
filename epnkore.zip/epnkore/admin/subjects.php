<?php
/**
 * EP NKORE - School Management System
 * Subject Curriculum Management (CRUD)
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, ['Administrator', 'Head Teacher']);

$action = $_GET['action'] ?? 'list';
$edit_id = (int)($_GET['id'] ?? 0);

// Handle Subject CRUD
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf)) {
        set_flash('danger', 'Security validation mismatch.');
        header('Location: subjects.php');
        exit;
    }

    $post_action = $_POST['post_action'] ?? '';

    if ($post_action === 'save_subject') {
        $sid = (int)($_POST['subject_db_id'] ?? 0);
        $name = sanitize_input($_POST['name'] ?? '');
        $code = sanitize_input($_POST['code'] ?? '');
        $department = sanitize_input($_POST['department'] ?? 'General');

        if (empty($name) || empty($code)) {
            set_flash('danger', 'Subject name and code are required.');
            header('Location: subjects.php');
            exit;
        }

        if ($sid > 0) {
            $stmt = $pdo->prepare("UPDATE subjects SET name = ?, code = ?, department = ? WHERE id = ?");
            $stmt->execute([$name, $code, $department, $sid]);
            log_audit($pdo, $current_user['id'], 'SUBJECT_UPDATED', "Updated subject: {$name} ({$code})");
            set_flash('success', "Subject {$name} updated successfully.");
        } else {
            $stmt = $pdo->prepare("INSERT INTO subjects (name, code, department) VALUES (?, ?, ?)");
            $stmt->execute([$name, $code, $department]);
            log_audit($pdo, $current_user['id'], 'SUBJECT_CREATED', "Created new subject: {$name} ({$code})");
            set_flash('success', "Subject {$name} created successfully.");
        }
        header('Location: subjects.php');
        exit;

    } elseif ($post_action === 'delete_subject') {
        $del_id = (int)($_POST['subject_db_id'] ?? 0);
        $pdo->prepare("DELETE FROM subjects WHERE id = ?")->execute([$del_id]);
        log_audit($pdo, $current_user['id'], 'SUBJECT_DELETED', "Deleted subject ID: {$del_id}");
        set_flash('success', 'Subject removed successfully.');
        header('Location: subjects.php');
        exit;
    }
}

// Fetch all subjects
$subjects = $pdo->query("
    SELECT s.*, 
           (SELECT COUNT(DISTINCT ts.teacher_id) FROM teacher_subjects ts WHERE ts.subject_id = s.id) as assigned_teachers,
           (SELECT COUNT(DISTINCT m.id) FROM marks m WHERE m.subject_id = s.id) as recorded_marks
    FROM subjects s
    ORDER BY s.name ASC
")->fetchAll();

// Edit single subject
$edit_subject = null;
if ($edit_id > 0) {
    $stmt_e = $pdo->prepare("SELECT * FROM subjects WHERE id = ?");
    $stmt_e->execute([$edit_id]);
    $edit_subject = $stmt_e->fetch();
}

$page_title = "Subject Curriculum - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">Subject Curriculum</h1>
            <p class="page-subtitle">Academic disciplines, department categorization, and examination codes</p>
        </div>
        <div>
            <?php if ($action !== 'create'): ?>
                <a href="subjects.php?action=create" class="btn btn-primary btn-sm">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    Add New Subject
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Create or Edit Subject Card -->
    <?php if ($action === 'create' || ($action === 'edit' && $edit_subject)): ?>
        <div class="card" style="margin-bottom: 24px;">
            <div class="card-header">
                <h3 class="card-title"><?= $action === 'edit' ? 'Edit Subject' : 'Add New Subject' ?></h3>
                <a href="subjects.php" class="btn btn-secondary btn-sm">Cancel</a>
            </div>
            <div class="card-body">
                <form action="subjects.php" method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="post_action" value="save_subject">
                    <input type="hidden" name="subject_db_id" value="<?= $edit_subject['id'] ?? 0 ?>">

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Subject Name <span class="required">*</span></label>
                            <input type="text" name="name" class="form-control" placeholder="e.g. Mathematics, English, ICT" value="<?= e($edit_subject['name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Subject Code <span class="required">*</span></label>
                            <input type="text" name="code" class="form-control" placeholder="e.g. MATH, ENG, ICT" value="<?= e($edit_subject['code'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Department / Faculty</label>
                            <input type="text" name="department" class="form-control" placeholder="e.g. STEM, Languages, Social Studies" value="<?= e($edit_subject['department'] ?? 'General') ?>">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <?= $action === 'edit' ? 'Update Subject' : 'Save Subject' ?>
                    </button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <!-- Subjects List Table -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Curriculum Subjects (<?= count($subjects) ?>)</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Subject Name</th>
                            <th>Department</th>
                            <th>Teachers Handling</th>
                            <th>Marks Logged</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($subjects as $s): ?>
                            <tr>
                                <td><span class="badge badge-primary" style="font-size: 12px; font-weight: 700;"><?= e($s['code']) ?></span></td>
                                <td><strong><?= e($s['name']) ?></strong></td>
                                <td><?= e($s['department']) ?></td>
                                <td><?= (int)$s['assigned_teachers'] ?> Assigned Teacher(s)</td>
                                <td><?= (int)$s['recorded_marks'] ?> Exam Records</td>
                                <td>
                                    <div style="display: flex; gap: 6px;">
                                        <a href="subjects.php?action=edit&id=<?= $s['id'] ?>" class="btn btn-secondary btn-sm">Edit</a>
                                        <form action="subjects.php" method="POST" onsubmit="return confirm('Delete this subject?');" style="display: inline;">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="post_action" value="delete_subject">
                                            <input type="hidden" name="subject_db_id" value="<?= $s['id'] ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">✕</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
