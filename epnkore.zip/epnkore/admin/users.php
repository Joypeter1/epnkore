<?php
/**
 * EP NKORE - School Management System
 * System Users Management (Admin)
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, 'Administrator');

// Handle Actions: Status Toggle, Password Reset, Role Change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    if (verify_csrf_token($csrf)) {
        $target_id = (int)($_POST['target_id'] ?? 0);
        $action = $_POST['action'];

        // Prevent self-lockout
        if ($target_id === $current_user['id'] && in_array($action, ['deactivate', 'delete'])) {
            set_flash('danger', 'You cannot deactivate or delete your own active administrator account.');
            header('Location: users.php');
            exit;
        }

        if ($action === 'set_status') {
            $new_status = $_POST['status'] ?? 'APPROVED';
            if (in_array($new_status, ['APPROVED', 'PENDING', 'REJECTED'])) {
                $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
                $stmt->execute([$new_status, $target_id]);
                log_audit($pdo, $current_user['id'], 'USER_STATUS_CHANGE', "Changed user #{$target_id} status to {$new_status}");
                set_flash('success', "User status updated to {$new_status}.");
            }
        } elseif ($action === 'reset_password') {
            $temp_pw = 'Nkore@' . random_int(1000, 9999) . '!';
            $hash = password_hash($temp_pw, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, must_change_password = 1 WHERE id = ?");
            $stmt->execute([$hash, $target_id]);
            log_audit($pdo, $current_user['id'], 'USER_PASSWORD_RESET', "Reset password for user #{$target_id}");
            set_flash('success', "Temporary password generated for user #{$target_id}: <strong>{$temp_pw}</strong> (User will be required to change it upon login).");
        } elseif ($action === 'change_role') {
            $new_role = $_POST['role'] ?? 'Teacher';
            if (in_array($new_role, ['Teacher', 'Head Teacher', 'Administrator'])) {
                $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE id = ?");
                $stmt->execute([$new_role, $target_id]);
                log_audit($pdo, $current_user['id'], 'USER_ROLE_CHANGE', "Changed user #{$target_id} role to {$new_role}");
                set_flash('success', "User role updated to {$new_role}.");
            }
        } elseif ($action === 'delete_user') {
            if ($target_id === $current_user['id']) {
                set_flash('danger', 'You cannot delete your own administrator account.');
            } else {
                $check_stmt = $pdo->prepare("SELECT first_name, last_name, email, role FROM users WHERE id = ?");
                $check_stmt->execute([$target_id]);
                $u_info = $check_stmt->fetch();
                if ($u_info) {
                    $del = $pdo->prepare("DELETE FROM users WHERE id = ?");
                    $del->execute([$target_id]);
                    log_audit($pdo, $current_user['id'], 'USER_DELETED', "Permanently deleted user #{$target_id} ({$u_info['first_name']} {$u_info['last_name']}, {$u_info['email']}, {$u_info['role']})");
                    set_flash('success', "User account for <strong>" . e($u_info['first_name'] . ' ' . $u_info['last_name']) . "</strong> was permanently deleted.");
                } else {
                    set_flash('danger', 'User not found or already deleted.');
                }
            }
        } elseif ($action === 'update_profile') {
            $first_name = trim($_POST['first_name'] ?? '');
            $last_name = trim($_POST['last_name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $role_val = trim($_POST['role'] ?? 'Teacher');
            $status_val = trim($_POST['status'] ?? 'APPROVED');
            $custom_pw = trim($_POST['custom_password'] ?? '');

            if (empty($first_name) || empty($last_name) || empty($email) || empty($phone)) {
                set_flash('danger', 'First name, last name, email, and phone number are required.');
            } else {
                // Check uniqueness of email or phone against other users
                $dupe_check = $pdo->prepare("SELECT id FROM users WHERE (email = ? OR phone = ?) AND id != ?");
                $dupe_check->execute([$email, $phone, $target_id]);
                if ($dupe_check->fetch()) {
                    set_flash('danger', 'Another user account already uses this email or phone number.');
                } else {
                    if (!empty($custom_pw)) {
                        $hash = password_hash($custom_pw, PASSWORD_BCRYPT);
                        $upd = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, role = ?, status = ?, password_hash = ? WHERE id = ?");
                        $upd->execute([$first_name, $last_name, $email, $phone, $role_val, $status_val, $hash, $target_id]);
                    } else {
                        $upd = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, role = ?, status = ? WHERE id = ?");
                        $upd->execute([$first_name, $last_name, $email, $phone, $role_val, $status_val, $target_id]);
                    }
                    log_audit($pdo, $current_user['id'], 'USER_PROFILE_UPDATED', "Updated profile of user #{$target_id} ({$first_name} {$last_name}, {$email}, Role: {$role_val}, Status: {$status_val})");
                    set_flash('success', "Profile for <strong>" . e($first_name . ' ' . $last_name) . "</strong> updated successfully.");
                }
            }
        }
        header('Location: users.php');
        exit;
    }
}

// Search and Filter parameters
$search = trim($_GET['search'] ?? '');
$role_filter = trim($_GET['role'] ?? '');
$status_filter = trim($_GET['status'] ?? '');

$query = "SELECT * FROM users WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR phone LIKE ?)";
    $term = "%{$search}%";
    $params = array_merge($params, [$term, $term, $term, $term]);
}

if (!empty($role_filter)) {
    $query .= " AND role = ?";
    $params[] = $role_filter;
}

if (!empty($status_filter)) {
    $query .= " AND status = ?";
    $params[] = $status_filter;
}

$query .= " ORDER BY id DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$users = $stmt->fetchAll();

$page_title = "Manage Users - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">Manage System Users</h1>
            <p class="page-subtitle">Configure accounts, password resets, roles, and status</p>
        </div>
        <div>
            <a href="approve_users.php" class="btn btn-warning btn-sm">Approve Queue</a>
        </div>
    </div>

    <!-- Search & Filter Bar -->
    <div class="card" style="margin-bottom: 20px;">
        <div class="card-body" style="padding: 16px 20px;">
            <form method="GET" action="users.php" style="display: flex; gap: 12px; flex-wrap: wrap; align-items: flex-end;">
                <div style="flex: 1; min-width: 200px;">
                    <label class="form-label" style="font-size: 12px;">Search Keyword</label>
                    <input type="text" name="search" class="form-control" placeholder="Search name, phone, or email..." value="<?= e($search) ?>">
                </div>

                <div style="min-width: 150px;">
                    <label class="form-label" style="font-size: 12px;">Filter Role</label>
                    <select name="role" class="form-select">
                        <option value="">All Roles</option>
                        <option value="Administrator" <?= $role_filter === 'Administrator' ? 'selected' : '' ?>>Administrator</option>
                        <option value="Head Teacher" <?= $role_filter === 'Head Teacher' ? 'selected' : '' ?>>Head Teacher</option>
                        <option value="Teacher" <?= $role_filter === 'Teacher' ? 'selected' : '' ?>>Teacher</option>
                    </select>
                </div>

                <div style="min-width: 150px;">
                    <label class="form-label" style="font-size: 12px;">Filter Status</label>
                    <select name="status" class="form-select">
                        <option value="">All Statuses</option>
                        <option value="APPROVED" <?= $status_filter === 'APPROVED' ? 'selected' : '' ?>>APPROVED</option>
                        <option value="PENDING" <?= $status_filter === 'PENDING' ? 'selected' : '' ?>>PENDING</option>
                        <option value="REJECTED" <?= $status_filter === 'REJECTED' ? 'selected' : '' ?>>REJECTED</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary" style="height: 42px;">Filter</button>
                <a href="users.php" class="btn btn-secondary" style="height: 42px;">Reset</a>
            </form>
        </div>
    </div>

    <!-- Users Table -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">User Accounts List (<?= count($users) ?>)</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Contact</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Registered</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $u): ?>
                            <tr>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div class="user-avatar-sm">
                                            <?= strtoupper(substr($u['first_name'], 0, 1) . substr($u['last_name'], 0, 1)) ?>
                                        </div>
                                        <div>
                                            <strong><?= e($u['first_name'] . ' ' . $u['last_name']) ?></strong>
                                            <?php if ($u['id'] === $current_user['id']): ?>
                                                <span style="font-size: 11px; background: #e0f2fe; color: #0369a1; padding: 2px 6px; border-radius: 4px; font-weight: 600;">You</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div><?= e($u['phone']) ?></div>
                                    <div style="font-size: 12px; color: var(--slate-500);"><?= e($u['email']) ?></div>
                                </td>
                                <td>
                                    <form action="users.php" method="POST" style="display: inline-block;">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="target_id" value="<?= $u['id'] ?>">
                                        <input type="hidden" name="action" value="change_role">
                                        <select name="role" class="form-select" style="font-size: 12px; padding: 4px 8px;" onchange="this.form.submit()">
                                            <option value="Administrator" <?= $u['role'] === 'Administrator' ? 'selected' : '' ?>>Administrator</option>
                                            <option value="Head Teacher" <?= $u['role'] === 'Head Teacher' ? 'selected' : '' ?>>Head Teacher</option>
                                            <option value="Teacher" <?= $u['role'] === 'Teacher' ? 'selected' : '' ?>>Teacher</option>
                                        </select>
                                    </form>
                                </td>
                                <td>
                                    <form action="users.php" method="POST" style="display: inline-block;">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="target_id" value="<?= $u['id'] ?>">
                                        <input type="hidden" name="action" value="set_status">
                                        <select name="status" class="form-select" style="font-size: 12px; padding: 4px 8px;" onchange="this.form.submit()">
                                            <option value="APPROVED" <?= $u['status'] === 'APPROVED' ? 'selected' : '' ?>>APPROVED</option>
                                            <option value="PENDING" <?= $u['status'] === 'PENDING' ? 'selected' : '' ?>>PENDING</option>
                                            <option value="REJECTED" <?= $u['status'] === 'REJECTED' ? 'selected' : '' ?>>REJECTED</option>
                                        </select>
                                    </form>
                                </td>
                                <td style="font-size: 12px; color: var(--slate-500);">
                                    <?= date('M d, Y', strtotime($u['created_at'])) ?>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 6px; align-items: center; flex-wrap: wrap;">
                                        <!-- Edit Profile Button -->
                                        <button type="button" class="btn btn-primary btn-sm" onclick="openEditUserModal(<?= htmlspecialchars(json_encode($u), ENT_QUOTES, 'UTF-8') ?>)" title="Edit User Profile">
                                            Edit
                                        </button>

                                        <!-- Reset Password -->
                                        <form action="users.php" method="POST" onsubmit="return confirm('Generate a temporary password for this user?');" style="display: inline-block;">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="target_id" value="<?= $u['id'] ?>">
                                            <input type="hidden" name="action" value="reset_password">
                                            <button type="submit" class="btn btn-outline btn-sm" title="Reset user password">
                                                Reset
                                            </button>
                                        </form>

                                        <!-- Delete User (Forbidden for self) -->
                                        <?php if ($u['id'] !== $current_user['id']): ?>
                                            <form action="users.php" method="POST" onsubmit="return confirm('WARNING: Are you sure you want to PERMANENTLY DELETE user <?= e($u['first_name'] . ' ' . $u['last_name']) ?>? This cannot be undone.');" style="display: inline-block;">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="target_id" value="<?= $u['id'] ?>">
                                                <input type="hidden" name="action" value="delete_user">
                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete User Permanently">
                                                    Delete
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Edit User Profile Modal -->
<div id="editUserModal" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.7); backdrop-filter: blur(4px); z-index: 9999; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: white; border-radius: 12px; width: 100%; max-width: 520px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.2); overflow: hidden;">
        <div style="padding: 16px 20px; background: #f8fafc; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; font-size: 16px; font-weight: 700; color: #0f172a;">Edit User Profile (Super Admin)</h3>
            <button type="button" onclick="closeEditUserModal()" style="background: none; border: none; font-size: 20px; cursor: pointer; color: #64748b;">&times;</button>
        </div>
        <form action="users.php" method="POST" style="padding: 20px;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="update_profile">
            <input type="hidden" name="target_id" id="modal_target_id" value="0">

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 14px;">
                <div>
                    <label class="form-label" style="font-size: 12px;">First Name *</label>
                    <input type="text" name="first_name" id="modal_first_name" class="form-control" required>
                </div>
                <div>
                    <label class="form-label" style="font-size: 12px;">Last Name *</label>
                    <input type="text" name="last_name" id="modal_last_name" class="form-control" required>
                </div>
            </div>

            <div style="margin-bottom: 14px;">
                <label class="form-label" style="font-size: 12px;">Email Address *</label>
                <input type="email" name="email" id="modal_email" class="form-control" required>
            </div>

            <div style="margin-bottom: 14px;">
                <label class="form-label" style="font-size: 12px;">Phone Number (Call/WhatsApp) *</label>
                <input type="tel" name="phone" id="modal_phone" class="form-control" required>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 14px;">
                <div>
                    <label class="form-label" style="font-size: 12px;">System Role</label>
                    <select name="role" id="modal_role" class="form-select">
                        <option value="Administrator">Administrator</option>
                        <option value="Head Teacher">Head Teacher</option>
                        <option value="Teacher">Teacher</option>
                    </select>
                </div>
                <div>
                    <label class="form-label" style="font-size: 12px;">Approval Status</label>
                    <select name="status" id="modal_status" class="form-select">
                        <option value="APPROVED">APPROVED</option>
                        <option value="PENDING">PENDING</option>
                        <option value="REJECTED">REJECTED</option>
                    </select>
                </div>
            </div>

            <div style="margin-bottom: 20px; background: #f8fafc; padding: 12px; border-radius: 8px; border: 1px dashed #cbd5e1;">
                <label class="form-label" style="font-size: 12px;">Set New Password Directly (Optional)</label>
                <input type="text" name="custom_password" class="form-control" placeholder="Leave blank to keep existing password" style="background: white;">
                <small style="color: #64748b; font-size: 11px;">If you type a new password here, it will be hashed and updated immediately.</small>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 10px;">
                <button type="button" onclick="closeEditUserModal()" class="btn btn-secondary">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Profile Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditUserModal(user) {
    document.getElementById('modal_target_id').value = user.id;
    document.getElementById('modal_first_name').value = user.first_name || '';
    document.getElementById('modal_last_name').value = user.last_name || '';
    document.getElementById('modal_email').value = user.email || '';
    document.getElementById('modal_phone').value = user.phone || '';
    document.getElementById('modal_role').value = user.role || 'Teacher';
    document.getElementById('modal_status').value = user.status || 'APPROVED';
    document.getElementById('editUserModal').style.display = 'flex';
}

function closeEditUserModal() {
    document.getElementById('editUserModal').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
