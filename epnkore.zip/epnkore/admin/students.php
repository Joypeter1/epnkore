<?php
/**
 * EP NKORE - School Management System
 * Complete Student Management (CRUD)
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, ['Administrator', 'Head Teacher']);

// Fetch classes and active academic years
$classes = $pdo->query("SELECT id, name FROM classes ORDER BY name ASC")->fetchAll();
$academic_years = $pdo->query("SELECT id, name FROM academic_years ORDER BY id DESC")->fetchAll();

$action = $_GET['action'] ?? 'list';
$student_id = (int)($_GET['id'] ?? 0);

// Handle Form Submissions (Add / Edit / Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf)) {
        set_flash('danger', 'Security validation mismatch.');
        header('Location: students.php');
        exit;
    }

    $post_action = $_POST['post_action'] ?? '';

    if ($post_action === 'save') {
        $sid = (int)($_POST['student_db_id'] ?? 0);
        $student_id_number = sanitize_input($_POST['student_id_number'] ?? '');
        $first_name = sanitize_input($_POST['first_name'] ?? '');
        $last_name = sanitize_input($_POST['last_name'] ?? '');
        $gender = sanitize_input($_POST['gender'] ?? 'Male');
        $dob = sanitize_input($_POST['dob'] ?? '');
        $parent_name = sanitize_input($_POST['parent_name'] ?? '');
        $parent_phone = normalize_phone($_POST['parent_phone'] ?? '');
        $class_id = (int)($_POST['class_id'] ?? 0);
        $academic_year_id = (int)($_POST['academic_year_id'] ?? 1);
        $status = sanitize_input($_POST['status'] ?? 'Active');

        if (empty($student_id_number) || empty($first_name) || empty($last_name) || empty($class_id)) {
            set_flash('danger', 'Please complete all required fields (ID, Name, Class).');
            header('Location: students.php?action=' . ($sid ? "edit&id={$sid}" : 'create'));
            exit;
        }

        // Photo upload
        $student_photo = 'default_student.png';
        if (isset($_FILES['student_photo']) && $_FILES['student_photo']['error'] !== UPLOAD_ERR_NO_FILE) {
            $up_err = null;
            $uploaded = upload_profile_photo($_FILES['student_photo'], __DIR__ . '/../uploads/students', $up_err);
            if ($uploaded) {
                $student_photo = $uploaded;
            }
        }

        if ($sid > 0) {
            // Update
            $sql = "UPDATE students SET student_id_number = ?, first_name = ?, last_name = ?, gender = ?, dob = ?, parent_name = ?, parent_phone = ?, class_id = ?, academic_year_id = ?, status = ?";
            $params = [$student_id_number, $first_name, $last_name, $gender, $dob, $parent_name, $parent_phone, $class_id, $academic_year_id, $status];
            if ($student_photo !== 'default_student.png') {
                $sql .= ", student_photo = ?";
                $params[] = $student_photo;
            }
            $sql .= " WHERE id = ?";
            $params[] = $sid;

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            log_audit($pdo, $current_user['id'], 'STUDENT_UPDATED', "Updated student ID: {$student_id_number}");
            set_flash('success', "Student record for {$first_name} {$last_name} updated successfully.");
        } else {
            // Insert
            $stmt = $pdo->prepare("
                INSERT INTO students (student_id_number, first_name, last_name, gender, dob, parent_name, parent_phone, class_id, academic_year_id, student_photo, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$student_id_number, $first_name, $last_name, $gender, $dob, $parent_name, $parent_phone, $class_id, $academic_year_id, $student_photo, $status]);
            $new_id = $pdo->lastInsertId();
            log_audit($pdo, $current_user['id'], 'STUDENT_CREATED', "Enrolled student {$first_name} {$last_name} ({$student_id_number})");
            set_flash('success', "Student {$first_name} {$last_name} successfully enrolled.");
        }

        header('Location: students.php');
        exit;

    } elseif ($post_action === 'delete') {
        $del_id = (int)($_POST['student_db_id'] ?? 0);
        $stmt = $pdo->prepare("DELETE FROM students WHERE id = ?");
        $stmt->execute([$del_id]);
        log_audit($pdo, $current_user['id'], 'STUDENT_DELETED', "Deleted student database ID: {$del_id}");
        set_flash('success', "Student removed from system.");
        header('Location: students.php');
        exit;
    }
}

// Fetch single student for edit/profile view
$student_record = null;
if ($student_id > 0) {
    $stmt = $pdo->prepare("SELECT s.*, c.name as class_name, a.name as year_name FROM students s LEFT JOIN classes c ON s.class_id = c.id LEFT JOIN academic_years a ON s.academic_year_id = a.id WHERE s.id = ?");
    $stmt->execute([$student_id]);
    $student_record = $stmt->fetch();
}

// Search and Filter parameters
$search = trim($_GET['search'] ?? '');
$class_filter = (int)($_GET['class_id'] ?? 0);
$status_filter = trim($_GET['status'] ?? '');

$query = "SELECT s.*, c.name as class_name, a.name as year_name FROM students s LEFT JOIN classes c ON s.class_id = c.id LEFT JOIN academic_years a ON s.academic_year_id = a.id WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (s.first_name LIKE ? OR s.last_name LIKE ? OR s.student_id_number LIKE ? OR s.parent_name LIKE ?)";
    $term = "%{$search}%";
    $params = array_merge($params, [$term, $term, $term, $term]);
}

if ($class_filter > 0) {
    $query .= " AND s.class_id = ?";
    $params[] = $class_filter;
}

if (!empty($status_filter)) {
    $query .= " AND s.status = ?";
    $params[] = $status_filter;
}

$query .= " ORDER BY c.name ASC, s.last_name ASC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$students = $stmt->fetchAll();

$page_title = "Student Management - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">Student Management</h1>
            <p class="page-subtitle">Pupil admissions, academic enrollments, parent contacts, and student profiles</p>
        </div>
        <div style="display: flex; gap: 8px;">
            <?php if ($action !== 'create'): ?>
                <a href="students.php?action=create" class="btn btn-primary btn-sm">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    Enroll New Student
                </a>
            <?php endif; ?>
            <button type="button" class="btn btn-outline btn-sm btn-print-trigger">
                Print Roster
            </button>
        </div>
    </div>

    <!-- Create or Edit Student Form View -->
    <?php if ($action === 'create' || ($action === 'edit' && $student_record)): ?>
        <div class="card" style="margin-bottom: 28px;">
            <div class="card-header">
                <h3 class="card-title"><?= $action === 'edit' ? 'Edit Student Details' : 'Enroll New Student' ?></h3>
                <a href="students.php" class="btn btn-secondary btn-sm">Cancel</a>
            </div>
            <div class="card-body">
                <form action="students.php" method="POST" enctype="multipart/form-data">
                    <?= csrf_field() ?>
                    <input type="hidden" name="post_action" value="save">
                    <input type="hidden" name="student_db_id" value="<?= $student_record['id'] ?? 0 ?>">

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Student ID Number <span class="required">*</span></label>
                            <input type="text" name="student_id_number" class="form-control" placeholder="STU-2025-XXX" value="<?= e($student_record['student_id_number'] ?? 'STU-' . date('Y') . '-' . random_int(100, 999)) ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">First Name <span class="required">*</span></label>
                            <input type="text" name="first_name" class="form-control" value="<?= e($student_record['first_name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Last Name <span class="required">*</span></label>
                            <input type="text" name="last_name" class="form-control" value="<?= e($student_record['last_name'] ?? '') ?>" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Gender <span class="required">*</span></label>
                            <select name="gender" class="form-select" required>
                                <option value="Male" <?= ($student_record['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>Male</option>
                                <option value="Female" <?= ($student_record['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Date of Birth</label>
                            <input type="date" name="dob" class="form-control" value="<?= e($student_record['dob'] ?? '2014-01-01') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Class Stream <span class="required">*</span></label>
                            <select name="class_id" class="form-select" required>
                                <option value="">Select Class</option>
                                <?php foreach ($classes as $c): ?>
                                    <option value="<?= $c['id'] ?>" <?= ($student_record['class_id'] ?? '') == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Parent / Guardian Full Name</label>
                            <input type="text" name="parent_name" class="form-control" placeholder="Parent or Guardian" value="<?= e($student_record['parent_name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Parent Phone (SMS notifications)</label>
                            <input type="tel" name="parent_phone" class="form-control" placeholder="+250 788 000 000" value="<?= e($student_record['parent_phone'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="Active" <?= ($student_record['status'] ?? '') === 'Active' ? 'selected' : '' ?>>Active</option>
                                <option value="Inactive" <?= ($student_record['status'] ?? '') === 'Inactive' ? 'selected' : '' ?>>Inactive</option>
                                <option value="Transferred" <?= ($student_record['status'] ?? '') === 'Transferred' ? 'selected' : '' ?>>Transferred</option>
                                <option value="Graduated" <?= ($student_record['status'] ?? '') === 'Graduated' ? 'selected' : '' ?>>Graduated</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Academic Year</label>
                            <select name="academic_year_id" class="form-select">
                                <?php foreach ($academic_years as $ay): ?>
                                    <option value="<?= $ay['id'] ?>" <?= ($student_record['academic_year_id'] ?? '') == $ay['id'] ? 'selected' : '' ?>><?= e($ay['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Student Photo (Optional)</label>
                            <input type="file" name="student_photo" class="form-control" accept="image/*">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary" style="margin-top: 10px;">
                        <?= $action === 'edit' ? 'Save Student Updates' : 'Complete Enrollment' ?>
                    </button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <!-- View Student Profile Modal / Card -->
    <?php if ($action === 'view' && $student_record): ?>
        <div class="card" style="margin-bottom: 28px; border-left: 4px solid var(--primary);">
            <div class="card-header">
                <h3 class="card-title">Student Profile: <?= e($student_record['first_name'] . ' ' . $student_record['last_name']) ?> (<?= e($student_record['student_id_number']) ?>)</h3>
                <div>
                    <a href="students.php?action=edit&id=<?= $student_record['id'] ?>" class="btn btn-primary btn-sm">Edit</a>
                    <a href="reports.php?type=student&student_id=<?= $student_record['id'] ?>" class="btn btn-warning btn-sm">Academic Report Card</a>
                    <a href="students.php" class="btn btn-secondary btn-sm">Close</a>
                </div>
            </div>
            <div class="card-body">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px;">
                    <div><strong>Gender:</strong> <?= e($student_record['gender']) ?></div>
                    <div><strong>Date of Birth:</strong> <?= e($student_record['dob']) ?></div>
                    <div><strong>Class Stream:</strong> <span class="badge badge-primary"><?= e($student_record['class_name']) ?></span></div>
                    <div><strong>Academic Year:</strong> <?= e($student_record['year_name']) ?></div>
                    <div><strong>Parent / Guardian:</strong> <?= e($student_record['parent_name']) ?></div>
                    <div><strong>Parent Contact:</strong> <?= e($student_record['parent_phone']) ?></div>
                    <div><strong>Enrollment Status:</strong> <span class="badge badge-<?= strtolower($student_record['status']) ?>"><?= e($student_record['status']) ?></span></div>
                    <div><strong>Enrolled Date:</strong> <?= date('M d, Y', strtotime($student_record['created_at'])) ?></div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Search & Filter Controls -->
    <div class="card" style="margin-bottom: 20px;">
        <div class="card-body" style="padding: 14px 20px;">
            <form method="GET" action="students.php" style="display: flex; gap: 12px; flex-wrap: wrap; align-items: flex-end;">
                <div style="flex: 1; min-width: 200px;">
                    <label class="form-label" style="font-size: 12px;">Search Student</label>
                    <input type="text" name="search" class="form-control" placeholder="Search by name, ID, parent..." value="<?= e($search) ?>">
                </div>

                <div style="min-width: 150px;">
                    <label class="form-label" style="font-size: 12px;">Filter Class</label>
                    <select name="class_id" class="form-select">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= $class_filter === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="min-width: 140px;">
                    <label class="form-label" style="font-size: 12px;">Status</label>
                    <select name="status" class="form-select">
                        <option value="">All Statuses</option>
                        <option value="Active" <?= $status_filter === 'Active' ? 'selected' : '' ?>>Active</option>
                        <option value="Inactive" <?= $status_filter === 'Inactive' ? 'selected' : '' ?>>Inactive</option>
                        <option value="Transferred" <?= $status_filter === 'Transferred' ? 'selected' : '' ?>>Transferred</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary" style="height: 42px;">Apply Filter</button>
                <a href="students.php" class="btn btn-secondary" style="height: 42px;">Reset</a>
            </form>
        </div>
    </div>

    <!-- Students Roster Table -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Enrolled Pupils (<?= count($students) ?>)</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Pupil Name</th>
                            <th>Gender</th>
                            <th>Class</th>
                            <th>Parent Contact</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($students)): ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 24px; color: var(--slate-500);">
                                    No students matching criteria found.
                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php foreach ($students as $stu): ?>
                            <tr>
                                <td><strong><?= e($stu['student_id_number']) ?></strong></td>
                                <td>
                                    <strong><?= e($stu['first_name'] . ' ' . $stu['last_name']) ?></strong>
                                    <div style="font-size: 11.5px; color: var(--slate-500);">DOB: <?= e($stu['dob']) ?></div>
                                </td>
                                <td><?= e($stu['gender']) ?></td>
                                <td><span class="badge badge-primary"><?= e($stu['class_name'] ?? 'Unassigned') ?></span></td>
                                <td>
                                    <div><?= e($stu['parent_name']) ?></div>
                                    <div style="font-size: 12px; color: var(--slate-500);"><?= e($stu['parent_phone']) ?></div>
                                </td>
                                <td><span class="badge badge-<?= strtolower($stu['status']) ?>"><?= e($stu['status']) ?></span></td>
                                <td>
                                    <div style="display: flex; gap: 4px;">
                                        <a href="students.php?action=view&id=<?= $stu['id'] ?>" class="btn btn-outline btn-sm" title="View Profile">View</a>
                                        <a href="students.php?action=edit&id=<?= $stu['id'] ?>" class="btn btn-secondary btn-sm" title="Edit Student">Edit</a>
                                        <form action="students.php" method="POST" onsubmit="return confirm('Are you sure you want to remove this student?');" style="display: inline;">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="post_action" value="delete">
                                            <input type="hidden" name="student_db_id" value="<?= $stu['id'] ?>">
                                            <button type="submit" class="btn btn-danger btn-sm" title="Delete">✕</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
