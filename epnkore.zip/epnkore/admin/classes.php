<?php
/**
 * EP NKORE - School Management System
 * Class Stream Management (CRUD)
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, ['Administrator', 'Head Teacher']);

$action = $_GET['action'] ?? 'list';
$edit_id = (int)($_GET['id'] ?? 0);

// Fetch teachers for Class Teacher assignment
$teachers = $pdo->query("
    SELECT t.id, t.teacher_code, u.first_name, u.last_name
    FROM teachers t
    JOIN users u ON t.user_id = u.id
    WHERE u.status = 'APPROVED'
    ORDER BY u.first_name ASC
")->fetchAll();

// Handle Form Submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf)) {
        set_flash('danger', 'Security validation mismatch.');
        header('Location: classes.php');
        exit;
    }

    $post_action = $_POST['post_action'] ?? '';

    if ($post_action === 'save_class') {
        $cid = (int)($_POST['class_db_id'] ?? 0);
        $name = sanitize_input($_POST['name'] ?? '');
        $stream = sanitize_input($_POST['stream'] ?? '');
        $class_teacher_id = !empty($_POST['class_teacher_id']) ? (int)$_POST['class_teacher_id'] : null;
        $room_number = sanitize_input($_POST['room_number'] ?? '');
        $capacity = (int)($_POST['capacity'] ?? 45);

        if (empty($name)) {
            set_flash('danger', 'Class name is required.');
            header('Location: classes.php');
            exit;
        }

        if ($cid > 0) {
            $stmt = $pdo->prepare("UPDATE classes SET name = ?, stream = ?, class_teacher_id = ?, room_number = ?, capacity = ? WHERE id = ?");
            $stmt->execute([$name, $stream, $class_teacher_id, $room_number, $capacity, $cid]);
            log_audit($pdo, $current_user['id'], 'CLASS_UPDATED', "Updated class: {$name}");
            set_flash('success', "Class {$name} updated successfully.");
        } else {
            $stmt = $pdo->prepare("INSERT INTO classes (name, stream, class_teacher_id, room_number, capacity) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $stream, $class_teacher_id, $room_number, $capacity]);
            log_audit($pdo, $current_user['id'], 'CLASS_CREATED', "Created new class: {$name}");
            set_flash('success', "Class {$name} created successfully.");
        }
        header('Location: classes.php');
        exit;

    } elseif ($post_action === 'delete_class') {
        $del_id = (int)($_POST['class_db_id'] ?? 0);
        // Check student count first
        $cnt = (int)$pdo->prepare("SELECT COUNT(*) FROM students WHERE class_id = ?")->execute([$del_id]) ? $pdo->query("SELECT COUNT(*) FROM students WHERE class_id = {$del_id}")->fetchColumn() : 0;
        if ($cnt > 0) {
            set_flash('danger', "Cannot delete class: {$cnt} students are currently enrolled in it.");
        } else {
            $pdo->prepare("DELETE FROM classes WHERE id = ?")->execute([$del_id]);
            log_audit($pdo, $current_user['id'], 'CLASS_DELETED', "Deleted class ID: {$del_id}");
            set_flash('success', 'Class removed successfully.');
        }
        header('Location: classes.php');
        exit;
    }
}

// Fetch all classes with teacher name and enrolled count
$classes = $pdo->query("
    SELECT c.*, 
           CONCAT(u.first_name, ' ', u.last_name) as teacher_name,
           (SELECT COUNT(*) FROM students s WHERE s.class_id = c.id AND s.status = 'Active') as enrolled_students
    FROM classes c
    LEFT JOIN teachers t ON c.class_teacher_id = t.id
    LEFT JOIN users u ON t.user_id = u.id
    ORDER BY c.name ASC
")->fetchAll();

// Edit single class
$edit_class = null;
if ($edit_id > 0) {
    $stmt_e = $pdo->prepare("SELECT * FROM classes WHERE id = ?");
    $stmt_e->execute([$edit_id]);
    $edit_class = $stmt_e->fetch();
}

$page_title = "Class Management - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">Class Management</h1>
            <p class="page-subtitle">Primary school streams, classrooms, and assigned class masters</p>
        </div>
        <div>
            <?php if ($action !== 'create'): ?>
                <a href="classes.php?action=create" class="btn btn-primary btn-sm">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    Create New Class
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Create or Edit Class Card -->
    <?php if ($action === 'create' || ($action === 'edit' && $edit_class)): ?>
        <div class="card" style="margin-bottom: 24px;">
            <div class="card-header">
                <h3 class="card-title"><?= $action === 'edit' ? 'Edit Class Stream' : 'Add New Class Stream' ?></h3>
                <a href="classes.php" class="btn btn-secondary btn-sm">Cancel</a>
            </div>
            <div class="card-body">
                <form action="classes.php" method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="post_action" value="save_class">
                    <input type="hidden" name="class_db_id" value="<?= $edit_class['id'] ?? 0 ?>">

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Class Name <span class="required">*</span></label>
                            <input type="text" name="name" class="form-control" placeholder="e.g. Primary 1, Primary 6" value="<?= e($edit_class['name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Stream / Section</label>
                            <input type="text" name="stream" class="form-control" placeholder="e.g. Stream A, Blue Stream" value="<?= e($edit_class['stream'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Assigned Class Teacher</label>
                            <select name="class_teacher_id" class="form-select">
                                <option value="">None (Unassigned)</option>
                                <?php foreach ($teachers as $t): ?>
                                    <option value="<?= $t['id'] ?>" <?= ($edit_class['class_teacher_id'] ?? '') == $t['id'] ? 'selected' : '' ?>>
                                        <?= e($t['first_name'] . ' ' . $t['last_name']) ?> (<?= e($t['teacher_code']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Room Number / Block</label>
                            <input type="text" name="room_number" class="form-control" placeholder="e.g. Block A - Room 101" value="<?= e($edit_class['room_number'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Max Student Capacity</label>
                            <input type="number" name="capacity" class="form-control" min="10" max="80" value="<?= e($edit_class['capacity'] ?? 45) ?>">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <?= $action === 'edit' ? 'Update Class' : 'Create Class' ?>
                    </button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <!-- Classes Grid / Table -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">School Class Directory</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Class Name</th>
                            <th>Stream</th>
                            <th>Class Master / Teacher</th>
                            <th>Room</th>
                            <th>Enrolled Pupils</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($classes as $c): ?>
                            <tr>
                                <td><strong><?= e($c['name']) ?></strong></td>
                                <td><?= e($c['stream'] ?: 'Main') ?></td>
                                <td><?= e($c['teacher_name'] ?: 'Unassigned') ?></td>
                                <td><?= e($c['room_number'] ?: 'Standard Hall') ?></td>
                                <td>
                                    <span class="badge badge-primary"><?= (int)$c['enrolled_students'] ?> / <?= (int)$c['capacity'] ?> Pupils</span>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 6px;">
                                        <a href="students.php?class_id=<?= $c['id'] ?>" class="btn btn-outline btn-sm">View Pupils</a>
                                        <a href="classes.php?action=edit&id=<?= $c['id'] ?>" class="btn btn-secondary btn-sm">Edit</a>
                                        <form action="classes.php" method="POST" onsubmit="return confirm('Delete this class stream?');" style="display: inline;">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="post_action" value="delete_class">
                                            <input type="hidden" name="class_db_id" value="<?= $c['id'] ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">✕</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
