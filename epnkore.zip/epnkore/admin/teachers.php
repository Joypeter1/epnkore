<?php
/**
 * EP NKORE - School Management System
 * Teacher Directory & Subject Assignment Management (CRUD)
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, ['Administrator', 'Head Teacher']);

$action = $_GET['action'] ?? 'list';
$edit_id = (int)($_GET['id'] ?? 0);

// Fetch classes and subjects for assignment dropdowns
$classes = $pdo->query("SELECT id, name FROM classes ORDER BY name ASC")->fetchAll();
$subjects = $pdo->query("SELECT id, name, code FROM subjects ORDER BY name ASC")->fetchAll();

// Handle Form Submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf)) {
        set_flash('danger', 'Security validation mismatch.');
        header('Location: teachers.php');
        exit;
    }

    $post_action = $_POST['post_action'] ?? '';

    if ($post_action === 'save_teacher') {
        $teacher_db_id = (int)($_POST['teacher_db_id'] ?? 0);
        $first_name = sanitize_input($_POST['first_name'] ?? '');
        $last_name = sanitize_input($_POST['last_name'] ?? '');
        $phone = normalize_phone($_POST['phone'] ?? '');
        $email = sanitize_input(filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL));
        $teacher_code = sanitize_input($_POST['teacher_code'] ?? '');
        $qualification = sanitize_input($_POST['qualification'] ?? '');
        $specialization = sanitize_input($_POST['specialization'] ?? '');
        $status = sanitize_input($_POST['status'] ?? 'APPROVED');

        if (empty($first_name) || empty($last_name) || empty($phone) || empty($email) || empty($teacher_code)) {
            set_flash('danger', 'All primary teacher fields are required.');
            header('Location: teachers.php');
            exit;
        }

        if ($teacher_db_id > 0) {
            // Update user & teacher details
            $stmt_get = $pdo->prepare("SELECT user_id FROM teachers WHERE id = ?");
            $stmt_get->execute([$teacher_db_id]);
            $uid = $stmt_get->fetchColumn();

            if ($uid) {
                $stmt_u = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ?, phone = ?, email = ?, status = ? WHERE id = ?");
                $stmt_u->execute([$first_name, $last_name, $phone, $email, $status, $uid]);

                $stmt_t = $pdo->prepare("UPDATE teachers SET teacher_code = ?, qualification = ?, specialization = ? WHERE id = ?");
                $stmt_t->execute([$teacher_code, $qualification, $specialization, $teacher_db_id]);

                log_audit($pdo, $current_user['id'], 'TEACHER_UPDATED', "Updated teacher: {$first_name} {$last_name} ({$teacher_code})");
                set_flash('success', "Teacher record updated successfully.");
            }
        } else {
            // Create new teacher user + profile
            $temp_pw = 'Nkore@' . random_int(1000, 9999) . '!';
            $pw_hash = password_hash($temp_pw, PASSWORD_BCRYPT);

            $stmt_u = $pdo->prepare("INSERT INTO users (first_name, last_name, phone, email, password_hash, role, status, must_change_password) VALUES (?, ?, ?, ?, ?, 'Teacher', ?, 1)");
            $stmt_u->execute([$first_name, $last_name, $phone, $email, $pw_hash, $status]);
            $new_uid = $pdo->lastInsertId();

            $stmt_t = $pdo->prepare("INSERT INTO teachers (user_id, teacher_code, qualification, specialization) VALUES (?, ?, ?, ?)");
            $stmt_t->execute([$new_uid, $teacher_code, $qualification, $specialization]);

            log_audit($pdo, $current_user['id'], 'TEACHER_CREATED', "Created teacher {$first_name} {$last_name} ({$teacher_code})");
            set_flash('success', "Teacher {$first_name} {$last_name} created. Temporary password: <strong>{$temp_pw}</strong>");
        }
        header('Location: teachers.php');
        exit;

    } elseif ($post_action === 'assign_subject') {
        $teacher_id = (int)($_POST['teacher_id'] ?? 0);
        $subject_id = (int)($_POST['subject_id'] ?? 0);
        $class_id = (int)($_POST['class_id'] ?? 0);

        if ($teacher_id > 0 && $subject_id > 0 && $class_id > 0) {
            try {
                $stmt = $pdo->prepare("INSERT INTO teacher_subjects (teacher_id, subject_id, class_id) VALUES (?, ?, ?)");
                $stmt->execute([$teacher_id, $subject_id, $class_id]);
                set_flash('success', 'Class & Subject successfully assigned to teacher.');
            } catch (Exception $e) {
                set_flash('warning', 'This teacher is already assigned to that class and subject.');
            }
        }
        header('Location: teachers.php');
        exit;

    } elseif ($post_action === 'remove_assignment') {
        $assignment_id = (int)($_POST['assignment_id'] ?? 0);
        $pdo->prepare("DELETE FROM teacher_subjects WHERE id = ?")->execute([$assignment_id]);
        set_flash('success', 'Subject assignment removed.');
        header('Location: teachers.php');
        exit;
    }
}

// Fetch all teachers with user details and assignments
$stmt = $pdo->query("
    SELECT t.*, u.first_name, u.last_name, u.phone, u.email, u.status, u.profile_photo
    FROM teachers t
    JOIN users u ON t.user_id = u.id
    ORDER BY u.first_name ASC
");
$teachers = $stmt->fetchAll();

// Fetch assignments for each teacher
$teacher_assignments = [];
$as_stmt = $pdo->query("
    SELECT ts.id as assignment_id, ts.teacher_id, s.name as subject_name, s.code as subject_code, c.name as class_name
    FROM teacher_subjects ts
    JOIN subjects s ON ts.subject_id = s.id
    JOIN classes c ON ts.class_id = c.id
");
while ($row = $as_stmt->fetch()) {
    $teacher_assignments[$row['teacher_id']][] = $row;
}

// Fetch single teacher for editing
$edit_teacher = null;
if ($edit_id > 0) {
    $stmt_e = $pdo->prepare("
        SELECT t.*, u.first_name, u.last_name, u.phone, u.email, u.status
        FROM teachers t
        JOIN users u ON t.user_id = u.id
        WHERE t.id = ?
    ");
    $stmt_e->execute([$edit_id]);
    $edit_teacher = $stmt_e->fetch();
}

$page_title = "Teacher Management - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">Teacher Management</h1>
            <p class="page-subtitle">Faculty members, academic qualifications, and class/subject assignments</p>
        </div>
        <div>
            <?php if ($action !== 'create'): ?>
                <a href="teachers.php?action=create" class="btn btn-primary btn-sm">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    Add New Teacher
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Create or Edit Teacher Box -->
    <?php if ($action === 'create' || ($action === 'edit' && $edit_teacher)): ?>
        <div class="card" style="margin-bottom: 28px;">
            <div class="card-header">
                <h3 class="card-title"><?= $action === 'edit' ? 'Edit Teacher Record' : 'Register New Teacher' ?></h3>
                <a href="teachers.php" class="btn btn-secondary btn-sm">Cancel</a>
            </div>
            <div class="card-body">
                <form action="teachers.php" method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="post_action" value="save_teacher">
                    <input type="hidden" name="teacher_db_id" value="<?= $edit_teacher['id'] ?? 0 ?>">

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Teacher Code <span class="required">*</span></label>
                            <input type="text" name="teacher_code" class="form-control" placeholder="TCH-00X" value="<?= e($edit_teacher['teacher_code'] ?? 'TCH-' . random_int(100, 999)) ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">First Name <span class="required">*</span></label>
                            <input type="text" name="first_name" class="form-control" value="<?= e($edit_teacher['first_name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Last Name <span class="required">*</span></label>
                            <input type="text" name="last_name" class="form-control" value="<?= e($edit_teacher['last_name'] ?? '') ?>" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Phone Number (For Login & OTP) <span class="required">*</span></label>
                            <input type="tel" name="phone" class="form-control" placeholder="+250 788 000 000" value="<?= e($edit_teacher['phone'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email Address <span class="required">*</span></label>
                            <input type="email" name="email" class="form-control" placeholder="teacher@epnkore.edu.rw" value="<?= e($edit_teacher['email'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Account Status</label>
                            <select name="status" class="form-select">
                                <option value="APPROVED" <?= ($edit_teacher['status'] ?? '') === 'APPROVED' ? 'selected' : '' ?>>APPROVED</option>
                                <option value="PENDING" <?= ($edit_teacher['status'] ?? '') === 'PENDING' ? 'selected' : '' ?>>PENDING</option>
                                <option value="REJECTED" <?= ($edit_teacher['status'] ?? '') === 'REJECTED' ? 'selected' : '' ?>>REJECTED</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Qualification / Degree</label>
                            <input type="text" name="qualification" class="form-control" placeholder="e.g. Bachelor of Education, Diploma" value="<?= e($edit_teacher['qualification'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Specialization / Subjects</label>
                            <input type="text" name="specialization" class="form-control" placeholder="e.g. Mathematics, Sciences, Languages" value="<?= e($edit_teacher['specialization'] ?? '') ?>">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <?= $action === 'edit' ? 'Update Teacher' : 'Save Teacher' ?>
                    </button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <!-- Assign Class & Subject Form Drawer -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-header">
            <h3 class="card-title">Assign Teacher to Subject & Class Stream</h3>
        </div>
        <div class="card-body">
            <form action="teachers.php" method="POST" style="display: flex; gap: 12px; flex-wrap: wrap; align-items: flex-end;">
                <?= csrf_field() ?>
                <input type="hidden" name="post_action" value="assign_subject">

                <div style="flex: 1; min-width: 200px;">
                    <label class="form-label" style="font-size: 12.5px;">Teacher</label>
                    <select name="teacher_id" class="form-select" required>
                        <option value="">Select Teacher</option>
                        <?php foreach ($teachers as $t): ?>
                            <option value="<?= $t['id'] ?>"><?= e($t['first_name'] . ' ' . $t['last_name']) ?> (<?= e($t['teacher_code']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="flex: 1; min-width: 180px;">
                    <label class="form-label" style="font-size: 12.5px;">Subject</label>
                    <select name="subject_id" class="form-select" required>
                        <option value="">Select Subject</option>
                        <?php foreach ($subjects as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= e($s['name']) ?> (<?= e($s['code']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="flex: 1; min-width: 160px;">
                    <label class="form-label" style="font-size: 12.5px;">Class Stream</label>
                    <select name="class_id" class="form-select" required>
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?= $c['id'] ?>"><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary" style="height: 42px;">Assign Assignment</button>
            </form>
        </div>
    </div>

    <!-- Teachers List Table -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">School Teaching Staff (<?= count($teachers) ?>)</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Teacher Code</th>
                            <th>Name & Contact</th>
                            <th>Qualification</th>
                            <th>Assigned Classes & Subjects</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($teachers as $t): ?>
                            <tr>
                                <td><strong><?= e($t['teacher_code']) ?></strong></td>
                                <td>
                                    <strong><?= e($t['first_name'] . ' ' . $t['last_name']) ?></strong>
                                    <div style="font-size: 12px; color: var(--slate-500);"><?= e($t['phone']) ?> • <?= e($t['email']) ?></div>
                                </td>
                                <td>
                                    <div><?= e($t['qualification'] ?: 'Not specified') ?></div>
                                    <small style="color: var(--slate-500);"><?= e($t['specialization']) ?></small>
                                </td>
                                <td>
                                    <?php if (!empty($teacher_assignments[$t['id']])): ?>
                                        <div style="display: flex; flex-wrap: wrap; gap: 4px;">
                                            <?php foreach ($teacher_assignments[$t['id']] as $assign): ?>
                                                <span class="badge badge-primary" style="font-size: 11px; display: inline-flex; align-items: center; gap: 4px;">
                                                    <?= e($assign['subject_code']) ?> (<?= e($assign['class_name']) ?>)
                                                    <form action="teachers.php" method="POST" style="display: inline;" onsubmit="return confirm('Remove this assignment?');">
                                                        <?= csrf_field() ?>
                                                        <input type="hidden" name="post_action" value="remove_assignment">
                                                        <input type="hidden" name="assignment_id" value="<?= $assign['assignment_id'] ?>">
                                                        <button type="submit" style="background: none; border: none; color: inherit; cursor: pointer; font-size: 12px; padding: 0;">&times;</button>
                                                    </form>
                                                </span>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else: ?>
                                        <span style="font-size: 12px; color: var(--slate-400);">No assigned subjects</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge badge-<?= strtolower($t['status']) ?>">
                                        <?= e($t['status']) ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="teachers.php?action=edit&id=<?= $t['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
