<?php
/**
 * EP NKORE - School Management System
 * School News, Photos & Video Gallery (Public Portal)
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$article_id = (int)($_GET['id'] ?? 0);
$selected_article = null;

if ($article_id > 0) {
    $stmt = $pdo->prepare("SELECT n.*, u.first_name, u.last_name 
                           FROM news_updates n 
                           LEFT JOIN users u ON n.author_id = u.id 
                           WHERE n.id = ? AND n.is_published = 1");
    $stmt->execute([$article_id]);
    $selected_article = $stmt->fetch();
}

// Fetch all published updates
$updates = $pdo->query("SELECT n.*, u.first_name, u.last_name 
                        FROM news_updates n 
                        LEFT JOIN users u ON n.author_id = u.id 
                        WHERE n.is_published = 1 
                        ORDER BY n.published_at DESC")->fetchAll();

$page_title = $selected_article ? e($selected_article['title']) . " - EP NKORE" : "Latest School News & Media Updates - EP NKORE";
require_once __DIR__ . '/includes/header.php';
?>

<div class="content-body" style="max-width: 1050px; margin: 0 auto; padding: 30px 20px;">
    <!-- Single Article View if opened -->
    <?php if ($selected_article): ?>
        <div style="margin-bottom: 24px;">
            <a href="news.php" class="btn btn-outline btn-sm">← Back to All School News</a>
        </div>

        <article class="card" style="margin-bottom: 40px; overflow: hidden; border-radius: 16px;">
            <?php if ($selected_article['media_type'] === 'video' && !empty($selected_article['video_url'])): ?>
                <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; background: #000;">
                    <iframe src="<?= e($selected_article['video_url']) ?>" style="position: absolute; top:0; left: 0; width: 100%; height: 100%; border: 0;" allowfullscreen></iframe>
                </div>
            <?php elseif (!empty($selected_article['image_url'])): ?>
                <div style="max-height: 420px; overflow: hidden;">
                    <img src="<?= (strpos($selected_article['image_url'], 'http') === 0 ? '' : get_base_url()) . e($selected_article['image_url']) ?>" alt="<?= e($selected_article['title']) ?>" style="width: 100%; height: auto; object-fit: cover;">
                </div>
            <?php endif; ?>

            <div class="card-body" style="padding: 32px;">
                <div style="display: flex; gap: 10px; align-items: center; margin-bottom: 12px; flex-wrap: wrap;">
                    <span class="badge badge-<?= $selected_article['media_type'] === 'video' ? 'danger' : ($selected_article['media_type'] === 'image' ? 'success' : 'info') ?>">
                        <?= ucfirst(e($selected_article['media_type'])) ?>
                    </span>
                    <span style="font-size: 13px; color: #64748b;">
                        📅 <?= date('F d, Y', strtotime($selected_article['published_at'])) ?>
                    </span>
                    <span style="font-size: 13px; color: #64748b;">
                        ✍️ By: <?= e(($selected_article['first_name'] ?? 'School') . ' ' . ($selected_article['last_name'] ?? 'Administration')) ?>
                    </span>
                </div>

                <h1 style="font-size: 26px; font-weight: 800; color: #0f172a; margin-bottom: 16px; line-height: 1.3;">
                    <?= e($selected_article['title']) ?>
                </h1>

                <?php if (!empty($selected_article['summary'])): ?>
                    <p style="font-size: 16px; font-weight: 600; color: #334155; line-height: 1.6; border-left: 4px solid var(--primary); padding-left: 14px; margin-bottom: 24px;">
                        <?= e($selected_article['summary']) ?>
                    </p>
                <?php endif; ?>

                <div style="font-size: 15px; color: #334155; line-height: 1.8; white-space: pre-line;">
                    <?= e($selected_article['content']) ?>
                </div>

                <div style="margin-top: 32px; padding-top: 20px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
                    <div style="font-size: 13px; color: #64748b;">
                        Location: <strong>Musange Sector, Masangano Cell, Gasagara Village, Nyamagabe District</strong>
                    </div>
                    <div>
                        <a href="https://wa.me/250781125809?text=Hello%20EP%20NKORE%2C%20regarding%20the%20update%3A%20<?= urlencode($selected_article['title']) ?>" target="_blank" class="btn btn-success btn-sm">
                            Share via WhatsApp
                        </a>
                    </div>
                </div>
            </div>
        </article>
    <?php endif; ?>

    <!-- Main Header -->
    <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 24px; flex-wrap: wrap; gap: 12px;">
        <div>
            <div style="display: inline-block; background: #e0f2fe; color: #0369a1; padding: 4px 12px; border-radius: 9999px; font-size: 12px; font-weight: 700; text-transform: uppercase; margin-bottom: 6px;">
                Official News & Media Feed
            </div>
            <h1 style="font-size: 26px; font-weight: 800; color: #0f172a; margin: 0;">
                Latest Updates from School Leadership
            </h1>
            <p style="color: #64748b; font-size: 14px; margin: 4px 0 0;">
                Follow current announcements, academic highlights, video showcases, and student life in Masangano Cell
            </p>
        </div>
    </div>

    <!-- News Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 24px;">
        <?php if (empty($updates)): ?>
            <div class="card" style="grid-column: 1 / -1; text-align: center; padding: 50px 20px; color: #64748b;">
                No public announcements currently posted. Check back soon!
            </div>
        <?php else: ?>
            <?php foreach ($updates as $u): ?>
                <div class="card" style="display: flex; flex-direction: column; overflow: hidden; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); transition: transform 0.2s;" onmouseover="this.style.transform='translateY(-3px)'" onmouseout="this.style.transform='translateY(0)'">
                    <div style="position: relative; height: 190px; background: #0f172a; overflow: hidden;">
                        <?php if (!empty($u['image_url'])): ?>
                            <img src="<?= (strpos($u['image_url'], 'http') === 0 ? '' : get_base_url()) . e($u['image_url']) ?>" alt="<?= e($u['title']) ?>" style="width: 100%; height: 100%; object-fit: cover;">
                        <?php else: ?>
                            <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #1e3a8a, #0369a1); display: flex; align-items: center; justify-content: center; color: white; font-size: 40px;">
                                <?= $u['media_type'] === 'video' ? '▶' : '📰' ?>
                            </div>
                        <?php endif; ?>

                        <div style="position: absolute; top: 12px; left: 12px;">
                            <span class="badge badge-<?= $u['media_type'] === 'video' ? 'danger' : ($u['media_type'] === 'image' ? 'success' : 'info') ?>">
                                <?= ucfirst(e($u['media_type'])) ?>
                            </span>
                        </div>

                        <?php if ($u['media_type'] === 'video'): ?>
                            <div style="position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.3);">
                                <div style="width: 48px; height: 48px; border-radius: 50%; background: rgba(239, 68, 68, 0.9); color: white; display: flex; align-items: center; justify-content: center; font-size: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.3);">
                                    ▶
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="card-body" style="padding: 20px; flex: 1; display: flex; flex-direction: column; justify-content: space-between;">
                        <div>
                            <div style="font-size: 11.5px; color: #94a3b8; margin-bottom: 6px;">
                                <?= date('M d, Y', strtotime($u['published_at'])) ?>
                            </div>
                            <h3 style="font-size: 16px; font-weight: 700; color: #0f172a; margin-bottom: 8px; line-height: 1.4;">
                                <a href="news.php?id=<?= $u['id'] ?>" style="color: inherit; text-decoration: none;">
                                    <?= e($u['title']) ?>
                                </a>
                            </h3>
                            <p style="font-size: 13px; color: #64748b; line-height: 1.5; margin-bottom: 16px;">
                                <?= !empty($u['summary']) ? e(substr($u['summary'], 0, 130)) . '...' : e(substr($u['content'], 0, 130)) . '...' ?>
                            </p>
                        </div>

                        <div>
                            <a href="news.php?id=<?= $u['id'] ?>" class="btn btn-outline btn-sm" style="width: 100%; text-align: center;">
                                Read Full Story <?= $u['media_type'] === 'video' ? '& Watch Video' : '' ?> →
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
