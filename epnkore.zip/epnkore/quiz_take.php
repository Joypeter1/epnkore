<?php
/**
 * EP NKORE - School Management System
 * Online Quiz & Test Taker Portal for Pupils
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$quiz_id = (int)($_GET['quiz_id'] ?? ($_POST['quiz_id'] ?? 0));

// If no quiz selected, display list of published quizzes
if ($quiz_id <= 0) {
    $quizzes = $pdo->query("SELECT q.*, c.name AS class_name, s.name AS subject_name,
                                  (SELECT COUNT(*) FROM quiz_questions WHERE quiz_id = q.id) AS q_count
                           FROM quizzes q
                           JOIN classes c ON q.class_id = c.id
                           JOIN subjects s ON q.subject_id = s.id
                           WHERE q.status = 'Published'
                           ORDER BY q.id DESC")->fetchAll();

    $page_title = "Online Tests & Quizzes - EP NKORE";
    require_once __DIR__ . '/includes/header.php';
    ?>
    <div class="content-body" style="max-width: 900px; margin: 0 auto; padding: 30px 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
            <div style="display: inline-block; background: #dbeafe; color: #1e40af; padding: 4px 12px; border-radius: 9999px; font-size: 12px; font-weight: 700; text-transform: uppercase; margin-bottom: 8px;">
                Digital E-Learning & Assessments
            </div>
            <h1 style="font-size: 26px; font-weight: 800; color: #0f172a; margin-bottom: 8px;">
                Available Online Quizzes & Tests
            </h1>
            <p style="color: #64748b; font-size: 14px;">
                Select your class test to begin. Please prepare your Student Registration ID.
            </p>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px;">
            <?php if (empty($quizzes)): ?>
                <div class="card" style="grid-column: 1 / -1; text-align: center; padding: 40px; color: #64748b;">
                    No active tests are currently published. Check back later or ask your class teacher.
                </div>
            <?php else: ?>
                <?php foreach ($quizzes as $q): ?>
                    <div class="card" style="display: flex; flex-direction: column; justify-content: space-between; border-top: 4px solid var(--primary);">
                        <div class="card-body" style="padding: 20px;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                <span style="background: #e0f2fe; color: #0369a1; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 700;">
                                    <?= e($q['class_name']) ?>
                                </span>
                                <span style="font-size: 12px; color: #64748b;">
                                    ⏱ <?= $q['duration_minutes'] ?> mins
                                </span>
                            </div>

                            <h3 style="font-size: 16px; font-weight: 700; color: #0f172a; margin-bottom: 6px;">
                                <?= e($q['title']) ?>
                            </h3>
                            <p style="font-size: 13px; color: #64748b; margin-bottom: 12px;">
                                Subject: <strong><?= e($q['subject_name']) ?></strong> • Total: <strong><?= number_format($q['total_marks'], 0) ?> pts</strong> (<?= $q['q_count'] ?> Qs)
                            </p>

                            <div style="font-size: 12px; margin-bottom: 16px; color: #475569;">
                                <?= $q['show_results_immediately'] ? '✓ Instant score feedback enabled' : '⏱ Results reviewed by teacher' ?>
                            </div>

                            <a href="quiz_take.php?quiz_id=<?= $q['id'] ?>" class="btn btn-primary" style="width: 100%; text-align: center;">
                                Start Test Now →
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

// Fetch Quiz & Questions
$q_stmt = $pdo->prepare("SELECT q.*, c.name AS class_name, s.name AS subject_name 
                         FROM quizzes q 
                         JOIN classes c ON q.class_id = c.id 
                         JOIN subjects s ON q.subject_id = s.id 
                         WHERE q.id = ?");
$q_stmt->execute([$quiz_id]);
$quiz = $q_stmt->fetch();

if (!$quiz) {
    set_flash('danger', 'Quiz not found or has been removed.');
    header('Location: quiz_take.php');
    exit;
}

$questions = $pdo->prepare("SELECT * FROM quiz_questions WHERE quiz_id = ? ORDER BY id ASC");
$questions->execute([$quiz_id]);
$quiz_questions = $questions->fetchAll();

// Fetch pupils belonging to this class for easy identification
$students_stmt = $pdo->prepare("SELECT id, student_id, first_name, last_name FROM students WHERE class_id = ? AND status = 'Active' ORDER BY first_name ASC");
$students_stmt->execute([$quiz['class_id']]);
$class_students = $students_stmt->fetchAll();

$submission_result = null;

// Handle Test Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_quiz') {
    $student_id = (int)($_POST['student_id'] ?? 0);
    $entered_answers = $_POST['answers'] ?? [];

    if ($student_id <= 0) {
        set_flash('danger', 'Please select your student name or enter your valid Student ID.');
    } elseif (empty($quiz_questions)) {
        set_flash('danger', 'This quiz has no questions.');
    } else {
        $score = 0.0;
        $total_possible = 0.0;
        $detailed_review = [];

        foreach ($quiz_questions as $q) {
            $q_id = $q['id'];
            $total_possible += (float)$q['points'];
            $user_choice = strtoupper(trim($entered_answers[$q_id] ?? ''));
            $is_correct = ($user_choice === strtoupper($q['correct_answer']));

            if ($is_correct) {
                $score += (float)$q['points'];
            }

            $detailed_review[] = [
                'question_text' => $q['question_text'],
                'user_choice' => $user_choice,
                'correct_answer' => $q['correct_answer'],
                'is_correct' => $is_correct,
                'points' => (float)$q['points'],
                'explanation' => $q['explanation'],
                'options' => [
                    'A' => $q['option_a'],
                    'B' => $q['option_b'],
                    'C' => $q['option_c'],
                    'D' => $q['option_d'],
                ]
            ];
        }

        $percentage = ($total_possible > 0) ? ($score / $total_possible) * 100 : 0;
        $answers_json = json_encode($entered_answers);

        // Record attempt in database
        $att_stmt = $pdo->prepare("INSERT INTO quiz_attempts (quiz_id, student_id, score_obtained, total_possible, percentage, answers_json, is_recorded) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $att_stmt->execute([$quiz_id, $student_id, $score, $total_possible, $percentage, $answers_json, $quiz['auto_record_marks']]);

        // If auto-recording to official marks table is enabled
        if ($quiz['auto_record_marks']) {
            try {
                // Check if mark already exists for this student, subject, and assessment
                $assessment_name = 'Online Quiz: ' . substr($quiz['title'], 0, 30);
                $term_id = 1; // Term 1 default
                $acad_id = 1;

                $chk_mark = $pdo->prepare("SELECT id FROM student_marks WHERE student_id = ? AND subject_id = ? AND assessment_type = ?");
                $chk_mark->execute([$student_id, $quiz['subject_id'], $assessment_name]);
                $existing_mark = $chk_mark->fetch();

                if ($existing_mark) {
                    $upd_mark = $pdo->prepare("UPDATE student_marks SET marks = ?, max_marks = ?, date_recorded = CURDATE() WHERE id = ?");
                    $upd_mark->execute([$score, $total_possible, $existing_mark['id']]);
                } else {
                    $ins_mark = $pdo->prepare("INSERT INTO student_marks (student_id, subject_id, class_id, term_id, academic_year_id, assessment_type, marks, max_marks, teacher_id, date_recorded) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE())");
                    $ins_mark->execute([$student_id, $quiz['subject_id'], $quiz['class_id'], $term_id, $acad_id, $assessment_name, $score, $total_possible, $quiz['teacher_id']]);
                }
            } catch (Exception $e) {
                // Fail-safe logging
            }
        }

        // Prepare submission result state
        $stu_stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
        $stu_stmt->execute([$student_id]);
        $student_info = $stu_stmt->fetch();

        $submission_result = [
            'student' => $student_info,
            'score' => $score,
            'total_possible' => $total_possible,
            'percentage' => $percentage,
            'show_immediately' => (bool)$quiz['show_results_immediately'],
            'auto_recorded' => (bool)$quiz['auto_record_marks'],
            'review' => $detailed_review
        ];
    }
}

$page_title = e($quiz['title']) . " - EP NKORE";
require_once __DIR__ . '/includes/header.php';
?>

<div class="content-body" style="max-width: 800px; margin: 0 auto; padding: 24px 16px;">
    <?php if ($submission_result): ?>
        <!-- RESULTS SCREEN -->
        <div class="card" style="border-top: 4px solid #10b981;">
            <div class="card-body" style="padding: 30px; text-align: center;">
                <div style="font-size: 40px; margin-bottom: 10px;">
                    <?= $submission_result['percentage'] >= 50 ? '🎉' : '📝' ?>
                </div>

                <h1 style="font-size: 22px; font-weight: 800; color: #0f172a; margin-bottom: 4px;">
                    Quiz Submitted Successfully!
                </h1>
                <p style="color: #64748b; font-size: 14px; margin-bottom: 20px;">
                    Pupil: <strong><?= e($submission_result['student']['first_name'] . ' ' . $submission_result['student']['last_name']) ?></strong> 
                    (<?= e($submission_result['student']['student_id']) ?>)
                </p>

                <?php if ($submission_result['show_immediately']): ?>
                    <!-- Instant Marks Display -->
                    <div style="background: #f0fdf4; border: 1px solid #86efac; border-radius: 12px; padding: 24px; max-width: 360px; margin: 0 auto 24px;">
                        <span style="font-size: 12px; font-weight: 700; color: #166534; text-transform: uppercase;">Your Score</span>
                        <div style="font-size: 36px; font-weight: 900; color: #15803d; margin: 4px 0;">
                            <?= number_format($submission_result['score'], 1) ?> <span style="font-size: 18px; color: #4ade80;">/ <?= number_format($submission_result['total_possible'], 1) ?> pts</span>
                        </div>
                        <div style="font-size: 14px; font-weight: 700; color: #166534;">
                            Grade: <?= number_format($submission_result['percentage'], 1) ?>% 
                            (<?= $submission_result['percentage'] >= 70 ? 'Distinction' : ($submission_result['percentage'] >= 50 ? 'Pass' : 'Requires Revision') ?>)
                        </div>
                    </div>

                    <?php if ($submission_result['auto_recorded']): ?>
                        <div style="display: inline-block; background: #e0f2fe; color: #0369a1; padding: 6px 14px; border-radius: 9999px; font-size: 12px; font-weight: 600; margin-bottom: 24px;">
                            ✓ Ayo manota yahise yandikwa mu buryo bwa automatique muri gradebook y'ishuri
                        </div>
                    <?php endif; ?>

                    <!-- Question-by-Question Review -->
                    <div style="text-align: left; margin-top: 24px; border-top: 1px solid #e2e8f0; padding-top: 20px;">
                        <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 16px; color: #0f172a;">
                            Detailed Review & Answers
                        </h3>
                        <div style="display: flex; flex-direction: column; gap: 14px;">
                            <?php foreach ($submission_result['review'] as $idx => $r): ?>
                                <div style="background: <?= $r['is_correct'] ? '#f0fdf4; border: 1px solid #bbf7d0;' : '#fef2f2; border: 1px solid #fecaca;' ?>; padding: 14px; border-radius: 8px;">
                                    <div style="display: flex; justify-content: space-between; font-weight: 700; font-size: 13px; margin-bottom: 6px;">
                                        <span>Q<?= $idx + 1 ?>: <?= e($r['question_text']) ?></span>
                                        <span style="color: <?= $r['is_correct'] ? '#15803d' : '#b91c1c' ?>;">
                                            <?= $r['is_correct'] ? '✓ +' . $r['points'] . ' pts' : '✕ 0 pts' ?>
                                        </span>
                                    </div>
                                    <div style="font-size: 12.5px; margin-bottom: 4px;">
                                        Your Choice: <strong>Option <?= e($r['user_choice']) ?> (<?= e($r['options'][$r['user_choice']] ?? 'None') ?>)</strong>
                                    </div>
                                    <?php if (!$r['is_correct']): ?>
                                        <div style="font-size: 12.5px; color: #15803d;">
                                            Correct Choice: <strong>Option <?= e($r['correct_answer']) ?> (<?= e($r['options'][$r['correct_answer']] ?? '') ?>)</strong>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($r['explanation'])): ?>
                                        <div style="font-size: 11.5px; color: #475569; margin-top: 4px; font-style: italic;">
                                            Teacher Note: <?= e($r['explanation']) ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                <?php else: ?>
                    <!-- Hidden Results Notice as requested by teacher -->
                    <div style="background: #fffbeb; border: 1px solid #fde68a; border-radius: 12px; padding: 24px; max-width: 480px; margin: 0 auto 24px; text-align: left;">
                        <h3 style="font-size: 15px; font-weight: 700; color: #92400e; margin-bottom: 6px;">
                            Amanota Yabitswe Neza (Pending Teacher Release)
                        </h3>
                        <p style="font-size: 13px; color: #78350f; line-height: 1.5; margin: 0;">
                            Mwalimu yashyizeho ko amanota azatangazwa amaze kugenzura ibisubizo by'abanyeshuri bose. Komeza ukurikirane portal y'ishuri.
                        </p>
                    </div>
                <?php endif; ?>

                <div style="margin-top: 24px;">
                    <a href="quiz_take.php" class="btn btn-secondary">Back to Quizzes List</a>
                </div>
            </div>
        </div>

    <?php else: ?>
        <!-- QUIZ QUESTIONS FORM -->
        <div class="card" style="margin-bottom: 20px;">
            <div class="card-header" style="background: #1e3a8a; color: white; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                <div>
                    <span style="font-size: 11px; background: rgba(255,255,255,0.2); padding: 2px 8px; border-radius: 9999px;">
                        <?= e($quiz['class_name']) ?> • <?= e($quiz['subject_name']) ?>
                    </span>
                    <h1 style="font-size: 18px; font-weight: 800; margin: 6px 0 2px;">
                        <?= e($quiz['title']) ?>
                    </h1>
                </div>
                <div style="background: rgba(0,0,0,0.25); padding: 6px 14px; border-radius: 8px; font-size: 14px; font-weight: 700; font-family: monospace;">
                    ⏱ Time Allowed: <?= $quiz['duration_minutes'] ?> Mins
                </div>
            </div>

            <div class="card-body" style="padding: 20px;">
                <?php if (!empty($quiz['instructions'])): ?>
                    <div style="background: #f8fafc; border-left: 4px solid #2563eb; padding: 10px 14px; border-radius: 4px; font-size: 13px; color: #475569; margin-bottom: 20px;">
                        <strong>Instructions:</strong> <?= nl2br(e($quiz['instructions'])) ?>
                    </div>
                <?php endif; ?>

                <form action="quiz_take.php" method="POST" id="quizForm">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="submit_quiz">
                    <input type="hidden" name="quiz_id" value="<?= $quiz['id'] ?>">

                    <!-- Pupil Identification -->
                    <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
                        <h3 style="font-size: 14px; font-weight: 700; color: #1e40af; margin-bottom: 10px;">
                            Step 1: Identify Yourself as a Pupil
                        </h3>
                        <div>
                            <label class="form-label" style="font-size: 12.5px;">Select Your Name (<?= e($quiz['class_name']) ?>) *</label>
                            <select name="student_id" class="form-select" required>
                                <option value="">-- Choose Pupil Name --</option>
                                <?php foreach ($class_students as $st): ?>
                                    <option value="<?= $st['id'] ?>">
                                        <?= e($st['first_name'] . ' ' . $st['last_name']) ?> (ID: <?= e($st['student_id']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Questions List -->
                    <div style="display: flex; flex-direction: column; gap: 20px; margin-bottom: 28px;">
                        <?php foreach ($quiz_questions as $index => $q): ?>
                            <div style="background: white; border: 1px solid #cbd5e1; border-radius: 8px; padding: 18px;">
                                <div style="display: flex; justify-content: space-between; font-weight: 700; font-size: 14px; margin-bottom: 12px; color: #0f172a;">
                                    <span>Question <?= $index + 1 ?>: <?= e($q['question_text']) ?></span>
                                    <span style="font-size: 11px; background: #e2e8f0; color: #334155; padding: 2px 8px; border-radius: 4px; height: fit-content;">
                                        <?= number_format($q['points'], 1) ?> pts
                                    </span>
                                </div>

                                <div style="display: flex; flex-direction: column; gap: 8px;">
                                    <label style="display: flex; align-items: center; gap: 10px; padding: 8px 12px; border: 1px solid #e2e8f0; border-radius: 6px; cursor: pointer;">
                                        <input type="radio" name="answers[<?= $q['id'] ?>]" value="A" required>
                                        <span style="font-size: 13.5px;"><strong>A:</strong> <?= e($q['option_a']) ?></span>
                                    </label>

                                    <label style="display: flex; align-items: center; gap: 10px; padding: 8px 12px; border: 1px solid #e2e8f0; border-radius: 6px; cursor: pointer;">
                                        <input type="radio" name="answers[<?= $q['id'] ?>]" value="B">
                                        <span style="font-size: 13.5px;"><strong>B:</strong> <?= e($q['option_b']) ?></span>
                                    </label>

                                    <?php if (!empty($q['option_c'])): ?>
                                        <label style="display: flex; align-items: center; gap: 10px; padding: 8px 12px; border: 1px solid #e2e8f0; border-radius: 6px; cursor: pointer;">
                                            <input type="radio" name="answers[<?= $q['id'] ?>]" value="C">
                                            <span style="font-size: 13.5px;"><strong>C:</strong> <?= e($q['option_c']) ?></span>
                                        </label>
                                    <?php endif; ?>

                                    <?php if (!empty($q['option_d'])): ?>
                                        <label style="display: flex; align-items: center; gap: 10px; padding: 8px 12px; border: 1px solid #e2e8f0; border-radius: 6px; cursor: pointer;">
                                            <input type="radio" name="answers[<?= $q['id'] ?>]" value="D">
                                            <span style="font-size: 13.5px;"><strong>D:</strong> <?= e($q['option_d']) ?></span>
                                        </label>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <a href="quiz_take.php" class="btn btn-secondary">Cancel</a>
                        <button type="submit" class="btn btn-primary btn-lg" onclick="return confirm('Submit your test answers now?');">
                            Submit My Test Answers
                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
