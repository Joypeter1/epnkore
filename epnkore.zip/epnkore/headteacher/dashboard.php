<?php
/**
 * EP NKORE - School Management System
 * Head Teacher Academic Oversight Dashboard
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$current_user = require_role($pdo, ['Head Teacher', 'Administrator']);

// Fetch Overview Metrics
$total_pupils = (int)$pdo->query("SELECT COUNT(*) FROM students WHERE status = 'Active'")->fetchColumn();
$total_teachers = (int)$pdo->query("SELECT COUNT(*) FROM teachers JOIN users ON teachers.user_id = users.id WHERE users.status = 'APPROVED'")->fetchColumn();
$total_classes = (int)$pdo->query("SELECT COUNT(*) FROM classes")->fetchColumn();
$today_date = date('Y-m-d');

// Today's attendance summary
$att_stmt = $pdo->prepare("SELECT status, COUNT(*) as count FROM attendance WHERE attendance_date = ? GROUP BY status");
$att_stmt->execute([$today_date]);
$att_today = ['present' => 0, 'absent' => 0, 'late' => 0];
while ($row = $att_stmt->fetch()) {
    $k = strtolower($row['status']);
    if (isset($att_today[$k])) $att_today[$k] = (int)$row['count'];
}

// Academic Marks Oversight - Recent marks entered
$recent_marks = $pdo->query("
    SELECT m.*, s.student_id_number, s.first_name as stu_first, s.last_name as stu_last,
           sub.name as subject_name, sub.code as subject_code,
           c.name as class_name,
           u.first_name as tch_first, u.last_name as tch_last
    FROM marks m
    JOIN students s ON m.student_id = s.id
    JOIN subjects sub ON m.subject_id = sub.id
    JOIN classes c ON s.class_id = c.id
    LEFT JOIN teachers t ON m.teacher_id = t.id
    LEFT JOIN users u ON t.user_id = u.id
    ORDER BY m.id DESC
    LIMIT 8
")->fetchAll();

// Class Enrollment and Attendance breakdown
$class_stats = $pdo->query("
    SELECT c.id, c.name, c.stream,
           (SELECT COUNT(*) FROM students s WHERE s.class_id = c.id AND s.status = 'Active') as pupil_count,
           (SELECT COUNT(DISTINCT ts.teacher_id) FROM teacher_subjects ts WHERE ts.class_id = c.id) as teacher_count
    FROM classes c
    ORDER BY c.name ASC
")->fetchAll();

$page_title = "Head Teacher Dashboard - EP NKORE";
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="content-body">
    <div class="page-header">
        <div>
            <h1 class="page-title">Head Teacher Academic Portal</h1>
            <p class="page-subtitle">Welcome, <?= e($current_user['first_name'] . ' ' . $current_user['last_name']) ?>. Academic oversight, teacher supervision, and curriculum tracking.</p>
        </div>
        <div style="display: flex; gap: 8px;">
            <a href="../admin/reports.php" class="btn btn-primary btn-sm">
                Generate Academic Bulletins
            </a>
        </div>
    </div>

    <!-- Overview Stats Grid -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-info">
                <span class="stat-label">Enrolled Pupils</span>
                <span class="stat-value"><?= number_format($total_pupils) ?></span>
                <span class="stat-subtext">Active Learners</span>
            </div>
            <div class="stat-icon blue">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-info">
                <span class="stat-label">Faculty Teachers</span>
                <span class="stat-value"><?= number_format($total_teachers) ?></span>
                <span class="stat-subtext">Assigned Staff</span>
            </div>
            <div class="stat-icon emerald">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-info">
                <span class="stat-label">Today's Present</span>
                <span class="stat-value" style="color: var(--success);"><?= number_format($att_today['present']) ?></span>
                <span class="stat-subtext">Recorded Pupils</span>
            </div>
            <div class="stat-icon purple">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-info">
                <span class="stat-label">Today's Absent</span>
                <span class="stat-value" style="color: var(--danger);"><?= number_format($att_today['absent']) ?></span>
                <span class="stat-subtext">Requires Follow-up</span>
            </div>
            <div class="stat-icon amber">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            </div>
        </div>
    </div>

    <!-- Class Roster & Oversight Breakdown -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-header">
            <h3 class="card-title">Class Stream Academic Breakdown</h3>
            <span class="badge badge-primary"><?= $total_classes ?> Active Classes</span>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Class Stream</th>
                            <th>Active Pupils</th>
                            <th>Assigned Teachers</th>
                            <th>Quick Performance Sheet</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($class_stats as $cs): ?>
                            <tr>
                                <td><strong><?= e($cs['name']) ?></strong> (<?= e($cs['stream'] ?: 'Main') ?>)</td>
                                <td><span class="badge badge-primary"><?= (int)$cs['pupil_count'] ?> Pupils</span></td>
                                <td><?= (int)$cs['teacher_count'] ?> Teacher(s) Assigned</td>
                                <td>
                                    <a href="../admin/reports.php?type=class_performance&class_id=<?= $cs['id'] ?>" class="btn btn-outline btn-sm">
                                        View Class Rankings
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Recent Exam Marks Activity -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Recent Marks Submitted by Teachers</h3>
            <a href="../teacher/marks.php" class="btn btn-outline btn-sm">Marks Management</a>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Class</th>
                            <th>Subject</th>
                            <th>Exam / Term</th>
                            <th>Score</th>
                            <th>Grade</th>
                            <th>Teacher</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recent_marks)): ?>
                            <tr><td colspan="7" style="text-align: center; padding: 20px; color: var(--slate-500);">No exam marks logged yet.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($recent_marks as $rm): ?>
                            <tr>
                                <td>
                                    <strong><?= e($rm['stu_first'] . ' ' . $rm['stu_last']) ?></strong>
                                    <div style="font-size: 11px; color: var(--slate-500);"><?= e($rm['student_id_number']) ?></div>
                                </td>
                                <td><?= e($rm['class_name']) ?></td>
                                <td><?= e($rm['subject_name']) ?></td>
                                <td><?= e($rm['exam_type']) ?> (<?= e($rm['term']) ?>)</td>
                                <td><strong><?= number_format($rm['marks_obtained'], 1) ?></strong> / <?= number_format($rm['max_marks'], 0) ?></td>
                                <td>
                                    <span class="badge badge-<?= $rm['grade'] === 'A' || $rm['grade'] === 'B' ? 'approved' : ($rm['grade'] === 'C' ? 'pending' : 'danger') ?>">
                                        <?= e($rm['grade']) ?>
                                    </span>
                                </td>
                                <td><?= e($rm['tch_first'] ? $rm['tch_first'] . ' ' . $rm['tch_last'] : 'Staff') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
