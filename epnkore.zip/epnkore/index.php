<?php
/**
 * EP NKORE - School Management System
 * Home Page with Integrated Portal Login & School Showcase
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

// If already authenticated, redirect straight to their dashboard
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

$page_title = "Welcome to EP NKORE - School Management System";
require_once __DIR__ . '/includes/header.php';
?>

<!-- Hero Section -->
<section class="home-hero">
    <div class="home-container">
        <div class="hero-grid">
            <div class="hero-content">
                <div class="hero-badge">
                    <span>★</span> Official Academic Portal 2025/2026
                </div>
                <h1 class="hero-title">Empowering Young Minds for a Digital Future</h1>
                <p class="hero-lead">
                    Welcome to <strong>EP NKORE</strong>. A premier basic education institution dedicated to academic excellence, STEM and computer literacy, moral values, and community progress.
                </p>
                <div class="hero-metrics">
                    <div class="metric-item">
                        <span class="metric-val">650+</span>
                        <span class="metric-lbl">Active Pupils</span>
                    </div>
                    <div class="metric-item">
                        <span class="metric-val">100%</span>
                        <span class="metric-lbl">Primary Leaving Exam Pass</span>
                    </div>
                    <div class="metric-item">
                        <span class="metric-val">1:1</span>
                        <span class="metric-lbl">Smart Classrooms</span>
                    </div>
                </div>
            </div>

            <!-- Login Form Card -->
            <div class="home-login-card">
                <h2 class="login-card-title">Staff & Teacher Portal</h2>
                <p class="login-card-sub">Sign in with your registered phone number or email</p>

                <form action="login.php" method="POST" autocomplete="on">
                    <?= csrf_field() ?>

                    <div class="form-group">
                        <label for="username" class="form-label">Phone Number or Email <span class="required">*</span></label>
                        <input type="text" id="username" name="username" class="form-control" placeholder="e.g. +250788000001 or staff@epnkore.edu.rw" required autofocus>
                    </div>

                    <div class="form-group">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <label for="password" class="form-label">Password <span class="required">*</span></label>
                            <a href="login.php?action=forgot" style="font-size: 12.5px; color: var(--primary);">Forgot Password?</a>
                        </div>
                        <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password" required>
                    </div>

                    <button type="submit" class="btn btn-primary btn-lg" style="width: 100%; margin-top: 10px;">
                        Secure Sign In
                    </button>

                    <div style="margin-top: 18px; text-align: center; font-size: 13.5px; color: var(--slate-600); border-top: 1px solid var(--slate-200); padding-top: 16px;">
                        Need staff access? 
                        <a href="register.php" style="font-weight: 700; color: var(--primary);">Create an Account</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- School Features & Smart Classroom Showcase -->
<section class="school-features-section">
    <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 24px; flex-wrap: wrap; gap: 12px;">
        <div>
            <span style="font-size: 11px; background: #e0f2fe; color: #0369a1; padding: 4px 10px; border-radius: 9999px; font-weight: 700; text-transform: uppercase;">
                Ibigezweho ku Kigo (Live School Updates)
            </span>
            <h2 class="section-title" style="margin-top: 6px; text-align: left;">
                Latest News, Photos & Video Updates from School Leadership
            </h2>
            <p class="section-subtitle" style="text-align: left; margin-bottom: 0;">
                Follow real-time announcements, school activities, video tours, and academic milestones from EP NKORE.
            </p>
        </div>
        <div>
            <a href="news.php" class="btn btn-primary btn-sm">View All News & Videos →</a>
        </div>
    </div>

    <!-- Fetch Latest 3 Updates dynamically from database -->
    <?php
    $recent_updates = [];
    try {
        $news_res = $pdo->query("SELECT * FROM news_updates WHERE is_published = 1 ORDER BY published_at DESC LIMIT 3");
        if ($news_res) {
            $recent_updates = $news_res->fetchAll();
        }
    } catch (Exception $e) {}
    ?>

    <div class="gallery-grid" style="margin-bottom: 40px;">
        <?php if (empty($recent_updates)): ?>
            <div class="card" style="grid-column: 1 / -1; padding: 30px; text-align: center; color: #64748b;">
                School leadership updates will appear here. Stay tuned!
            </div>
        <?php else: ?>
            <?php foreach ($recent_updates as $nu): ?>
                <div class="gallery-card" style="display: flex; flex-direction: column; justify-content: space-between;">
                    <div style="height: 190px; background: #0f172a; position: relative; overflow: hidden;">
                        <?php if (!empty($nu['image_url'])): ?>
                            <img src="<?= (strpos($nu['image_url'], 'http') === 0 ? '' : get_base_url()) . e($nu['image_url']) ?>" alt="<?= e($nu['title']) ?>" style="width: 100%; height: 100%; object-fit: cover;">
                        <?php else: ?>
                            <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #1e3a8a, #0369a1); display: flex; align-items: center; justify-content: center; color: white; font-size: 40px;">
                                <?= $nu['media_type'] === 'video' ? '▶' : '📰' ?>
                            </div>
                        <?php endif; ?>

                        <div style="position: absolute; top: 10px; left: 12px;">
                            <span class="badge badge-<?= $nu['media_type'] === 'video' ? 'danger' : ($nu['media_type'] === 'image' ? 'success' : 'info') ?>" style="font-size: 11px;">
                                <?= ucfirst(e($nu['media_type'])) ?>
                            </span>
                        </div>

                        <?php if ($nu['media_type'] === 'video'): ?>
                            <div style="position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.3);">
                                <div style="width: 44px; height: 44px; border-radius: 50%; background: #ef4444; color: white; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 4px 10px rgba(0,0,0,0.3);">
                                    ▶
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="gallery-body" style="flex: 1; display: flex; flex-direction: column; justify-content: space-between;">
                        <div>
                            <div style="font-size: 11.5px; color: #94a3b8; margin-bottom: 6px;">
                                📅 <?= date('M d, Y', strtotime($nu['published_at'])) ?>
                            </div>
                            <h3 class="gallery-title" style="font-size: 15px; margin-bottom: 6px; line-height: 1.4;">
                                <a href="news.php?id=<?= $nu['id'] ?>" style="color: inherit; text-decoration: none;">
                                    <?= e($nu['title']) ?>
                                </a>
                            </h3>
                            <p class="gallery-desc" style="font-size: 13px; line-height: 1.5; margin-bottom: 12px;">
                                <?= !empty($nu['summary']) ? e(substr($nu['summary'], 0, 110)) . '...' : e(substr($nu['content'], 0, 110)) . '...' ?>
                            </p>
                        </div>
                        <a href="news.php?id=<?= $nu['id'] ?>" class="btn btn-outline btn-sm" style="width: 100%; text-align: center;">
                            Read Update <?= $nu['media_type'] === 'video' ? '& Play Video' : '' ?> →
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Quick Services: E-Learning Hub & Online Tests -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 40px;">
        <div style="background: linear-gradient(135deg, #1e3a8a, #2563eb); border-radius: 12px; padding: 24px; color: white; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
            <div>
                <span style="background: rgba(255,255,255,0.2); padding: 2px 8px; border-radius: 9999px; font-size: 11px; font-weight: 700; text-transform: uppercase;">For Pupils & Parents</span>
                <h3 style="font-size: 18px; font-weight: 800; margin: 6px 0 4px;">Notes & Homework Hub</h3>
                <p style="font-size: 13px; opacity: 0.9; margin: 0; max-width: 340px;">Download teacher notes, exercises, and homework assignments for all primary classes.</p>
            </div>
            <a href="materials.php" class="btn btn-warning btn-sm" style="font-weight: 700; white-space: nowrap;">Browse Materials →</a>
        </div>

        <div style="background: linear-gradient(135deg, #0f766e, #0d9488); border-radius: 12px; padding: 24px; color: white; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
            <div>
                <span style="background: rgba(255,255,255,0.2); padding: 2px 8px; border-radius: 9999px; font-size: 11px; font-weight: 700; text-transform: uppercase;">Online Assessments</span>
                <h3 style="font-size: 18px; font-weight: 800; margin: 6px 0 4px;">Take Online Tests & Quizzes</h3>
                <p style="font-size: 13px; opacity: 0.9; margin: 0; max-width: 340px;">Practice questions with instant scoring feedback or take continuous terminal evaluations.</p>
            </div>
            <a href="quiz_take.php" class="btn btn-warning btn-sm" style="font-weight: 700; white-space: nowrap;">Open Tests →</a>
        </div>
    </div>

    <!-- Academic Facilities -->
    <h2 class="section-title">Academic Environment & Facilities</h2>
    <p class="section-subtitle">Fostering high standards of primary education through modern pedagogy and technology.</p>

    <div class="gallery-grid">
        <div class="gallery-card">
            <!-- Modern Smart Computer Lab Visual -->
            <div style="height: 200px; background: linear-gradient(135deg, #1e3a8a, #0369a1); display: flex; align-items: center; justify-content: center; color: white; position: relative; overflow: hidden;">
                <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="opacity: 0.9;">
                    <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
                    <line x1="8" y1="21" x2="16" y2="21"/>
                    <line x1="12" y1="17" x2="12" y2="21"/>
                </svg>
                <div style="position: absolute; bottom: 10px; left: 16px; background: rgba(0,0,0,0.5); padding: 4px 10px; border-radius: 4px; font-size: 12px; font-weight: 600;">Smart Computer Classroom</div>
            </div>
            <div class="gallery-body">
                <h3 class="gallery-title">Modern ICT & Smart Learning</h3>
                <p class="gallery-desc">EP NKORE provides dedicated computer lab sessions where young pupils develop foundational digital skills, coding literacy, and interactive e-learning.</p>
            </div>
        </div>

        <div class="gallery-card">
            <div style="height: 200px; background: linear-gradient(135deg, #0f766e, #14b8a6); display: flex; align-items: center; justify-content: center; color: white; position: relative; overflow: hidden;">
                <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="opacity: 0.9;">
                    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
                    <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
                </svg>
                <div style="position: absolute; bottom: 10px; left: 16px; background: rgba(0,0,0,0.5); padding: 4px 10px; border-radius: 4px; font-size: 12px; font-weight: 600;">Curriculum & Assessment</div>
            </div>
            <div class="gallery-body">
                <h3 class="gallery-title">Competence-Based Curriculum</h3>
                <p class="gallery-desc">Comprehensive basic education aligned with Rwanda Education Board (REB) standards covering STEM, Languages, Social Sciences, and Creative Arts.</p>
            </div>
        </div>

        <div class="gallery-card">
            <div style="height: 200px; background: linear-gradient(135deg, #b45309, #f59e0b); display: flex; align-items: center; justify-content: center; color: white; position: relative; overflow: hidden;">
                <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="opacity: 0.9;">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                    <circle cx="9" cy="7" r="4"/>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                </svg>
                <div style="position: absolute; bottom: 10px; left: 16px; background: rgba(0,0,0,0.5); padding: 4px 10px; border-radius: 4px; font-size: 12px; font-weight: 600;">Parent & School Partnership</div>
            </div>
            <div class="gallery-body">
                <h3 class="gallery-title">Active Attendance & Marks Tracking</h3>
                <p class="gallery-desc">Transparent daily attendance monitoring, continuous assessment grading, and automated report card generation accessible to teachers and administrators.</p>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
