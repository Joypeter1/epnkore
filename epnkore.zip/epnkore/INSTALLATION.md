# EP NKORE - School Management System
## Deployment & Installation Manual for Shared Hosting (InfinityFree, cPanel, Hostinger)

---

### 1. System Requirements
- **PHP Version:** PHP 8.0, 8.1, 8.2, or 8.3
- **Database:** MySQL 5.7+ or MariaDB 10.3+
- **PHP Extensions:** `pdo_mysql`, `mbstring`, `session`, `ctype`, `gd` (standard on all shared hosting).
- **Runtime:** Standard Apache / Nginx shared hosting. **Zero Node.js, zero Composer, zero framework build required.**

---

### 2. Step-by-Step Installation Guide

#### Step 1: Create a MySQL Database
1. Log into your hosting control panel (**cPanel**, **InfinityFree VistaPanel**, or **DirectAdmin**).
2. Open **MySQL Databases** or **Database Wizard**.
3. Create a new database named `ep_nkore` (e.g. `epiz_12345678_ep_nkore` on InfinityFree).
4. Create a database user and assign a strong password.
5. Grant **ALL PRIVILEGES** to the user on that database.

#### Step 2: Import the Database Schema
1. Open **phpMyAdmin** from your control panel.
2. Select your newly created database in the left sidebar.
3. Click the **Import** tab on the top menu.
4. Click **Choose File** and select `database/ep_nkore.sql` from this package.
5. Scroll down and click **Import / Go**.
6. All tables (`users`, `teachers`, `students`, `classes`, `subjects`, `teacher_subjects`, `student_marks`, `attendance`, `otp_codes`, `system_settings`, `audit_logs`, `quizzes`, `quiz_questions`, `quiz_attempts`, `learning_materials`, `news_updates`) and initial sample data will be created instantly.

#### Step 3: Configure Database Connection
Open the file `config/database.php` in a text editor or the hosting File Manager:

```php
define('DB_HOST', 'sql123.infinityfree.com'); // Or 'localhost' / your host IP
define('DB_NAME', 'your_database_name');
define('DB_USER', 'your_database_user');
define('DB_PASS', 'your_database_password');
```

Save the file.

#### Step 4: Upload the Project Files
1. Open your hosting **File Manager** or connect via **FTP** (e.g. FileZilla).
2. Navigate to your root web directory:
   - On InfinityFree: `/htdocs/`
   - On cPanel: `/public_html/`
3. Upload all contents of the `EP-NKORE/` folder into your root directory.
4. Ensure upload directories have write permissions (CHMOD 755 or 777):
   - `uploads/profiles/`
   - `uploads/students/`
   - `uploads/materials/`
   - `uploads/news/`

#### Step 5: Test in Your Browser
Open your website URL: `https://your-domain.com` or `http://your-subdomain.infinityfreeapp.com`.
The portal home page will load immediately!

---

### 3. New Modules & Capabilities

1. **Super Admin User Management (`admin/users.php`):**
   - Super Admin can permanently delete user accounts with full audit logs.
   - Super Admin can directly update any user's profile: names, email, phone number, system role, and set new custom passwords.

2. **Teacher Online Quizzes & Tests (`teacher/quizzes.php` & `quiz_take.php`):**
   - Teachers can create timed online MCQ quizzes with multiple choices.
   - **Toggle 1:** Show results immediately to pupils after submission, or keep them hidden until reviewed.
   - **Toggle 2:** Automatically record marks into the official gradebook (`student_marks`).

3. **Learning Materials Upload (`teacher/materials.php` & `materials.php`):**
   - Teachers upload class revision notes, exercises, and weekly homework assignments (PDF, Word, PPTX, Images, or direct text).
   - Pupils and parents can filter by class, download files, or read questions directly on mobile or desktop.

4. **School News, Photos & Videos Portal (`admin/news.php` & `news.php`):**
   - School leadership can post real-time updates: text articles, photo galleries, and embedded video tours/lessons.
   - Visible to all website visitors and community members on the homepage.

---

### 4. Default Login Credentials (For Testing)

The database comes pre-seeded with approved accounts for each role:

| Role | Username (Phone or Email) | Password | Notes |
| :--- | :--- | :--- | :--- |
| **Administrator** | `+250781125809` or `jeanpierret772@gmail.com` | `Admin@Nkore2025!` | Full School System & Staff Management |
| **Head Teacher** | `+250788000002` or `headteacher@epnkore.edu.rw` | `Head@Nkore2025!` | Academic Supervision & Bulletins |
| **Teacher** | `+250788000003` or `teacher@epnkore.edu.rw` | `Teacher@Nkore2025!` | P6 Attendance & Marks Entry |

---

### 4. How the Two-Factor OTP System Works

1. When a user enters their credentials on `login.php`:
   - Passwords are verified securely using standard `password_hash()`.
   - The user's account approval status is checked (`PENDING`, `APPROVED`, `REJECTED`).
   - If approved, a secure **6-digit numerical OTP** is generated with a 5-minute expiration time and maximum 3 attempts lockout.
2. **Development Simulator Mode:**
   - In `config/otp.php`, `OTP_DEV_MODE` is set to `true` by default.
   - The generated 6-digit OTP is safely displayed in a visual helper box right on the verification screen and logged to the PHP error log.
   - This allows testing the complete 2FA authentication flow without incurring SMS gateway fees.
3. **Switching to Live SMS (Production):**
   - In `config/otp.php`, set `OTP_DEV_MODE = false;`.
   - Configure your SMS gateway credentials (e.g. **Africa's Talking**, **Twilio**, or a local telecom SMS API endpoint in the `send_otp_sms()` function).

---

### 5. Staff Registration & Approval Workflow

1. New staff members register via `register.php`.
2. All passwords must satisfy the security criteria:
   - Minimum 8 characters
   - At least 1 uppercase letter (A-Z)
   - At least 1 lowercase letter (a-z)
   - At least 1 number (0-9)
   - At least 1 special character (!@#$)
3. **Initial status:** New accounts are automatically assigned **`PENDING`** status.
4. The user cannot log in immediately; attempting to sign in displays:
   *"Your account is waiting for administrator approval."*
5. The Administrator logs in, visits **Admin Dashboard -> Account Approvals** (`admin/approve_users.php`), and clicks **Approve** or **Reject**.
6. Once approved, the user can sign in, complete 2FA OTP verification, and access their dashboard!

---

### 6. Mobile Usage for Android Phones

- The entire interface is built with responsive mobile-first CSS.
- On Android phones (Chrome, Firefox, Samsung Internet):
  - Tap the top-left hamburger menu to open the navigation drawer.
  - Large touch targets (minimum 44px) for all buttons and attendance radio pills.
  - Teachers can mark daily attendance directly in the classroom from their smartphone.
  - Responsive tables with horizontal swiping support on compact screens.

---

### 7. Support & Maintenance
Developed for **EP NKORE - Basic Education School**.
Built using clean, native PHP 8.x, PDO Prepared Statements, CSRF tokens, and zero external build tools.
