<?php
/**
 * EP NKORE - School Management System
 * Two-Factor OTP Verification
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/otp.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

// If already logged in and verified, jump to dashboard
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

// User must have come from login.php with pending OTP
if (empty($_SESSION['pending_otp_user_id'])) {
    set_flash('warning', 'Please enter your username and password first to receive an OTP verification code.');
    session_write_close();
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['pending_otp_user_id'];
$user_phone = $_SESSION['pending_otp_phone'] ?? 'your registered phone';
$masked_phone = substr($user_phone, 0, 4) . ' ••• ' . substr($user_phone, -3);

$error = null;

// Fetch latest active OTP record
$stmt = $pdo->prepare("SELECT * FROM otp_codes WHERE user_id = ? AND is_used = 0 ORDER BY id DESC LIMIT 1");
$stmt->execute([$user_id]);
$otp_record = $stmt->fetch();

if (!$otp_record) {
    set_flash('danger', 'No active OTP found. Please sign in again to request a new code.');
    unset($_SESSION['pending_otp_user_id']);
    header('Location: login.php');
    exit;
}

// Handle OTP Resend
if (isset($_GET['action']) && $_GET['action'] === 'resend') {
    $last_sent = $_SESSION['pending_otp_time'] ?? 0;
    if (time() - $last_sent < OTP_RESEND_COOLDOWN) {
        $remaining = OTP_RESEND_COOLDOWN - (time() - $last_sent);
        set_flash('warning', "Please wait {$remaining} seconds before requesting another OTP.");
        header('Location: verify_otp.php');
        exit;
    }

    // Invalidate old codes
    $pdo->prepare("UPDATE otp_codes SET is_used = 1 WHERE user_id = ?")->execute([$user_id]);

    // Generate fresh OTP
    $new_otp = generate_secure_otp(OTP_LENGTH);
    $expiry = date('Y-m-d H:i:s', strtotime('+' . OTP_EXPIRY_MINUTES . ' minutes'));

    $pdo->prepare("INSERT INTO otp_codes (user_id, otp_code, expires_at, attempts, is_used) VALUES (?, ?, ?, 0, 0)")
        ->execute([$user_id, $new_otp, $expiry]);

    send_otp_sms($user_phone, $new_otp);
    $_SESSION['pending_otp_time'] = time();
    if (OTP_DEV_MODE === true) {
        $_SESSION['dev_mode_otp_display'] = $new_otp;
    }

    log_audit($pdo, $user_id, 'OTP_RESENT', "New OTP requested by user");
    set_flash('success', 'A fresh verification code has been dispatched to ' . $masked_phone);
    header('Location: verify_otp.php');
    exit;
}

// Handle OTP Verification Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf)) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $entered_otp = trim($_POST['otp_code'] ?? '');

        if (strlen($entered_otp) !== 6 || !ctype_digit($entered_otp)) {
            $error = "Please enter a valid 6-digit numerical code.";
        } elseif (strtotime($otp_record['expires_at']) < time()) {
            $error = "OTP has expired. Please click 'Resend Code' below.";
        } elseif ($otp_record['attempts'] >= OTP_MAX_ATTEMPTS) {
            // Lockout this OTP session
            $pdo->prepare("UPDATE otp_codes SET is_used = 1 WHERE id = ?")->execute([$otp_record['id']]);
            log_audit($pdo, $user_id, 'OTP_MAX_ATTEMPTS_EXCEEDED', "User exceeded maximum verification attempts");
            unset($_SESSION['pending_otp_user_id']);
            set_flash('danger', 'Maximum verification attempts exceeded. Please sign in again.');
            header('Location: login.php');
            exit;
        } elseif ($entered_otp !== $otp_record['otp_code']) {
            // Increment attempt count
            $new_attempts = $otp_record['attempts'] + 1;
            $pdo->prepare("UPDATE otp_codes SET attempts = ? WHERE id = ?")->execute([$new_attempts, $otp_record['id']]);
            $attempts_left = OTP_MAX_ATTEMPTS - $new_attempts;

            if ($attempts_left <= 0) {
                unset($_SESSION['pending_otp_user_id']);
                set_flash('danger', 'Invalid OTP. Maximum attempts exceeded. Please sign in again.');
                header('Location: login.php');
                exit;
            } else {
                $error = "Invalid OTP code. You have {$attempts_left} attempt(s) remaining.";
            }
        } else {
            // OTP is correct!
            $pdo->prepare("UPDATE otp_codes SET is_used = 1 WHERE id = ?")->execute([$otp_record['id']]);

            // Fetch user record
            $stmt_u = $pdo->prepare("SELECT id, role, first_name, last_name FROM users WHERE id = ? LIMIT 1");
            $stmt_u->execute([$user_id]);
            $user = $stmt_u->fetch();

            // Secure session creation & ID regeneration
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
            $_SESSION['otp_verified'] = true;
            $_SESSION['authenticated_at'] = time();

            // Clean up temporary session flags
            unset($_SESSION['pending_otp_user_id']);
            unset($_SESSION['pending_otp_phone']);
            unset($_SESSION['pending_otp_time']);
            unset($_SESSION['dev_mode_otp_display']);

            log_audit($pdo, $user['id'], 'LOGIN_SUCCESS_OTP', "User successfully authenticated with 2FA OTP");

            set_flash('success', "Welcome back, {$user['first_name']}!");
            header('Location: dashboard.php');
            exit;
        }
    }
}

$page_title = "Verify OTP - EP NKORE";
require_once __DIR__ . '/includes/header.php';
?>

<div class="otp-card">
    <div class="otp-icon-wrap">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="5" y="2" width="14" height="20" rx="2" ry="2"/>
            <line x1="12" y1="18" x2="12.01" y2="18"/>
        </svg>
    </div>

    <h2 style="font-size: 22px; font-weight: 700; margin-bottom: 8px;">Two-Factor Authentication</h2>
    <p style="font-size: 14px; color: var(--slate-600); margin-bottom: 16px;">
        We have sent a 6-digit verification code to your phone number: <strong><?= e($masked_phone) ?></strong>.
    </p>

    <!-- Development Simulator Banner -->
    <?php if (OTP_DEV_MODE === true && isset($_SESSION['dev_mode_otp_display'])): ?>
        <div class="dev-otp-banner">
            <div style="font-weight: 700; margin-bottom: 4px;">🛠 Development OTP Simulator (Safe Mode):</div>
            <div>Use code: <span class="dev-otp-code"><?= e($_SESSION['dev_mode_otp_display']) ?></span></div>
            <small style="color: #b45309;">(Active because <code>OTP_DEV_MODE = true</code> in <code>config/otp.php</code> for testing without an external SMS balance)</small>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger" style="margin-bottom: 16px;">
            <?= e($error) ?>
        </div>
    <?php endif; ?>

    <form action="verify_otp.php" method="POST">
        <?= csrf_field() ?>

        <div class="form-group">
            <label for="otp_code" class="form-label">Enter 6-Digit Code</label>
            <input type="text" id="otp_code" name="otp_code" class="otp-code-input" maxlength="6" pattern="[0-9]{6}" inputmode="numeric" placeholder="••••••" required autofocus>
        </div>

        <button type="submit" class="btn btn-primary btn-lg" style="width: 100%;">
            Verify Code & Access Dashboard
        </button>
    </form>

    <div style="margin-top: 24px; font-size: 13.5px; color: var(--slate-600);">
        <span id="otpTimerText">Resend code in <strong id="otpTimer">60</strong>s • </span>
        <a href="verify_otp.php?action=resend" id="otpResendBtn" style="font-weight: 600;">Resend OTP</a>
    </div>

    <div style="margin-top: 16px;">
        <a href="logout.php" style="font-size: 13px; color: var(--slate-500);">Cancel and Return to Sign In</a>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
