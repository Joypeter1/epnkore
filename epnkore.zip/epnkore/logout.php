<?php
/**
 * EP NKORE - School Management System
 * Secure Sign Out Script
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

if (isset($_SESSION['user_id'])) {
    log_audit($pdo, $_SESSION['user_id'], 'LOGOUT', "User signed out successfully");
}

logout_user();
header('Location: login.php?logged_out=1');
exit;
