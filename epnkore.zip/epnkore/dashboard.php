<?php
/**
 * EP NKORE - School Management System
 * Gateway Dashboard Dispatcher
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$user = require_login($pdo);

switch ($user['role']) {
    case 'Administrator':
        header('Location: admin/dashboard.php');
        exit;
    case 'Head Teacher':
        header('Location: headteacher/dashboard.php');
        exit;
    case 'Teacher':
        header('Location: teacher/dashboard.php');
        exit;
    default:
        logout_user();
        header('Location: login.php?error=invalid_role');
        exit;
}
